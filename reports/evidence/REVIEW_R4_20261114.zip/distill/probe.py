import os, sys, json, hashlib, pathlib, subprocess, copy
os.environ.update(BC_DEVICE='cpu', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
sys.path.insert(0,'/workspace/carbon-league/code')
import numpy as np
import torch
import cnet2_feat as F
import cnet2_train as T
import k0_distill as D
from cnet2_model import CNet2
from fastsim import FastCarbon
from eval_v53 import CFG
OUT=pathlib.Path('/workspace/review-20261114-r4/distill')
torch.set_num_threads(1); torch.manual_seed(7)
net=CNet2(C=16,NB=1,D=16,NH=2,L=1,E=8,G=4)
parent=OUT/'parent.npz'; T.export(net,str(parent),{'cfg':net.cfg})
sim=FastCarbon(CFG).reset(seed=1); sim.cash[0]=40; sim.step_count=200
feat=F.Feat(0); x=feat.observe(sim.obs(0))
arms=np.full((2,F.OWN),-1,dtype=np.int8); arms[:,10:]=[[1,0],[0,1]]

def prefix_row(arm):
    row={k:np.asarray(x[k]) for k in D.FEATURE_FIELDS if k in x}
    row.update(uf=np.zeros((F.OWN,F.UF),np.float32),mf=np.zeros((F.OWN,5,F.MF),np.float32),legal=np.ones((F.OWN,5),bool))
    pref=F.Prefix(x,copy.deepcopy(feat.aux))
    for slot in range(F.OWN):
        if not x['tok_mask'][slot]: continue
        row['uf'][slot],row['mf'][slot],row['legal'][slot]=pref.feats(slot)
        assert row['legal'][slot,arm[slot]], (slot,arm[slot])
        pref.advance(slot,int(arm[slot]))
    row.update(carbon=np.zeros(F.N,np.uint8),teacher=np.asarray(2,np.int8),gid=np.asarray(0,np.int32),step=np.asarray(200,np.int16))
    return row
ra,rb=[prefix_row(a) for a in arms]
def make_batch(rows):
    b={k:np.stack([row[k] for row in rows]) for k in D.FEATURE_FIELDS if k not in ('gid','step')}; b['y']=arms.copy()
    return T.to_dev(b,aug=False)
def calc(b):
    t,c,_=net.encode(b); lg=net.decode(b,t,c)
    lp,kl=D.joint_logp_kl(lg,lg,torch.from_numpy(arms.astype(np.int64)))
    return lp.detach().numpy(), lg.detach().numpy()
wrong,lgwrong=calc(make_batch([ra,ra])); correct,lgcorrect=calc(make_batch([ra,rb]))
priors=np.array([.6,.4]); Q=np.array([.51,.49]); q=D.construct_target(Q,priors)
assert abs(wrong[0]-correct[0])<1e-10
assert ra['legal'][11,1]==False and rb['legal'][11,1]==True
assert wrong[1]<-1e8 and correct[1]>-20

# Build exactly the documented consumer format; synthetic join, actual FastCarbon/Feat/model.
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def seal(path,train_temp=1,omit_ptrhash=False):
    path.mkdir(exist_ok=True); gen=path/'gen'; gen.mkdir(exist_ok=True)
    for k in D.FEATURE_FIELDS: np.save(gen/(k+'.npy'),ra[k][None])
    keys=dict(game=np.array([0]),step=np.array([200]),seat=np.array([0]))
    np.savez(gen/'policy_labels.npz',**keys,arms=arms[None],n_arms=np.array([2]),priors=priors[None],q=q[None],pi0=np.ones(1),pi1=np.zeros(1),pi=np.ones(1))
    np.savez(gen/'value_labels.npz',**keys,Q=Q[None])
    meta={'games':['fixture'], 'teacher':{'config':{'train_temp':train_temp,'behavior_temp':1},'config_sha256':'fixture-config'}}
    (gen/'meta.json').write_text(json.dumps(meta))
    fields={}
    for k in D.FEATURE_FIELDS+(D.POLICY_BUNDLE,D.VALUE_BUNDLE):
        p=gen/(k+('.npz' if k.endswith('_labels') else '.npy'))
        fields[k]=dict(file=p.name,bytes=p.stat().st_size,sha256=sha(p),rows=1)
    man=dict(format=D.ANNOTATION_FORMAT,total=1,generation='fixture',fields=fields,meta_sha256=sha(gen/'meta.json'),producer=dict(teacher_config_hash='fixture-config',teacher_weights_md5=hashlib.md5(parent.read_bytes()).hexdigest(),belief='conditional',config={'train_temp':train_temp,'behavior_temp':1},train_temp=train_temp))
    man['self_sha256']=D._canonical_sha256(man)
    (gen/'manifest.json').write_text(json.dumps(man))
    ptr=dict(dir='gen',generation='fixture',manifest_sha256=sha(gen/'manifest.json'))
    if omit_ptrhash: del ptr['manifest_sha256']
    (path/'current.json').write_text(json.dumps(ptr))
    return path
base=seal(OUT/'ds')
ds=D.load_annotation(str(base)); assert np.array_equal(ds['target'][0],q)
cmd=[sys.executable,'/workspace/carbon-league/code/k0_distill.py','--data',str(base),'--parent',str(parent),'--out',str(OUT/'student.npz'),'--max-updates','1','--bs','1','--device','cpu']
run=subprocess.run(cmd,env=os.environ,capture_output=True,text=True,timeout=45)
(OUT/'main.stdout').write_text(run.stdout); (OUT/'main.stderr').write_text(run.stderr)
assert run.returncode==0,run.stderr
logs=[json.loads(l) for l in run.stdout.splitlines()]; upd=next(l for l in logs if 'update' in l)
assert abs(upd['loss']['ce']-float(-q@wrong))<1e-5

dst= D.load_annotation(str(seal(OUT/'ds_temp2',train_temp=2)))
qt=q**2/(q**2).sum()
assert np.array_equal(dst['target'][0],q) and np.max(np.abs(qt-q))>.05
# Positive C arm construction exactly sqrt prior.
c=D.targets_with_flatten(ds,True)[0]; np.testing.assert_allclose(c,np.sqrt(priors)/np.sqrt(priors).sum(),atol=1e-15)
# Positive finite and sealed-byte checks.
qbad=seal(OUT/'ds_hash_bad'); fp=qbad/'gen'/'uf.npy'; raw=bytearray(fp.read_bytes());raw[-1]^=1;fp.write_bytes(raw)
try: D.load_annotation(str(qbad)); raise AssertionError('hash corrupted was accepted')
except SystemExit as e: bad_hash=str(e)
# Pointer seal omission bypasses pointer binding, while correct self seal remains.
missing_ptr=D.load_annotation(str(seal(OUT/'ds_missing_ptrhash',omit_ptrhash=True)))
res={'source_sha':'907c105965c8429919201e4d7b84ca8fb93ae0bc','fixture':'Actual FastCarbon(seed=1), cash override=40 and step_count=200 (registered window), real Feat/Prefix/CNet2; joined consumer dataset self-built, no annotator/join claimed',
'prefix':dict(arms=arms.tolist(),root_prefix_first_base_recruit=True,wrong_second_base_recruit_legal=bool(ra['legal'][11,1]),correct_second_base_recruit_legal=bool(rb['legal'][11,1]),same_prefix_control_absdiff=float(abs(wrong[0]-correct[0])),wrong_joint_logp=wrong.tolist(),correct_joint_logp=correct.tolist(),q=q.tolist(),actual_main_ce=upd['loss']['ce'],expected_ce_own_prefix=float(-q@correct),main_exit=run.returncode,main_saved=(OUT/'student.npz.complete.json').exists()),
 'temperature':dict(recorded_train_temp=2,actual_target=dst['target'][0].tolist(),expected_target=qt.tolist(),maxdiff=float(np.max(np.abs(qt-dst['target'][0])))),
 'controls':dict(C_target=c.tolist(),C_expected=(np.sqrt(priors)/np.sqrt(priors).sum()).tolist(),corrupted_file_rejected=bad_hash,omitted_pointer_hash_accepted=missing_ptr['info']['generation'])}
(OUT/'results.json').write_text(json.dumps(res,indent=2));print(json.dumps(res,indent=2))
