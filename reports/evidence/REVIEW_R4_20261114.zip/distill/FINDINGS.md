# k0_distill 只读复审

基线：`496ee1cc` → 固定审查 SHA `907c105965c8429919201e4d7b84ca8fb93ae0bc`。未改仓、未提交、未部署。

## D1 / P1：逐候选只替换 y，未重放动作相关 Prefix，合法候选也能被错屏蔽并保存成功

- 主要位置：`code/k0_distill.py:655-666`（特别是 664-665），调用路径 668-685。
- 佐证：`code/cnet2_model.py:232-239` 直接读取输入 `uf/mf/legal`；241-242 只更新前动作 embedding。`cnet2_feat.py:479-495,510-513` 明示 cash/slots 与合法招募依赖先前候选动作。
- 数据合同为 root 级 uf/mf/legal；expanded_batch 对全部 K 候选复制同一个 root 的这些特征，只换 y。RNN 前动作虽然变了，但现金、空位、占位、合法性仍属于被复制的那条旧前缀。头注释声称的“每个 candidate 在 OWN prefix 上 teacher forcing”不成立。
- 反例：真实 FastCarbon(seed=1) 构造状态、cash=40、step_count=200，真实 Feat/Prefix、小配置真实 CNet2。两基地合法候选 A=(招募,停)、B=(停,招募)。根行前缀按 A 产生；B 正确前缀到第二基地仍有40现金，复制 A 后只有10，错误 legal 把 B 的招募 mask 成 −1e9。
- 真实 `k0_distill.main` 一次更新（未替换 loss、模型、to_dev 或 loader）：B joint logp = −1,000,000,001.453667；正确逐候选 Prefix 为 −2.637894662。实际 CE **353,718,778.785733**；正确 CE **1.620111730**。数值仍 finite，因此退出码 **0**，完整 checkpoint 与 complete marker 都写出。
- 正对照：A 候选复制前缀与自身真前缀的 logp 差 **0**；C 目标恰等 sqrt(priors) 归一；损坏 uf 文件 hash 被拒绝。可见不是网络整体失败或门槛全拒绝。
- 建议：在候选级实际重放 Prefix，或把候选级 uf/mf/legal 列入封存输入并逐候选校验；根共享静态特征可以复用，动作依赖特征不能复用。需候选前缀改变招募合法性和工人占位的集成回归。单纯实现声明中的 join 容器/哨兵转换不能解决此项。
- 证据边界：状态为受控构造，父网为小配置随机网；Q/priors 为受控有效标签；consumer generation 为自造合约输入，**不是**真实 annotator→join 产物。反例验证的是生产 `Feat/Prefix/CNet2/loader/main` 计算链。本轮没有声称 join 已实现。

## D2 / P2（与 integration 线合并）：train_temp 非1的认证对象没有进入蒸馏消费者

- `code/k0_annotate.py:175-182` 配置包含 train_temp；其头注释 39-44 明示存的是 raw q，供下游 q**train_temp。
- `reports/STAGE1_TEACHER_GATES_20261113.md:245-250` 规定 q 闸仅覆盖所认证的训练分布。
- `code/k0_distill.py:407-425` 始终重构 raw q 且不读取/检查 train_temp；CLI 只有 q_temp（指数 Q 的温度），不是对全 q 的幂温度。
- 将同一封存测试集的 producer.config、producer.train_temp、meta.teacher.config 全记录 train_temp=2，loader 仍接受且返回原 q `[0.6462812224,0.3537187776]`；对应认证目标 q² 归一为 `[0.7694955688,0.2305044312]`，最大差 **0.1232143464**。默认 train_temp=1 的正对照完全一致。
- 影响有条件：仅当登记/认证用非1温度时发生；不能据此声称默认1的当前正式跑已错。最小修复可以先把当前配方限制为 train_temp=1 并拒绝其他输入；若支持非1，消费、目标构造、C 对照定义与 provenance 必须共同绑定。
- 本项交 integration 线统一对照跨入口合同；避免重复列项。

## 低优先注记（是否列项由主审裁定）

`verify_annotation_generation` 的 pointer manifest_sha256 在 211-212 为 optional。删除字段后，正确 self-sealed generation 被接受；与头注释“pointer manifest hash verify-or-refuse”不一致。现有文件逐项 hash 与 manifest 自封印仍生效；未将其上升为已发生的混代故障。

## 已核且未报缺陷

- C 的 construct_target 只将 Q 置平，目标 sqrt(P_A) 正确；没有硬标签 CE。
- KL 计算 float64，方向 student||parent，按有效槽求和、按候选均值；上述 Prefix 错误会同时污染 KL 的条件状态，但不是另一个独立缺陷。
- 冻结前缀从 optimizer 排除，保存时逐位检查；完整当前 parent 的 smoke 保存通过。
- parent 文件 md5 与 producer 权重身份绑定，且有限性、文件哈希损坏有拒绝门。
- 无 resume 是显式配方设计，不报告为遗漏。
- 最新裁定明确输入合同有条件、join 待补：未把这一已声明开放项重新报成隐藏缺陷。

## 运行与工件

```
cd /workspace/carbon-league
/workspace/carbon-review-venv/bin/python /workspace/review-20261114-r4/distill/probe.py
```

脚本 `probe.py`；精确结果 `results.json`；真实主入口日志 `main.stdout` / `main.stderr`；封存输入 ds、ds_temp2；输出 student.npz 及 complete marker。所有文件在仓外 `/workspace/review-20261114-r4/distill/`。
