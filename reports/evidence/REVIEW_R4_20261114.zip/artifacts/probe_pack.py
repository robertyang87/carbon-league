import os,sys,ast,json,pathlib,hashlib,base64,zlib,gzip,subprocess,collections
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
sys.dont_write_bytecode=True
import numpy as np
repo=pathlib.Path('/workspace/carbon-league');out=pathlib.Path('/workspace/review-20261114-r4/artifacts')
sys.path.insert(0,str(repo/'code'))
from cnet2_model import CNet2
from cnet2_pack import dequantize
head='907c105965c8429919201e4d7b84ca8fb93ae0bc';base='496ee1cc'
def blob(p):return subprocess.check_output(['git','-C',str(repo),'show',head+':'+p])
paths=subprocess.check_output(['git','-C',str(repo),'diff','--name-only',base,head],text=True).splitlines()
R={'base':base,'head':head,'packs':[],'matches':[],'replays':[]}
for p in paths:
 if not(p.startswith('code/exp/') and p.endswith('.py')):continue
 raw=blob(p); tree=ast.parse(raw);v={}
 for n in tree.body:
  if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
   try:v[n.targets[0].id]=ast.literal_eval(n.value)
   except:pass
 src_checks={}
 for name,src in v['_SRC'].items():
  b=src.encode();auth=blob('code/'+name+'.py')
  src_checks[name]={'matches_authoritative':b==auth,'matches_declared_md5':hashlib.md5(b).hexdigest()==v['_BUILD_HASHES'][name]}
 q=v['_Q1'];weight_raw=zlib.decompress(base64.b64decode(v['_B1']));w=dequantize(weight_raw,q);meta=json.loads(v['_M1'])
 expected=CNet2(**meta['cfg']).state_dict();missing=sorted(set(expected)-set(w));unexpected=sorted(set(w)-set(expected))
 shape_bad=[k for k in w if k in expected and tuple(w[k].shape)!=tuple(expected[k].shape)]
 byte_bad=[]
 for k,shape,kind,nb in q:
  count=int(np.prod(shape)); want=count+shape[0]*4 if kind=='int8' else count*(2 if kind=='f16' else 4)
  if want!=nb:byte_bad.append(k)
 R['packs'].append({'path':p,'md5':hashlib.md5(raw).hexdigest(),'sources':src_checks,'conf':v['CONF'],'meta':meta,'weight_tensor_count':len(w),'weight_elements':sum(a.size for a in w.values()),'raw_weight_bytes':len(weight_raw),'q_bytes_sum':sum(x[3] for x in q),'q_duplicate_keys':len(q)-len({x[0] for x in q}),'q_bad_byte_sizes':byte_bad,'nonfinite_keys':[k for k,a in w.items() if not np.isfinite(a).all()],'shape_mismatch_keys':shape_bad,'missing_model_keys':missing,'unexpected_model_keys':unexpected,'multiple_weight_payloads':bool(v['_B2'] or v['_B3'] or v['_ENS'])})

(out/'pack_results.json').write_text(json.dumps(R,indent=2,allow_nan=False)+'\n')
print(json.dumps(R,indent=2))
