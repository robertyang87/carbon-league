import os,sys,json,gzip,hashlib,subprocess,collections,zlib,tempfile
from pathlib import Path
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
sys.dont_write_bytecode=True
repo=Path('/workspace/carbon-league');out=Path('/workspace/review-20261114-r4/artifacts');base='496ee1cc';head='907c105965c8429919201e4d7b84ca8fb93ae0bc'
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args])
def blob(p):return git('show',head+':'+p)
paths=git('diff','--name-only',base,head).decode().splitlines()
R={'base':base,'head':head,'matches':[],'replays':[]}
indexes={}
for p in paths:
 if p.startswith('data/') and p.endswith('_matches.json'):
  d=json.loads(blob(p));by={(m['id'],m['game']):m for m in d};indexes[p]=by
  R['matches'].append({'path':p,'rows':len(d),'unique_ids':len({m['id'] for m in d}),'unique_game_keys':len(by),'states':dict(collections.Counter(m.get('state') for m in d)),'duplicate_game_keys':len(d)-len(by)})
newgz=[p for p in paths if p.endswith('.json.gz')]
newnames={Path(p).name for p in newgz};tree=git('ls-tree','-r',head,'--','data').decode().splitlines();byname=collections.defaultdict(list)
for line in tree:
 info,p=line.split('\t',1)
 if Path(p).name in newnames:byname[Path(p).name].append({'path':p,'blob':info.split()[2]})
first=None
for p in newgz:
 raw=blob(p);d=json.loads(gzip.decompress(raw));stem=Path(p).name.removesuffix('.json.gz');mid,gno=stem.rsplit('-',1);family=p.split('/')[1].removesuffix('_corpus');table=indexes.setdefault('data/'+family+'_matches.json',{(v['id'],v['game']):v for v in json.loads(blob('data/'+family+'_matches.json'))});m=table.get((mid,int(gno)));steps=d['steps'];reward=[m['scores'][k] for k in m['order']] if m else None
 entry={'path':p,'family':family,'replay_id':d.get('id'),'sha256':hashlib.sha256(raw).hexdigest(),'steps':len(steps),'all_steps_two_seats':all(isinstance(s,list) and len(s)==2 for s in steps),'in_match_index':m is not None,'rewards':d.get('rewards'),'index_rewards':reward,'rewards_match_index':d.get('rewards')==reward,'statuses':d.get('statuses'),'last_statuses':[x.get('status') for x in steps[-1]],'last_rewards':[x.get('reward') for x in steps[-1]],'terminal_matches_top':([x.get('reward') for x in steps[-1]]==d.get('rewards') and [x.get('status') for x in steps[-1]]==d.get('statuses')),'same_basename_paths':byname[Path(p).name],'val_rule':zlib.crc32(Path(p).name.encode())%10==0}
 R['replays'].append(entry)
 if first is None and len(byname[Path(p).name])>1:first=(p,m,raw)
R['counts_by_family']=dict(collections.Counter(x['family'] for x in R['replays']))
R['new_duplicate_game_groups']=[v for v in ({n:[x['path'] for x in R['replays'] if Path(x['path']).name==n] for n in newnames}).values() if len(v)>1]
R['new_paths_also_elsewhere_in_head']=sum(len(x['same_basename_paths'])>1 for x in R['replays'])
R['cross_corpus_same_basename_differing_blob']={n:v for n,v in byname.items() if len({x['blob'] for x in v})>1}
R['bad_replays']=[x['path'] for x in R['replays'] if not all((x['all_steps_two_seats'],x['in_match_index'],x['rewards_match_index'],x['terminal_matches_top']))]
id_groups=collections.defaultdict(list)
for x in R['replays']:id_groups[x['replay_id']].append(x)
R['unique_new_replay_ids']=len(id_groups)
R['new_same_replay_id_different_names']={k:[x['path'] for x in v] for k,v in id_groups.items() if len({Path(x['path']).name for x in v})>1}
R['new_same_replay_id_different_hashes']={k:[x['path'] for x in v] for k,v in id_groups.items() if len({x['sha256'] for x in v})>1}
R['step_counts']=dict(collections.Counter(x['steps'] for x in R['replays']))
(out/'data_results.json').write_text(json.dumps(R,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:R[k] for k in ['matches','counts_by_family','new_paths_also_elsewhere_in_head','cross_corpus_same_basename_differing_blob','bad_replays']},indent=2))
