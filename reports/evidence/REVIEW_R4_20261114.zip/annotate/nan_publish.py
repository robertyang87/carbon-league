import os,sys,json,shutil,tempfile,argparse
from pathlib import Path
for n in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[n]='1'
sys.dont_write_bytecode=True
sys.path.insert(0,'/workspace/carbon-league/code')
import numpy as np
import k0_annotate as A
O=Path('/workspace/review-20261114-r4/annotate'); F=Path(json.loads((O/'results.json').read_text()).get('fixture',str(O/'fixture')))
a=argparse.Namespace(weights=str(F/'live.npz'),replays=str(F/'replays'),games=str(F/'games.json'),window_lo=0,window_hi=1,K=2,M=1,H=0,workers=1,belief='sample',teacher_style=2,train_temp=1.,behavior_temp=1.,seed_teacher=7000,seed=12345,pi0=1.,pi1=1.,isolation_file=[])
plan=A.build_plan(a)
R={}
for field in ('q','priors','Q_std','Q','pi'):
 out=Path(tempfile.mkdtemp(prefix='nan_'+field+'_',dir=O)); sd=out/'shards';sd.mkdir()
 with np.load(F/'healthy/shards/g1.npz') as D:
  arrs={k:D[k].copy() for k in A.FIELDS}; meta=json.loads(str(D['_meta'].item()))
 if arrs[field].ndim==1:arrs[field][0]=np.nan
 else:arrs[field][0,0]=np.nan
 meta['arrays']={k:A._array_sha(arrs[k]) for k in A.FIELDS}
 with open(sd/'g1.npz','wb') as f:np.savez(f,_meta=np.asarray(json.dumps(meta,sort_keys=True)),**arrs)
 err=None; pub=None; ver=None; value=None
 try:
  m=A._verify_shard(str(sd),plan['per_game'][0],plan['identity'])
  pub=A.publish(str(out),plan,[m]); ver=A.resolve_out_arg(str(out)); lm,la=A.load_annotated(str(out));value=la[field].flat[0].item()
 except BaseException as e:err=repr(e)
 R[field]={'publish':pub,'verify':ver,'loaded_first_value':value,'error':err,'out':str(out)}
(O/'nan_publish_results.json').write_text(json.dumps(R,indent=2,allow_nan=True));print(json.dumps(R,indent=2,allow_nan=True))
