# k0_annotate 只读复审

冻结：`907c105965c8429919201e4d7b84ca8fb93ae0bc`。范围：`code/k0_annotate.py` 全文件及其 teacher/gate 调用，最新 K0 round-2 ruling。源码未改动；全部探针及产物在本目录。

## A01 — P2：恢复身份未绑定 replay 内容及实际标注代码，可给旧标签盖新版身份

位置：`code/k0_annotate.py:266-272`，`417-422`，`563-570`，`775-791`。

run identity 只有游戏名单、选中根、参数和权重 hash；没有每局 replay 内容 hash，也没有标注器/教师/特征/模拟器代码 hash。恢复时根列表和身份一致就跳过旧 shard；publish 才读取当前代码 hash。故同 ID 的 replay 被纠正，或者 rollout/teacher 修复后续跑同 OUT，都不会使旧 shard 失效，甚至将旧标签重新封存成新代码产物。若任务只做完一部分就升级，旧新 shard 可混在一个 generation 内。

实测：真实 tiny CNet2、实际 teacher K=2/M=1/H=0 产生两席两根。把 replay 的 full_carbon 改掉而保留 ID、terminal bound、根集合，`identity_equal=true`，恢复没有调用 `_eval_root`，原 generation 直接复用。将 `code_md5s()` 返回的 teacher hash 单独模拟更新，仍无重算，manifest 却记录新 teacher hash，generation 也变了。代码变更部分仅为 hash 函数注入，不冒称改过真实仓库文件或重测了新教师；恢复接受旧 shard 的行为是实际代码路径。

修法：启动时冻结完整 source identity（每局 replay hash、所有语义相关源码 hash），写入 plan/progress/shard；恢复按同一身份核验，publish 使用该冻结身份而不是事后读盘身份。读取 replay 应同时防止 hash 后换文件。

## A02 — P2：权重先 hash 后按可变路径重读，产物身份可与实际推理权重不同

位置：`code/k0_annotate.py:239`、`285-288`、`808-818`。

build_plan 对路径上的权重计算 md5，随后各 worker 再 np.load 同一路径，并不核验读取字节与 plan 的 md5。原子刷新 live checkpoint/symlink 恰落在两步之间，会使所有 identity 和封存验证仍写 A、实际教师使用 B；多 worker 启动期间变化还可造成互相不同的教师。

实测是实际网络和教师，非 stub 推理：A 的 utility.bias=+4，正常 Q=0.9820137900；在 build_plan 返回后、worker 初始化前将路径换成 B（bias=-4），实际 Q=0.0179862100。全流程正常封存并通过 consumer verify，manifest 的 weights_md5 仍是 A 的 `129e89678a58a1fa58985bf85ba8e0a7`，实际加载 B 为 `83c2507064a4e1f864db843420615d20`。

修法：只读一次权重字节，从同一 buffer hash+load，或将已核验权重物化为不可变 snapshot 给全部 worker；worker 必须验证其加载字节与计划身份一致。仅在 np.load 前后分别 hash 路径不能完全绑定解析的那份字节。

## A03 — P2：复用历史 generation 未验 meta.json，可能先将健康指针切到坏代再失败

位置：`code/k0_annotate.py:618-629`、`635-642`；消费端正确检查在 `672-674`。

reuse 分支验证 manifest self-seal、expected core 和 fields 文件，但没有校验历史目录的实际 meta.json。旧 meta 损坏时仍 reused=true 并切 current；main 后面的 resolve_out_arg 才报错。消费者不会静默消费坏 meta，但原健康 current 已被替换，不满足失败不发布的契约。这是新 annotate 入口同类缺口，不应把已经修复的 exit_merge 同项重新记为未修。

实测：先 publish A，再以另一 producer hash publish 健康 B 并让 current 指向 B；只把历史 A/meta.json 改成 `{}`，再 publish A 返回 `reused=true`、current 指向损坏 A；consumer 抛 `annotation generation meta seal mismatch`。实际 publish/consumer 路径，只有制造两个 distinct generation 的 code hash 是注入。

修法：reuse 在翻指针前验证 meta 文件存在且实际 SHA 与 old.meta_sha256 一致，最好复用统一全量 generation verifier；任何失败保留现有 current。补正反例：完好同代可复用；损坏旧 meta 拒绝且 current 不变。

## A04 — P3（可由主审按发布门要求升 P2）：q/priors 的 NaN 被封存及消费验证放行

位置：`code/k0_annotate.py:475-488`，调用点 `516-517`、`698-699`。

Q 和 π 有显式 finite 门，q/priors 只有负值检查及 q.sum 归一检查。NaN 的 `<0`、`abs(sum-1)>tol` 都为 False，导致无效概率分布通过。Q_std 也不验 finite，但它是诊断字段，不能与策略目标的影响混为一谈。

实测：复用真实 teacher 产出的健康 shard，只将一个 real arm 的 q 或 priors 置 NaN，重新计算 producer embedded array hash，再走 `_verify_shard → publish → resolve_out_arg → load_annotated`。均成功封存，14 个文件校验通过，消费者确实加载 NaN。Q_std 同样通过。正反控制：同样置 Q=NaN 或 pi=NaN 都在 pre-seal 正确拒绝。

边界：这是 producer 数值异常的注入测试；没有声称正常教师自然产生了 NaN，也没有声称 NaN 已通过尚未完成的 join 或下游 distill 的独立有限性门。问题是此入口宣称的 verify-or-refuse 接受了数学上非法的策略标签。

修法：recorded arms 的 q、priors 都须 finite、非负，并各自归一（若 priors 按协议必须 normalized）；Q_std 如要求有效则 real arms finite 且 >=0，padding NaN 保留允许。

## 正面/已知边界

- `_eval_root` 直接调用 gate.extract_scene / _teacher_guard_snaps / teacher.evaluate_root，席位与 Feat 历史、belief 和 teacher_version 检查未发现新的偏离。
- 终局窗口沿用 gate 的 first-terminal bound，遍历 `step < min(len-1, ft, hi)`；0<=lo<hi<=299。
- 目前两阶段采样（整局概率 pi0；未中局逐根 pi1）的边际包含概率确实是 pi0+(1-pi0)*pi1；无证据将该公式记为错误。
- raw q、priors 和 train_temp 的输出契约有明确文档：下游派生温度后的目标，不能把存 raw q 本身报成 bug。
- annotator 与 distill 格式不直通已在裁定书明确登记，join 为未完成件 4；本报告不重复报为新增隐藏缺口。
- 小配置真实 teacher 只用于验证身份/发布链和数值探针，不等于生产教师成本/收益、长局或完整资源认证。

## 复跑

```bash
/workspace/carbon-review-venv/bin/python /workspace/review-20261114-r4/annotate/probe.py
/workspace/carbon-review-venv/bin/python /workspace/review-20261114-r4/annotate/nan_publish.py
```

`probe.py` 每次创建独立 fixture 目录；`nan_publish.py` 从最新 `results.json` 取它的真实 shard。结果：`results.json`、`probe.log`、`nan_publish_results.json`。
