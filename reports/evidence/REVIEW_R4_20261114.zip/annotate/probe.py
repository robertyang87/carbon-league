import os,sys,json,gzip,hashlib,copy,contextlib,io,tempfile
from pathlib import Path
from unittest.mock import patch
for n in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[n]='1'
sys.dont_write_bytecode=True
sys.path.insert(0,'/workspace/carbon-league/code')
import numpy as np,torch
import k0_annotate as A
from cnet2_model import CNet2
from rl2_ppo_cnet2 import Cnet2Adapter
from fastsim import FastCarbon
from eval_v53 import CFG
O=Path('/workspace/review-20261114-r4/annotate');F=Path(tempfile.mkdtemp(prefix='fixture_',dir=O))
torch.set_num_threads(1);torch.manual_seed(123)
ad=Cnet2Adapter();net=CNet2(C=16,NB=1,D=16,NH=2,L=1,E=8,G=4)
w=ad.export(net);w['utility.weight']=np.zeros_like(w['utility.weight']);w['utility.bias']=np.full_like(w['utility.bias'],4)
wa=F/'a.npz';wb=F/'b.npz';live=F/'live.npz';np.savez(wa,**w)
w['utility.bias']=np.full_like(w['utility.bias'],-4);np.savez(wb,**w);live.write_bytes(wa.read_bytes())
rp=F/'replays';rp.mkdir(exist_ok=True)
sim=FastCarbon(CFG).reset(seed=1)
frame=[{'status':'ACTIVE','observation':sim.full_observation(p),'action':{}} for p in (0,1)]
for e in frame:e['observation']['full_carbon']=list(sim.carbon)
end=copy.deepcopy(frame)
for e in end:e['status']='DONE'
d={'steps':[frame,end]};replay=rp/'g1.json.gz'
def wr_replay(doc):
 with gzip.open(replay,'wt') as f:json.dump(doc,f)
wr_replay(d);games=F/'games.json';games.write_text(json.dumps(['g1']))
args0=['--weights',str(live),'--replays',str(rp),'--games',str(games),'--window-lo','0','--window-hi','1','--K','2','--M','1','--H','0','--workers','1']
R={'fixture':str(F)};logs=io.StringIO()
def run(out,extra=None):
 with contextlib.redirect_stdout(logs):return A.main(args0+['--out',str(out)]+(extra or []))
# Healthy real teacher -> shard -> generation -> consumer.
out=F/'healthy';run(out);summary=A.resolve_out_arg(str(out));meta,arr=A.load_annotated(str(out))
R['normal']={'verified':summary,'Q':arr['Q'].tolist(),'q':arr['q'].tolist(),'rows':len(arr['step'])}
# Feed content changes, same game id/length/terminal bound/root set.
planargs=__import__('argparse').Namespace(weights=str(live),replays=str(rp),games=str(games),window_lo=0,window_hi=1,K=2,M=1,H=0,workers=1,belief='sample',teacher_style=2,train_temp=1.,behavior_temp=1.,seed_teacher=7000,seed=12345,pi0=1.,pi1=1.,isolation_file=[])
p1=A.build_plan(planargs);oldraw=hashlib.sha256(replay.read_bytes()).hexdigest();d2=copy.deepcopy(d)
for st in d2['steps']:
 for e in st:e['observation']['full_carbon']=[v+10. for v in e['observation']['full_carbon']]
wr_replay(d2);p2=A.build_plan(planargs)
with patch.object(A,'_eval_root',side_effect=AssertionError('resume must not need this for probe')):
 err=None
 try:run(out)
 except BaseException as e:err=repr(e)
R['changed_replay_resume']={'source_bytes_changed':hashlib.sha256(replay.read_bytes()).hexdigest()!=oldraw,'identity_equal':p1['identity']==p2['identity'],'error':err,'generation_unchanged':A.resolve_out_arg(str(out))['generation']==summary['generation']}
# Code change not in resume identity; publish can stamp old shard labels with new code identity.
orig_codes=A.code_md5s();codes2=dict(orig_codes);codes2['stage0_teacher.py']='0'*32
with patch.object(A,'code_md5s',return_value=codes2),patch.object(A,'_eval_root',side_effect=AssertionError('no recompute')):
 err=None
 try:run(out)
 except BaseException as e:err=repr(e)
s2=A.resolve_out_arg(str(out));man=json.loads((Path(s2['dir'])/'manifest.json').read_text())
R['changed_code_resume']={'error':err,'source_teacher_md5':orig_codes['stage0_teacher.py'],'published_teacher_md5':man['producer']['code_md5']['stage0_teacher.py'],'generation_changed':s2['generation']!=summary['generation']}
# Real worker load after build_plan() path has been replaced: labels from B, identity A.
wr_replay(d);live.write_bytes(wa.read_bytes());outw=F/'weights';orig_build=A.build_plan
def swapped(a):
 p=orig_build(a);live.write_bytes(wb.read_bytes());return p
with patch.object(A,'build_plan',side_effect=swapped):run(outw)
wm,wx=A.load_annotated(str(outw))
R['weight_swap']={'recorded_md5':wm['teacher']['weights_md5'],'A_md5':A._md5_file(str(wa)),'actual_B_md5':A._md5_file(str(live)),'actual_bias':A._W['pol'].w['utility.bias'].tolist(),'Q':wx['Q'].tolist()}
# Published metadata corruption reused by same-input publish, verification fails only AFTER pointer flip.
# Use healthy shard and original plan; repair source to A identity.
live.write_bytes(wa.read_bytes());plan=A.build_plan(planargs)
shard=A._verify_shard(str(out/'shards'),plan['per_game'][0],plan['identity'])
# Publish clean A under original code, then B under altered code, keeping healthy current B.
a=A.publish(str(out),plan,[shard]);pa=json.loads((out/'current.json').read_text());ad=out/pa['dir']
with patch.object(A,'code_md5s',return_value=codes2):b=A.publish(str(out),plan,[shard])
pb=json.loads((out/'current.json').read_text());(ad/'meta.json').write_text('{}')
res=A.publish(str(out),plan,[shard]);after=json.loads((out/'current.json').read_text())
try:A.resolve_out_arg(str(out));verr=None
except BaseException as e:verr=repr(e)
R['reuse_corrupt_meta']={'republish_result':res,'healthy_before':pb['generation'],'after':after['generation'],'switch_to_corrupt_A':after['generation']==pa['generation'],'consumer_error':verr}
# Nonfinite target validation hole, direct validator before sealing.
for field in ('q','priors','Q_std'):
 z={k:v.copy() for k,v in arr.items()};z[field][0,0]=np.nan
 try:A.validate_records(z,[0,1],2,'nan-'+field);e=None
 except BaseException as ex:e=repr(ex)
 R['nan_'+field]={'accepted':e is None,'error':e}
(O/'results.json').write_text(json.dumps(R,indent=2,allow_nan=True)+'\n');(O/'probe.log').write_text(logs.getvalue());print(json.dumps(R,indent=2))
