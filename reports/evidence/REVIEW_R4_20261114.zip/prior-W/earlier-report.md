Carbon League 复审交接说明（2026-11-14）

这是 b9997026 → 10907a81 的 W01–W12 清单和复现证据。
它不是 baed0b5c → b9997026 的 V01–V11 清单。
原报告已明确 V01–V10 原反例通过（包括 V04、V10）；W 是后续发现。

截至 496ee1cc，code 树与 10907a81、70d3e863 完全一致：
824f95e58980ee7ce17625bb51de53a604deca57。

状态澄清：W01–W10 为 10 项 P2，待修复或逐项处置；
W11 为 P3，待处置；W12 即原 V11，按用户本次提供的裁定记为
已批准 fix-on-touch 缓修，代码未改，不要求在 pilot 在飞期间立即修改。
这不是把已关闭的 V04/V10 重新打开。

原报告保持原样作为审查记录，以本说明更新 W12 的处置状态。
各 JSON 是当轮实际结果，各脚本说明了受控 fixture 和真实运行的边界。
脚本包含 /workspace/carbon-league 及 /workspace/review-20261114-r2
的绝对路径；在别的机器复跑前需适配根路径及 Python 依赖。
运行使用 /workspace/carbon-review-venv/bin/python。此包不含生产权重、
完整训练语料或平台资源认证工件，不应把受控复现说成生产事故。

---

# Carbon League 续轮只读复审

日期：2026-11-14。

- 上轮基线：b99970267d248c99a7dfafb57b13a05b2a32e41b。
- 首次冻结：2f7ebe9e6b5eca527fc473a5f8bf4a95cea960ae。
- 收尾追加并完成复审：10907a81d1da339b9fdda90abe9d1690d3233d27。
- 追加提交仅改变 cnet2_train.py 的依赖冻结逻辑；该文件在最终版复跑，其余文件与首测版本逐字相同。
- 用户要求继续同步、review；沿用只读限制。未修改仓内源码、提交、推送或部署。报告与探针均在仓库外。

## 结论

上轮 V01–V10 的原反例本轮均已通过，包括两项 P1。不能据此认定涉及的全部入口、身份边界都已关闭：本轮确认 **10 项 P2、2 项 P3**，无新增 P1。P2 中包括原问题的边界残余和新增实现带来的回归；P3 中一项是上轮 V11 未改。

优先处理 K0 跨版本恢复改变训练集合、实际加载字节与记录身份不一致，以及认证测试覆盖产生正式口径证据的问题。以下均注明触发条件；受控复现不等于已经在生产发生事故。

## 上轮 11 项对账

| 上轮项 | 本轮原反例结果 | 仍需区分的范围 |
|---|---|---|
| V01 exit 合法 q NaN 被拒 | 通过：未搜索、部分搜索、搜索但未评估三类正常记录均加载；7 种损坏负例拒绝 | 原 P1 关闭 |
| V02 重复发布删除 generation | 通过：重复发布保留 manifest 字节及旧指针；新代发布失败保全旧代 | 原 P1 关闭；新增复用遗漏 meta 校验见 W05 |
| V03 失败部署 duel 仍获选 | 通过：单失败被剔除，双方失败拒绝，健康平局规则保留 | 原项关闭 |
| V04 独立 eval 被环境温度覆盖 | 通过：eval/learner/snap 角色隔离，真实 spawn 与实际动作均验证 | 原项关闭 |
| V05 BC_INIT 缺失→出现绕过 hash | 通过：dataset load 前拒绝；已有 A→B 替换仍绑定 A | 原项关闭 |
| V06 固定考官可变路径 | 原文件替换反例通过：执行快照不变 | 依赖缓存、数据闭包、动态加载仍有缺口，见 W03/W04/W09/W10；入口改名见 W11 |
| V07 恢复未绑定辅助标签 | 两次运行之间换标签、合法更新 sidecar，新 checkpoint 恢复已拒绝 | 加载后重读 hash 的单次运行窗口仍在，见 W02 |
| V08 screen 成功输出 NaN | 通过：有限大权重引起的推理溢出被拒；正常指标与单类 AUC=null 保留 | 原项关闭 |
| V09 cgroup 根路径误读 | 原 5 场景通过，另加 subtree-only 正例通过 | 多挂载、hybrid 布局仍有遗漏；测试覆盖未标识，见 W06–W08 |
| V10 温度测试 fixture 缺失 | 仓内脚本原样全通过，SELF 不再依赖缺文件 | 原项关闭 |
| V11 seed 段注释上界少算 | 代码未改 | P3 仍开放，见 W12 |

## 本轮发现

### W01 · P2 · 新抽样算法让旧 checkpoint 恢复时无声更换训练集合

定位：[k0_train.py:514](/workspace/carbon-league/code/k0_train.py:514)，恢复协议检查在 [607](/workspace/carbon-league/code/k0_train.py:607)。

B2 把 max-games 截断从旧版的前缀改成 seeded sampling，但恢复只校验 seed、max_games 等参数，没有校验抽样算法版本、实际 game/root 集合。相同 seed/cap 在两个算法中并不等价。

实测用真实 b9997026 主程序生成 checkpoint：6 局、cap=3、seed=7，旧集为 [0,1,2]。新版恢复成功，却改用 [0,1,3]；第四次更新实际读取 row 3，旧版连续训练读取 row 2，参数最大差 0.0103348344564。新版自身连续训练与恢复训练的正对照最大差为 0.0。

建议：保存并核对抽样协议和实际集合身份；旧 checkpoint 明确保留旧语义，或拒绝跨协议恢复并要求新实验。不要只记录新集合 hash 而不参与恢复检查。

证据：[migration_results.json](k0/migration_results.json)、[probe_migration.py](k0/probe_migration.py)。真实新旧 main、CNet2、AdamW；大数据读取替换为受控内存 fixture。

### W02 · P2 · 辅助标签先加载、后重读 hash，记录可能不属于实际训练标签

定位：[k0_train.py:491](/workspace/carbon-league/code/k0_train.py:491)，实际 np.load 在 [464](/workspace/carbon-league/code/k0_train.py:464)。

新增 aux_identity 重新从路径读取文件 hash，而训练数组已在此前读入。若此窗口内辅助层被重新生成，训练用 A、记录用 B，后续恢复的身份检查反而认可 B。

受控替换：np.load 读完全零 A 后，把标签和 sidecar 合法重封为全一 B。真实一步训练的 death head 与 A 对照逐位相同，差 0.0；与 B 对照差 0.0139999837。checkpoint 却记录 B 的 hash，之后用 B 恢复也被接受。

建议：sidecar 校验、标签解析、身份记录使用同一不可变快照或同一 bytes。正常“两趟运行间换标签”的原反例已修，不与此单次读取窗口混记。

证据：[aux_race_results.json](k0/aux_race_results.json)、[probe_aux_race.py](k0/probe_aux_race.py)。未声称生产已发生并发替换。

### W03 · P2 · 考官依赖虽已复制，实际 import 可复用候选或父进程的模块缓存

定位：[cnet2_train.py:1660](/workspace/carbon-league/code/cnet2_train.py:1660)、[1720](/workspace/carbon-league/code/cnet2_train.py:1720)，关联 [eval_v53.py:194](/workspace/carbon-league/code/eval_v53.py:194)。

候选和考官在同一 Python 导入命名空间运行，且先加载候选。冻结依赖文件和 MD5 不会隔离 sys.modules；候选先导入的同名模块，或 fork 继承的模块缓存，可直接被考官复用。即使调整 sys.path，也不保证读取冻结副本。

真实完整对局反例：snapshot 的 v06_helper.py 与记录 MD5 始终不变；候选动作始终返回空动作。只给候选增加从另一目录导入同名 helper，考官就使用另一份模块，U 从 0.5 变成 0.7574977508；两次 4 局都 ok=true。

建议：约束考官为自包含制品，或真正隔离它的依赖命名空间及执行来源。不能把复制依赖当作实际执行身份的证明。

证据：[最终版 BC 结果](bc/results_10907a81.json)、[探针](bc/probe_10907a81.py)。真实 loader、完整双席对局；未发现现役自包含 Master2 包已发生此问题。

### W04 · P2 · 只递归冻结依赖代码，遗漏依赖模块所需的数据文件

定位：[cnet2_train.py:1613](/workspace/carbon-league/code/cnet2_train.py:1613)、[1640](/workspace/carbon-league/code/cnet2_train.py:1640)。

依赖 .py 的递归处理扫描 imports 和动态代码加载；数据字面量扫描只作用于顶层 examiner。helper 内相对于自身 __file__ 读取的 settings.json 等文件不会被复制。

反例：原考官导入同目录 v06_config.py，后者读取 settings.json，原 loader 正常。冻结后只有 .py，没有 JSON；真实 evaluator 4 局全部 FileNotFoundError，ok=false。

建议：完整处理代码与数据依赖闭包，或明确拒绝无法冻结的考官；在训练前实际加载快照作健康验证，避免训练结束选模时才发现不可用。

证据：[最终版 BC 结果](bc/results_10907a81.json)。该问题在最后追加的动态代码枚举后仍存在。

### W05 · P2 · generation 复用未核验实际 meta.json，可把健康 current 切到坏历史代

定位：[exit_merge.py:170](/workspace/carbon-league/code/exit_merge.py:170)。

复用检查核验 manifest self seal、core 和所有 .npy，但没有核验实际 meta.json 是否与 manifest.meta_sha256 相符。

真实文件链复现：发布 A、再发布健康 B；只损坏历史 A 的 meta.json。恢复 A 原始输入重发，发布器成功报告 sealed/reused，并把 current 从 B 切到 A；消费端随后报 exit generation meta seal mismatch。损坏 .npy 的对照已能正确拒绝并保留 current。

建议：切指针前验证 meta.json 存在且 hash 正确；任何复用核验失败都保留当前健康指针。

证据：[exit/results.json](exit/results.json)、[probe_exit.py](exit/probe_exit.py)。原 V02 的删除窗口已消失，此项是新复用路径的校验遗漏。

### W06 · P2 · 测试覆盖可伪装为正式配额来源，证书不标明诊断状态

定位：[certify_pack.py:195](/workspace/carbon-league/code/certify_pack.py:195)。

CERTIFY_PACK_TEST_CGROUP_FILE 和 CERTIFY_PACK_TEST_MOUNTINFO_FILE 可让认证读取普通文件，却仍标记 source=cgroup_v2；证书不记录覆盖来源，也不降为诊断。

无 stub 的真实子进程单步验证：实际容器为 4 CPU / 16 GiB；将两变量指向临时普通文件，工具以 --require-quota 正常退出 0、overall=PASS，证书却记为 1.5 CPU / 512 MiB，且看不出是测试数据。

建议：将测试注入移出正式入口，或强制标记 diagnostic、记录来源且禁止形成正式配额自证。问题是记录不等于真实约束，不是要求任意有限配额都必须等于平台配额。

证据：[真实环境与覆盖对照](quota/override_results.json)、[实际子进程证书](quota/override_real_stdout.json)、[probe_override_real.py](quota/probe_override_real.py)。只有单步烟测，不是平台完整资源认证。

### W07 · P2 · 优先最深 cgroup 挂载，遗漏其他挂载可见的更紧祖先限额

定位：[certify_pack.py:289](/workspace/carbon-league/code/certify_pack.py:289)，v1 同类规则在 [348](/workspace/carbon-league/code/certify_pack.py:348)。

同一 hierarchy 同时有完整根挂载和叶子 bind mount 时，代码只选最长 root 并遍历它，忽略完整根挂载中可见的祖先。

合成挂载、真实证书发射复现：实际父组 1.5 CPU / 512 MiB，叶组自身 8 CPU / 8 GiB，证书 PASS 却记录后者。单独 subtree 挂载正例和普通父子组场景均已通过，缺口限于多个视图的选择。

建议：聚合同一 hierarchy 可见的祖先约束，不能以最深挂载替代有效限额。

证据：[quota_results.json](quota/quota_results.json) 的 v2_duplicate_subtree_mount。只合成文件读取，没有操作真实 cgroup。

### W08 · P2 · hybrid 布局读取到 v2 任一控制器后提前返回，漏掉 v1 控制器

定位：[certify_pack.py:391](/workspace/carbon-league/code/certify_pack.py:391)。

CPU 在 v2、memory 在 v1 时，v2.read_any=true 导致整段提前返回，不再查 v1 memory。实际二者都有有限约束，结果 memory=null，--require-quota 误 FAIL。

建议：按控制器分别解析实际来源，而非将 v1/v2 作为整套互斥选项。也应分别记录 process_path 和来源。

证据：[quota_results.json](quota/quota_results.json) 的 hybrid_v2_cpu_v1_memory，仅 quota_self_proof 失败；其他健康对照通过。

### W09 · P2 · 动态加载的绝对路径被接受，但快照执行仍读取原路径

定位：[cnet2_train.py:1490](/workspace/carbon-league/code/cnet2_train.py:1490)，复制在 [1606](/workspace/carbon-league/code/cnet2_train.py:1606)，主源码原样写入在 [1657](/workspace/carbon-league/code/cnet2_train.py:1657)。这是最后追加 10907a81 的问题。

静态解析接受同目录绝对路径并复制目标，但源码中的 spec_from_file_location(..., '/原目录/dep.py') 没有改写，复制后仍从原绝对路径加载。

真实 freezer + fresh subprocess 反例：冻结 dep.py 为 VALUE=101，登记 MD5；原依赖改成 VALUE=20202 后，同一快照执行返回 20202。冻结依赖仍是 101，主快照 hash 不变。以 __file__ 为锚点的正对照两次都返回 101。

建议：拒绝不随快照迁移的绝对表达式；若采用改写，应分别绑定原制品和转换后真正执行制品的身份。静态“找到了文件”不等于运行“用了副本”。

证据：[absolute_results.json](dyn/absolute_results.json)、[probe_absolute.py](dyn/probe_absolute.py)。验证真实动态加载，无 stub；该探针不评估完整对战收益。

### W10 · P2 · 静态解析忽略函数形参遮蔽，把运行时目标误认成全局固定路径

定位：[cnet2_train.py:1530](/workspace/carbon-league/code/cnet2_train.py:1530)，名称回退查找在 [1278](/workspace/carbon-league/code/cnet2_train.py:1278)。

访问函数时只收集函数体赋值，没有把形参登记为局部未知绑定。若形参 target 与模块级 target 同名，函数内的 spec_from_file_location(..., target) 会被错误解析为全局固定路径，实际运行却使用调用者参数。

真实完整对局：全局 target 指向 good.py，被冻结并记录；函数 load(target) 实际收到环境指定的外部 actual.py。改变外部文件，U 从 0.5 变为 0.7574977508，两次都 ok=true；依赖记录只有 good.py，未包含真正执行文件。

建议：所有参数和局部绑定都应正确遮蔽外层名称；无法证明固定来源的运行时加载应在冻结阶段拒绝。应保守限定支持的语言子集，避免把不完整 AST 推断当作执行身份保证。

证据：[动态扫描结果](bc/dyn/results.json)、[动态探针](bc/dyn/probe.py)。普通 __file__ 锚定正例已通过，未将所有动态加载一概判坏。

另有 [exists 候选循环正例](bc/dyn/loop_results.json)：正确选取第一个存在的 sibling，真实 loader 在原目标后续替换后仍返回冻结版 marker。

### W11 · P3 · 快照统一改名丢失 policy_* 的 make_agent 加载约定

定位：[cnet2_train.py:1656](/workspace/carbon-league/code/cnet2_train.py:1656)，loader 约定在 [eval_v53.py:93](/workspace/carbon-league/code/eval_v53.py:93)。

合法 policy_factory.py 仅提供 make_agent，原 loader 正常。快照改名 examiner_snapshot.py 后不再满足 policy_ 前缀，loader 转而访问 module.agent，真实 evaluator 4 局全部 AttributeError。

建议：在独立快照目录保留原 basename，或显式保存并传递入口类型。当前提供 module.agent 的自包含 Master2 包不受此特定条件影响。

证据：[最终版 BC 结果](bc/results_10907a81.json) 的 factory_filename。

### W12 · P3 · 上轮 V11 的 seed 保留段注释仍未修正

定位：[stage1_teacher_gate.py:702](/workspace/carbon-league/code/stage1_teacher_gate.py:702)。

仍声明 995300–995699；默认 continuation 995400、step=298、M=8 可用到 995705。尚未进入 996000 起的考试段，不将注释误差视为已发生考试污染。采样 RNG seed 区间也不能单独证明 replay 数据隔离。

## 已通过的其他验证

- K0 隐式 LR 恢复 0.007、显式 .01，optimizer/effective/逐步日志一致；六类协议不一致均拒绝；init 单源 bytes 保护仍通过；同版连续/恢复参数差 0。
- V08 的大有限参数溢出反例现在因 180 个非有限概率退出；正常 screen 指标有限，单类 AUC 为 null；最终发射 allow_nan=False。
- 温度原外部对手反例：继承 CNET2_TEMP_KIND 后，--temp .2/1.0 分别产生 107/75 个动作，行为与不设置该环境值时各自一致；真实 spawn CLI 的 temp_cli/temp_eff/greedy/temp_kind_env 正确。
- learner/eval/snap 为独立缓存对象，temp_kind 为 true/false/false；训练任务省略角色仍维持原 per-kind 行为，交错调用不污染 eval。
- test_eval_temp.py 原样全通过；默认 greedy 与 T=1 greedy 的 128 个动作一致，其中 56 个非 STAY；T=0 毒化对照 2392 个动作全 STAY，证明测试有检出能力。test_clustered_se.py 7/7 通过。
- certify 原 5 种 cgroup 布局及 subtree-only 正例通过；实际当前容器读取 4 CPU / 16 GiB 正确。W07/W08 只针对额外布局，不把整项说成原样未修。

## 新模型包和数据检查

四个新增 m3s2g1/m3s2r1 的 A4/base 包：四份内嵌源码与权威代码及内嵌 MD5 一致，包 MD5 与提交说明一致，CONF 相同。量化数据长度、张量形状和数值有限性通过；g1 128 张量、r1 180 张量，仅缺旧权重允许缺少的 utility/wdl/margin 六个键。

epoch 元数据为 g1 A4=17/base=19、r1 A4=18/base=19，与提交说明对应。包内无 selection 记录，且未取得源 NPZ，因此本轮未独立认证赢家来源或对战收益。

9 份比赛索引 JSON 解析通过，各自无重复 ID。22 份新增 fable6 replay 均可解压、解析，含 300 步双席记录，终局奖励/状态与索引席位顺序对应，无重复 replay ID/文件字节。未重放模拟器逐步验证规则。

证据：[packs/results.json](packs/results.json)、[packs/probe.py](packs/probe.py)。

## 证据与范围

审查差分为 12 个代码文件、31 个数据路径。code 全差分已分线复核；新 pack 通过 AST/权重检查，避免直接执行大模型比赛。最后追加 cnet2_train.py 已独立检查并重新运行 BC 探针。

证据目录：/workspace/review-20261114-r2/。Python：/workspace/carbon-review-venv/bin/python。

- [K0 原项结果](k0/results.json)；[K0 原项探针](k0/probe_recheck.py)。
- [exit 全链结果](exit/results.json)。
- [最终版 BC 结果](bc/results_10907a81.json)。
- [eval 行为、缓存、spawn 结果](eval/inherited_temp_result.json)；[仓内温度测试日志](eval/test_eval_temp.log)；[SE 日志](eval/test_clustered_se.log)。
- [quota 布局矩阵](quota/quota_results.json)；[quota 覆盖来源探针](quota/probe_override_real.py)。

各项已注明真实执行部分、受控替代部分。未开展完整生产语料训练、模型收益确认、平台完整资源认证或远程部署。本报告不能作为这些环节已经完成的证据。
