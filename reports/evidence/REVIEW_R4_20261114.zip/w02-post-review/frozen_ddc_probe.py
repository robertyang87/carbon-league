import os,sys,json,hashlib,copy,io,contextlib,types
from pathlib import Path
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
os.environ['BC_DEVICE']='cpu'
sys.path.insert(0,'/workspace/carbon-league/code')
import numpy as np,torch
import importlib.util
sp=importlib.util.spec_from_file_location("audit_frozen_ddc",'/workspace/review-20261114-r4/fixes/w02_challenge/frozen_ddc_k0_train.py')
K=importlib.util.module_from_spec(sp);sp.loader.exec_module(K)
import cnet2_train as T
from cnet2_model import CNet2
from rl2_ppo_cnet2 import Cnet2Adapter
from fastsim import FastCarbon
from eval_v53 import CFG
from unittest.mock import patch
root=Path('/workspace/review-20261114-r4/fixes/w02_challenge/frozen_ddc_fixture');root.mkdir(exist_ok=True)
torch.set_num_threads(1);torch.manual_seed(123)
ad=Cnet2Adapter();net=CNet2(C=16,NB=1,D=16,NH=2,L=1,E=8,G=4)
w=ad.export(net);np.savez(root/'init.npz',**w)
act=ad.make_actor(w);sim=FastCarbon(CFG).reset(seed=4);sts=[act.new_game(0),act.new_game(1)];recs=[]
for i in range(3):
 outs=act.act(sts,[sim.obs(0),sim.obs(1)],np.random.default_rng(i),1.,False)
 recs.extend([outs[0][1],outs[1][1]]);sim.step(outs[0][0],outs[1][0])
buf=ad.build_buffer([recs]);N=buf.n
D={'y':buf.d['y'],'gid':np.zeros(N,dtype=np.int64)}
np.save(root/'u_raw.npy',np.full(N,.6,np.float32));np.save(root/'gid.npy',D['gid']);np.save(root/'step.npy',np.arange(N));
np.save(root/'aux_die.npy',np.zeros((N,10,3),np.float32));np.save(root/'aux_die_m.npy',np.ones((N,10,3),np.uint8))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
fields={k:{'file':k+'.npy','sha256':sha(root/(k+'.npy'))} for k in ('u_raw','gid','step')}
man={'generation':'g-1','cfg_fp':'cfg-A','total':N,'fields':fields};(root/'manifest.json').write_text(json.dumps(man))
meta={'dataset_source':str(root),'games':[{'gi':0,'file':'fixture_no_replay'}]}
sc={'format':K.AUX_FORMAT,'base_generation':'g-1','lineage':'cfg-A','rows':N,'row_key':{'fields':['gid','step'],'sha256':K.row_key_sha256(str(root),man)},'games':[{'gi':0,'file':'fixture_no_replay'}],'files':{}}
for k in ('aux_die.npy','aux_die_m.npy'):
 a=np.load(root/k);sc['files'][k]={'sha256':sha(root/k),'shape':list(a.shape),'dtype':str(a.dtype)}
(root/'k0_aux.json').write_text(json.dumps(sc))
base=['--data',str(root),'--device','cpu','--bs','2','--seed','7']

def call(name,args,hook=None):
 out=root/(name+'.pt');argv=['k0']+base+['--out',str(out)]+args
 saved=io.StringIO();error=None
 try:
  with patch.object(sys,'argv',argv),patch.object(T,'load',return_value=(D,np.zeros(N,bool),meta)),patch.object(T,'fetch',side_effect=lambda d,idx:buf.batch(idx,torch.device('cpu'))),patch.object(T,'to_dev',side_effect=lambda b,aug:b),contextlib.redirect_stdout(saved):
   if hook:
    with patch.object(K,'_read_bytes',side_effect=hook):K.main()
   else:K.main()
 except BaseException as e:error=repr(e)
 ck=torch.load(out,weights_only=False) if out.exists() else None
 return {'name':name,'error':error,'ck':ck,'text':saved.getvalue(),'out':out}

def install(v):
 np.save(root/'aux_die.npy',np.full((N,10,3),v,np.float32))
 sc['files']['aux_die.npy']['sha256']=sha(root/'aux_die.npy')
 (root/'k0_aux.json').write_text(json.dumps(sc))
def hdiff(a,b):
 return max(float((a['ck']['death_head'][k]-b['ck']['death_head'][k]).abs().max()) for k in a['ck']['death_head'])
args=['--init',str(root/'init.npz'),'--max-updates','1','--lr','.007']
install(0);hashA=sha(root/'aux_die.npy');ctrlA=call('ctrlA',args)
install(1);hashB=sha(root/'aux_die.npy');ctrlB=call('ctrlB',args)
install(0)
load0=np.load; swapped=[]
def load_swap(path,*a,**kw):
 z=load0(path,*a,**kw)
 if isinstance(z,np.ndarray) and z.shape==(N,10,3) and z.dtype==np.float32 and not swapped:
  swapped.append(True);install(1)
 return z
with patch.object(np,'load',side_effect=load_swap):race=call('race',args)
res=call('resume',['--resume',str(race['out']),'--max-updates','2'])
R={'race_error':race['error'],'loaded_labels_A_hash':hashA,'recorded_labels_hash':race['ck']['effective']['aux']['files_sha256']['aux_die.npy'],'on_disk_labels_B_hash':hashB,'race_vs_A_death_maxdiff':hdiff(race,ctrlA),'race_vs_B_death_maxdiff':hdiff(race,ctrlB),'resume_B_error':res['error'],'resume_B_accepted':res['ck'] is not None,'swapped_once':len(swapped)}
Path('/workspace/review-20261114-r4/fixes/w02_challenge/frozen_ddc_results.json').write_text(json.dumps(R,indent=2)+'\n')
print(json.dumps(R,indent=2))

assert R["swapped_once"]==1
assert R["race_vs_A_death_maxdiff"]==0
assert R["race_error"] is None
assert R["recorded_labels_hash"]==R['on_disk_labels_B_hash']
assert R["resume_B_accepted"] is True
