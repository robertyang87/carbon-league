#!/usr/bin/env python3
"""Reproduce X06 and the builder/gate root-feature positive control.

Read-only repository access; all generated files live below --out.
Requires the reviewed source files (907c1059, also unchanged at ddc88081).
"""
import argparse
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import numpy as np


SOURCE_REV = "907c105965c8429919201e4d7b84ca8fb93ae0bc"
REPLAY = "data/carago1_corpus/003b13528e3e0a2c6921b03c8b3130b9-1.json.gz"


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--repo", default="/workspace/carbon-league")
    ap.add_argument("--out", default=str(Path(__file__).parent / "repro_join"))
    args = ap.parse_args()
    repo, out = Path(args.repo).resolve(), Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)

    def blob(path):
        return subprocess.check_output(
            ["git", "show", f"{SOURCE_REV}:{path}"], cwd=repo)

    for name in ("cnet2_build.py", "k0_annotate.py", "stage1_teacher_gate.py",
                 "cnet2_feat.py", "fastsim.py"):
        current = (repo / "code" / name).read_bytes()
        assert current == blob("code/" + name), f"source differs from reviewed version: {name}"
    sys.path.insert(0, str(repo / "code"))
    import cnet2_build as B
    import k0_annotate as A
    import stage1_teacher_gate as G

    replay = out / "replay.json.gz"
    replay.write_bytes(blob(REPLAY))
    with gzip.open(replay) as fh:
        data = json.load(fh)
    assert len(data["steps"]) == 300
    B.STEP_MIN, B.STEP_MAX = 200, 201
    build = out / "two_seat_build.npz"
    returned = B._build_game((str(replay), [0, 1], 0, [2, 2], [0., 0.], str(build)))
    with np.load(build) as z:
        roots, ft = A.enumerate_roots(str(replay), 200, 202)
        keys = list(zip(z["gid"].tolist(), z["step"].tolist()))
        counts = Counter(keys)
        result = {
            "head": SOURCE_REV,
            "replay_source": REPLAY,
            "replay_sha256": hashlib.sha256(replay.read_bytes()).hexdigest(),
            "builder_return": returned,
            "fields": z.files,
            "builder_gid_step": [list(k) for k in keys],
            "builder_gid_step_count": [[list(k), n] for k, n in counts.items()],
            "annotation_gid_step_seat": [[0, *root] for root in roots],
            "first_terminal_step": ft,
            "feature_has_seat": "seat" in z.files,
        }
        assert keys == [(0, 200), (0, 201), (0, 200), (0, 201)]
        assert all(n == 2 for n in counts.values())
        assert roots == [(200, 0), (200, 1), (201, 0), (201, 1)]
        assert "seat" not in z.files
        alignment = []
        for seat in (0, 1):
            for step in (200, 201):
                scene = G.extract_scene({
                    "game": "fixture", "path": str(replay),
                    "step": step, "me": seat, "ft": ft})
                index = seat * 2 + step - 200
                x = scene["x_me"]
                differences = {
                    k: int(np.count_nonzero(z[k][index] != np.asarray(x[k], dtype=z[k].dtype)))
                    for k in x if k in z.files
                }
                assert len(differences) == 9
                assert all(n == 0 for n in differences.values()), differences
                alignment.append({"seat": seat, "step": step,
                                  "differing_entries": differences})
    (out / "join_key_probe.json").write_text(json.dumps(result, indent=2) + "\n")
    (out / "root_feature_alignment.json").write_text(json.dumps(alignment, indent=2) + "\n")
    print(json.dumps({"out": str(out), "duplicate_gid_step_keys": len(counts),
                      "root_feature_comparisons": 36, "all_equal": True}, indent=2))


if __name__ == "__main__":
    main()
