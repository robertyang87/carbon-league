# Cross-entry review, frozen head 907c105965c8429919201e4d7b84ca8fb93ae0bc

Scope: 496ee1cc..907c1059; read-only repository inspection, temporary probes outside the repository. No deployment or source edits.

## Reproduce

The scripts create their output directories, read the pinned replay/data blobs via `git show`, and verify that imported source files match the reviewed source version. They work on the data-only fast-forward to ddc88081 without a checkout. Run:

```sh
/workspace/carbon-review-venv/bin/python /workspace/review-20261114-r4/integration/probe_join_alignment.py
/workspace/carbon-review-venv/bin/python /workspace/review-20261114-r4/integration/probe_registry.py
```

Optional `--repo PATH` and `--out PATH` override the repository and generated-artifact directories. Default outputs are `repro_join/` and `repro_registry/` beside the scripts. X06 is the join key reproduction, X10 is the registry identity reproduction. X02's executable temperature fixture is the sibling `distill/probe.py` cited below.

## Findings

### P2: certified train-temperature distribution is not consumed by distillation

Locations: `code/k0_distill.py:404-411`, `:161-180`, `:525-527`; producer config `code/k0_annotate.py:175-182`; registration `reports/K0_ROUND2_RULING_20261114.md:48,71`.

Annotator records `train_temp`, deliberately stores raw q, and states that downstream consumers must derive q**train_temp when appropriate. The gate certifies exactly normalized q**train_temp. Distill has only the inner Q-temperature `q_temp`, validates the stored raw q, and always trains that raw q. It neither reads nor refuses train_temp != 1. With a sealed consumer-format fixture explicitly declaring train_temp=2, its loader accepts and returns [0.6462812224, 0.3537187776] instead of [0.7694955688, 0.2305044312]. The default train_temp=1 control agrees.

The existing `--q-temp` flag is not an equivalent workaround: halving Q temperature yields [0.7315954920, 0.2684045080] because the prior remains P_A**0.5. Exponentiating q also changes the prior exponent. The C arm must undergo the same registered transformation after Q flattening to retain the one-variable comparison.

Evidence: sibling agent's executable `/workspace/review-20261114-r4/distill/probe.py` and `results.json` (`temperature`); independent formula check `temperature_formula.json`. This is a self-built joined-format consumer fixture, NOT a claim that the unimplemented real join ran. Default production tau=1 is unaffected; any nondefault registered tau silently trains an uncertified target. Fix by carrying a validated explicit train_temp/config identity through join, consuming it for S and C, and binding it in student provenance; until implemented, refuse nondefault tau rather than accept it.

### P2: new join specification declares a non-unique and generation-local key

Locations: `reports/K0_ROUND2_RULING_20261114.md:74`; `code/k0_annotate.py:203-205,247-259`; `code/cnet2_build.py:340-391`; consumer `code/k0_distill.py:327-335`.

The newly required join says `(gid, step)` is 1:1 and then verifies seat. Both producers use one gid per replay and have both seats at a given step. Annotator rows are step-major/seat-minor; builder rows are seat-major/step-minor and have no seat field. Their gids are independently assigned enumeration positions, so gid is not a cross-generation game identity either. The current consumer compares bundle seats only to each other, and compares only gid/step against feature rows.

Actual replay `data/carago1_corpus/003b13528e3e0a2c6921b03c8b3130b9-1.json.gz` (300 frames), through real `_build_game` at steps 200 and 201 with both seats, produces `(gid,step)=[(0,200),(0,201),(0,200),(0,201)]`. The real annotation enumerator produces `(gid,step,seat)=[(0,200,0),(0,200,1),(0,201,0),(0,201,1)]`. Thus a strict 1:1 join fails; deduplication or a positional join risks wrong-seat targets. This is a defect in the newly accepted specification, not a duplicate report that join itself is absent (absence is explicitly disclosed).

Evidence: `join_key_probe.json`, `two_seat_build.npz`, locally extracted `replay.json.gz`. Require mapping each generation's gid through its replay-ID table, joining on stable `(game_id,step,seat)`, and explicitly sealing/checking feature seat in the consumer. Unknown/missing/duplicate keys must reject.

## Passed / correctly constrained

- Latest ruling supplement K-prime requires final four-condition joint power, each arm's planned effect and variability, and a named binding constraint. M-prime now requires the cluster CI lower bound of Delta_S > 0; the former weaker point-estimate rule is expressly superseded.
- J makes the distribution q gate an explicit startup prerequisite. L withdraws the 1/20 significance claim. N correctly distinguishes examination sampling noise from unmeasured training noise.
- Ruling line 83 explicitly calls N=323 the **teacher-line** formal split. It does not replace the student experiment's still-to-be-locked joint-power N.
- Missing annotation-to-distill join is explicitly disclosed and blocks calibration/pilot startup. Do not report it as an undisclosed directly runnable path.
- Parent checkpoint identity is checked against annotation teacher_weights_md5 before student initialization (distill lines 554-563). Default teacher style is 2 in annotation and duel. Join must preserve/check that identity rather than inherit arbitrary historical replay style labels.
- On the same real replay, both seats at steps 200/201 have exact builder-vs-extract_scene equality for maps, scalar features, token fields, and all three history fields after casting to builder dtypes. `root_feature_alignment.json` records zero differing entries for all 36 checks. This does not validate candidate-dependent uf/mf/legal: sibling distill review has an independent P1 there.

## Limits

No formal teacher q gate, training experiment, real join, or production deployment was run. Statistical design rules are checked at document level, not claimed experimentally passed. Other agents independently audit each new entry script and the older fixes.

## Late data-only commit ddc88081 (read through git show; source stayed 907c1059)

### P2: consumed registry collapses all replay identities to `selfplay`

`data/k0_consumed_gen1r_shard1_registry.json:17-24` has 200 unique numeric games and 200 distinct filenames, but all 200 `replay_id` fields are the same string `selfplay`. The actual `stage1_teacher_gate.game_id_of` consumer retains the full stem, e.g. `selfplay-994400`. All 200 fields disagree with that canonical ID. If the registry is projected to its explicit replay_id field for isolation, a deliberately inserted test ID `selfplay-994400` has intersection zero with the recorded registry but intersection one with the actual registry. Require full stem IDs, uniqueness, ID-to-file agreement, and rerun the recorded checks.

This does **not** establish leakage in the current 323-game cut: its historical corpus IDs have zero intersection with the correctly reconstructed 200 selfplay IDs too. Numeric game and full path are still present, so the bad field is repairable. Evidence: `ddc88081/registry_key_probe.json` and `checks.json`.

Rechecked data facts: test=323 unique, train=1202 unique, disjoint, union size=1525; allocation totals 323, stratum_counts totals 1525; registry/test/train file MD5s match all companion declarations. The original pool, 118 training IDs, 34 pilot IDs and machine-local replay paths are absent here, so equality to the original pool, those two claimed intersections, and remote path existence were not independently verified.

### N=323 interpretation

The q branch in `stage1_teacher_gate.py:853-917` does not read the du pilot artifact; only the non-pilot du branch invokes `_verify_pilot_artifact` at line 1001. Therefore moving from a full-window du pilot to a terminal-window q test does not create the hypothesized q-artifact hard rejection. The number 323 is the accepted teacher split budget; the 80% normal-approximation calculation from full-window hard-du sigma is not evidence of the terminal soft-q gate's joint power. The document already reports the approximately 50% du conjunction power and distinguishes student N separately. No new runtime bug is claimed solely from this planning interpretation. `stageB_split_N323_verify.json` explicitly says `q_gate_started=false`.
