#!/usr/bin/env python3
"""Reproduce X10, verify the ddc88081 split counts and sealed-file MD5s.

Uses git show only; does not inspect or modify any remote machine.
No claim is made about the unavailable original pool or 118/34 ID lists.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys


DATA_REV = "ddc88081"
SOURCE_REV = "907c105965c8429919201e4d7b84ca8fb93ae0bc"
NAMES = ("k0_consumed_gen1r_shard1_registry", "stageB_split_N323",
         "stageB_split_N323_train", "stageB_split_N323_verify")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--repo", default="/workspace/carbon-league")
    ap.add_argument("--out", default=str(Path(__file__).parent / "repro_registry"))
    args = ap.parse_args()
    repo, out = Path(args.repo).resolve(), Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    full_rev = subprocess.check_output(
        ["git", "rev-parse", DATA_REV], cwd=repo, text=True).strip()
    objects, md5s = {}, {}
    for name in NAMES:
        raw = subprocess.check_output(["git", "show", f"{DATA_REV}:data/{name}.json"], cwd=repo)
        (out / f"{name}.json").write_bytes(raw)
        objects[name] = json.loads(raw)
        md5s[f"{name}.json"] = hashlib.md5(raw).hexdigest()

    source = subprocess.check_output(
        ["git", "show", f"{SOURCE_REV}:code/stage1_teacher_gate.py"], cwd=repo)
    assert (repo / "code/stage1_teacher_gate.py").read_bytes() == source
    sys.path.insert(0, str(repo / "code"))
    from stage1_teacher_gate import game_id_of

    reg, test, train, verify = (objects[name] for name in NAMES)
    test_ids = {x["id"] for x in test["games"]}
    train_ids = {x["id"] for x in train["games"]}
    rows = [{"game": x["game"], "recorded_replay_id": x["replay_id"],
             "consumer_game_id": game_id_of(x["file"])} for x in reg["games"]]
    recorded = {x["recorded_replay_id"] for x in rows}
    actual = {x["consumer_game_id"] for x in rows}
    checks = {
        "data_rev": full_rev,
        "n_test": len(test["games"]), "n_unique_test": len(test_ids),
        "n_train": len(train["games"]), "n_unique_train": len(train_ids),
        "intersection": len(test_ids & train_ids), "union": len(test_ids | train_ids),
        "reg_count": len(rows), "reg_unique_replay_id": len(recorded),
        "reg_id_values": sorted(recorded),
        "reg_unique_game": len({x["game"] for x in rows}),
        "reg_unique_basename_stems": len(actual),
        "test_registry_stem_overlap": len(test_ids & actual),
        "test_registry_currentkey_overlap": len(test_ids & recorded),
        "allocation_sum": sum(test["header"]["allocation"].values()),
        "pool_counts_sum": sum(test["header"]["stratum_counts"].values()),
        "md5s": md5s,
    }
    probe = {
        "mismatched_ids": sum(x["recorded_replay_id"] != x["consumer_game_id"] for x in rows),
        "count": len(rows), "example": rows[:3],
        "negative_control_current_test_overlap": len(test_ids & actual),
        "counterfactual_selfplay_994400_in_test": {
            "recorded_registry_intersection": len({"selfplay-994400"} & recorded),
            "actual_registry_intersection": len({"selfplay-994400"} & actual),
        },
    }
    assert checks["n_test"] == checks["n_unique_test"] == 323
    assert checks["n_train"] == checks["n_unique_train"] == 1202
    assert checks["intersection"] == 0 and checks["union"] == 1525
    assert checks["allocation_sum"] == 323 and checks["pool_counts_sum"] == 1525
    assert checks["reg_count"] == checks["reg_unique_game"] == len(actual) == 200
    assert recorded == {"selfplay"} and probe["mismatched_ids"] == 200
    assert checks["test_registry_stem_overlap"] == 0
    assert probe["counterfactual_selfplay_994400_in_test"] == {
        "recorded_registry_intersection": 0, "actual_registry_intersection": 1}
    for section, name in (("test", "stageB_split_N323"),
                          ("train", "stageB_split_N323_train"),
                          ("conditionE_registry", "k0_consumed_gen1r_shard1_registry")):
        assert verify[section]["md5"] == md5s[f"{name}.json"]
    assert train["header"]["test_file_md5"] == md5s["stageB_split_N323.json"]
    assert train["header"]["conditionE_registry_md5"] == md5s["k0_consumed_gen1r_shard1_registry.json"]
    assert verify["q_gate_started"] is False
    (out / "checks.json").write_text(json.dumps(checks, indent=2) + "\n")
    (out / "registry_key_probe.json").write_text(json.dumps(probe, indent=2) + "\n")
    print(json.dumps({"out": str(out), "mismatched_registry_ids": 200,
                      "current_test_registry_overlap": 0,
                      "split_count_and_hash_checks_pass": True}, indent=2))


if __name__ == "__main__":
    main()
