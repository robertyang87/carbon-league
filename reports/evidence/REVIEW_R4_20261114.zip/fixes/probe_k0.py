import os,sys,json,hashlib,copy,io,contextlib,types
from pathlib import Path
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
os.environ['BC_DEVICE']='cpu'
sys.path.insert(0,'/workspace/carbon-league/code')
import numpy as np,torch
import k0_train as K,cnet2_train as T
from cnet2_model import CNet2
from rl2_ppo_cnet2 import Cnet2Adapter
from fastsim import FastCarbon
from eval_v53 import CFG
from unittest.mock import patch
root=Path('/workspace/review-20261114-r4/fixes/k0-fixture-final');root.mkdir(exist_ok=True)
torch.set_num_threads(1);torch.manual_seed(123)
ad=Cnet2Adapter();net=CNet2(C=16,NB=1,D=16,NH=2,L=1,E=8,G=4)
w=ad.export(net);np.savez(root/'init.npz',**w)
act=ad.make_actor(w);sim=FastCarbon(CFG).reset(seed=4);sts=[act.new_game(0),act.new_game(1)];recs=[]
for i in range(3):
 outs=act.act(sts,[sim.obs(0),sim.obs(1)],np.random.default_rng(i),1.,False)
 recs.extend([outs[0][1],outs[1][1]]);sim.step(outs[0][0],outs[1][0])
buf=ad.build_buffer([recs]);N=buf.n
D={'y':buf.d['y'],'gid':np.arange(N,dtype=np.int64)}
np.save(root/'u_raw.npy',np.linspace(.1,.9,N,dtype=np.float32));np.save(root/'gid.npy',D['gid']);np.save(root/'step.npy',np.arange(N));
np.save(root/'aux_die.npy',np.zeros((N,10,3),np.float32));np.save(root/'aux_die_m.npy',np.ones((N,10,3),np.uint8))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
fields={k:{'file':k+'.npy','sha256':sha(root/(k+'.npy'))} for k in ('u_raw','gid','step')}
man={'generation':'g-1','cfg_fp':'cfg-A','total':N,'fields':fields};(root/'manifest.json').write_text(json.dumps(man))
meta={'dataset_source':str(root),'games':[{'gi':i,'file':f'fixture_{i}'} for i in range(N)]}
sc={'format':K.AUX_FORMAT,'base_generation':'g-1','lineage':'cfg-A','rows':N,'row_key':{'fields':['gid','step'],'sha256':K.row_key_sha256(str(root),man)},'games':[{'gi':i,'file':f'fixture_{i}'} for i in range(N)],'files':{}}
for k in ('aux_die.npy','aux_die_m.npy'):
 a=np.load(root/k);sc['files'][k]={'sha256':sha(root/k),'shape':list(a.shape),'dtype':str(a.dtype)}
(root/'k0_aux.json').write_text(json.dumps(sc))
base=['--data',str(root),'--device','cpu','--bs','2','--seed','7','--max-games','3']

def call(name,args,hook=None):
 out=root/(name+'.pt');argv=['k0']+base+['--out',str(out)]+args
 saved=io.StringIO();error=None;seen=[]
 try:
  with patch.object(sys,'argv',argv),patch.object(T,'load',return_value=(D,np.zeros(N,bool),meta)),patch.object(T,'fetch',side_effect=lambda d,idx:(seen.append(idx.tolist()) or buf.batch(idx,torch.device('cpu')))),patch.object(T,'to_dev',side_effect=lambda b,aug:b),contextlib.redirect_stdout(saved):
   if hook:
    with patch.object(K,'_read_bytes',side_effect=hook):K.main()
   else:K.main()
 except BaseException as e:error=repr(e)
 ck=torch.load(out,weights_only=False) if out.exists() else None
 return {'name':name,'error':error,'ck':ck,'text':saved.getvalue(),'out':out,'seen':seen}

import subprocess
Knew=K
Kold=types.ModuleType('k0_baseline');Kold.__file__='/workspace/carbon-league/code/k0_train.py'
exec(compile(subprocess.check_output(['git','-C','/workspace/carbon-league','show','b9997026:code/k0_train.py'],text=True),'k0_baseline.py','exec'),Kold.__dict__)
args=['--init',str(root/'init.npz'),'--lr','.007']
K=Kold
old1=call('old_1',args+['--max-updates','1'])
K=Knew
cross=call('cross_resume',['--resume',str(old1['out']),'--max-updates','4'])
migration=call('explicit_migration',['--resume',str(old1['out']),'--max-updates','4','--accept-unrecorded-subset'])
new1=call('new_1',args+['--max-updates','1'])
new2=call('new_2',args+['--max-updates','4'])
newr=call('new_resume',['--resume',str(new1['out']),'--max-updates','4'])
def maxdiff(a,b):
 return max(float((a['ck'][part][k]-b['ck'][part][k]).abs().max()) for part in ('backbone','u_head','death_head') for k in a['ck'][part])
# Make an internally complete checkpoint with a different recorded subset.
ck=copy.deepcopy(new1['ck']);ck['effective']['games_used_sha256']=hashlib.sha256(np.array([0,1,2],np.int64).tobytes()).hexdigest()
p=root/'different_subset_source.pt';torch.save(ck,p)
(p.parent/(p.name+'.complete.json')).write_text(json.dumps({'checkpoint':p.name,'sha256':sha(p),'updates':1,'complete':True}))
bad=call('changed_subset',['--resume',str(p),'--max-updates','4'])
badflag=call('changed_subset_flag',['--resume',str(p),'--max-updates','4','--accept-unrecorded-subset'])
R={'base':'496ee1cc','head':'907c1059','old_checkpoint_no_subset':{'error':cross['error'],'accepted':cross['ck'] is not None,'batches_read':cross['seen']},'explicit_migration':{'error':migration['error'],'accepted':migration['ck'] is not None,'record':migration['ck']['effective'].get('subset_migration') if migration['ck'] else None,'batches':migration['seen']},'same_new_protocol':{'error':newr['error'],'max_parameter_diff':maxdiff(new2,newr),'new_subset_hash':new1['ck']['effective']['games_used_sha256'],'resumed_subset_hash':newr['ck']['effective']['games_used_sha256']},'changed_recorded_subset':{'error':bad['error'],'accepted':bad['ck'] is not None,'batches':bad['seen']},'changed_recorded_subset_with_migration_flag':{'error':badflag['error'],'accepted':badflag['ck'] is not None}}
assert cross['ck'] is None and 'no games_used_sha256' in cross['error'] and not cross['seen']
assert migration['ck'] is not None and migration['ck']['effective']['subset_migration']['accept_unrecorded_subset']
assert maxdiff(new2,newr)==0
assert bad['ck'] is None and badflag['ck'] is None and 'subset identity' in bad['error']
Path('/workspace/review-20261114-r4/fixes/k0_results.json').write_text(json.dumps(R,indent=2)+'\n')
print(json.dumps(R,indent=2))
