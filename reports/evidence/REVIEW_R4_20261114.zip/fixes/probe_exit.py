import os,sys,json,tempfile,copy,contextlib,io
from pathlib import Path
from unittest.mock import patch
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
sys.dont_write_bytecode=True
sys.path.insert(0,'/workspace/carbon-league/code')
import numpy as np
import exit_gen as EG,exit_merge as EM,cnet2_exit_train as ET,cnet2_feat as F
from cnet2_build import FIELDS
from fastsim import FastCarbon
from eval_v53 import CFG
from types import SimpleNamespace
outdir=Path('/workspace/review-20261114-r4/fixes/exit');outdir.mkdir(exist_ok=True)
root=Path(tempfile.mkdtemp(prefix='fixture-',dir=outdir))
results={'base':'496ee1cc','head':'907c1059','root':str(root),'checks':{}}
log=io.StringIO()
def record(rec):
 sim=FastCarbon(CFG).reset(seed=1);f=F.Feat(0);x=f.observe(sim.obs(0))
 rows={k:[] for k in list(FIELDS)+list(EG.EXTRA)}
 ag=SimpleNamespace(state={'f':f,'x':x,'y_net':f.labels({}),'acts_out':{},'rec':rec})
 EG.record(ag,0,sim,rows);rows['value']=[0.];rows['gid']=[0];rows['step']=[0]
 return {k:np.asarray(v).astype((FIELDS.get(k) or EG.EXTRA[k])[0]) for k,v in rows.items()}
plain=record(None)
partial=record({'slot':10,'q':np.array([0.,np.nan,np.nan,np.nan,np.nan],np.float32)})
empty=record({'slot':10,'q':np.full(5,np.nan,np.float32)})
def run_load(name,a):
 sd=root/name/'shards';sd.mkdir(parents=True);np.savez(sd/'1_self_s0.npz',**a)
 out=sd.parent/'merged'
 with contextlib.redirect_stdout(log):
  EM.main(str(out),[str(sd)]);gen=ET.resolve_exit_arg(str(out))
  try:
   d,_,_=ET.load_exit(gen)
   result={'accepted':True,'rows':len(d['gid']),'q_nan_preserved':int(np.isnan(d['q']).sum())}
  except SystemExit as e:result={'accepted':False,'error':str(e)}
 results['checks'][name]=result
 return out,sd
out,sd=run_load('unsearched_nan',plain)
run_load('searched_partial_nan',partial)
run_load('searched_no_evaluation',empty)
for name,mut in [
 ('reject_q_inf',lambda a:a['q'].__setitem__((0,0),np.inf)),
 ('reject_pi_nan',lambda a:a['pi'].__setitem__((0,10,0),np.nan)),
 ('reject_positive_pi_unseen',lambda a:a['pi'].__setitem__((0,10,1),.2)),
 ('reject_claim_no_q',lambda a:a['q'].__setitem__((0,0),np.nan)),
 ('reject_finite_unclaimed',lambda a:a['pi_slot'].__setitem__(0,-1)),
 ('reject_finite_unsearched',lambda a:a['searched'].__setitem__(0,False)),
 ('reject_ps_out_of_range',lambda a:a['pi_slot'].__setitem__(0,12))]:
 a={k:v.copy() for k,v in partial.items()};mut(a);run_load(name,a)
p1=json.loads((out/'current.json').read_text());g1=out/p1['dir'];m1=(g1/'manifest.json').read_bytes()
with contextlib.redirect_stdout(log):
 EM.main(str(out),[str(sd)])
 ET._verify_exit_generation(str(g1),p1)
p2=json.loads((out/'current.json').read_text())
results['checks']['identical_republish']={'same_generation':p1['generation']==p2['generation'],'manifest_bytes_unchanged':m1==(g1/'manifest.json').read_bytes(),'old_pointer_still_verifies':True}
# Old landing-fault location is never reached when reusing existing data.
orig_replace=os.replace;hits=[]
def fail_landing(src,dst):
 if Path(src).name.startswith('.staging-exit-'):
  hits.append(str(dst));raise OSError('injected new-generation landing failure')
 return orig_replace(src,dst)
with contextlib.redirect_stdout(log),patch.object(EM.os,'replace',fail_landing):EM.main(str(out),[str(sd)])
results['checks']['identical_no_landing']={'landing_attempts':len(hits),'old_gen_exists':g1.exists()}
# New content failure preserves old pointer and generation.
new={k:v.copy() for k,v in plain.items()};new['value'][:]=.25;np.savez(sd/'1_self_s0.npz',**new)
oldptr=(out/'current.json').read_bytes()
try:
 with contextlib.redirect_stdout(log),patch.object(EM.os,'replace',fail_landing):EM.main(str(out),[str(sd)])
except OSError as e:err=str(e)
with contextlib.redirect_stdout(log):ET._verify_exit_generation(str(g1),p1)
results['checks']['interrupted_new_publish']={'error':err,'old_pointer_unchanged':oldptr==(out/'current.json').read_bytes(),'old_generation_verifies':True}
# Publish healthy B; A is retained as immutable historical generation.
with contextlib.redirect_stdout(log):EM.main(str(out),[str(sd)]);ET.resolve_exit_arg(str(out))
pB=json.loads((out/'current.json').read_text())
# Corrupt A metadata only, leave its self-sealed manifest and every .npy intact.
(g1/'meta.json').write_text('{"corrupted":true}')
np.savez(sd/'1_self_s0.npz',**plain)
publish_error=None
try:
 with contextlib.redirect_stdout(log):EM.main(str(out),[str(sd)])
except BaseException as e:publish_error=repr(e)
pAfter=json.loads((out/'current.json').read_text())
try:
 with contextlib.redirect_stdout(log):ET.resolve_exit_arg(str(out))
 consumer_error=None
except BaseException as e:consumer_error=repr(e)
results['checks']['corrupt_historical_meta_republish']={'publish_error':publish_error,'healthy_B_generation':pB['generation'],'after_generation':pAfter['generation'],'changed_to_corrupt_A':pAfter['generation']==p1['generation'],'consumer_error':consumer_error}
# Symmetric .npy corruption is refused by new reuse branch.
out2,sd2=run_load('field_corrupt_control',plain)
pC=json.loads((out2/'current.json').read_text());gc=out2/pC['dir'];before=(out2/'current.json').read_bytes()
with open(gc/'value.npy','ab') as f:f.write(b'x')
try:
 with contextlib.redirect_stdout(log):EM.main(str(out2),[str(sd2)])
 field_error=None
except BaseException as e:field_error=repr(e)
results['checks']['corrupt_field_republish']={'error':field_error,'pointer_unchanged':before==(out2/'current.json').read_bytes()}
assert publish_error is not None and pAfter['generation']==pB['generation'] and consumer_error is None
(outdir/'results.json').write_text(json.dumps(results,indent=2)+'\n')
(outdir/'probe.log').write_text(log.getvalue())
print(json.dumps(results,indent=2))
