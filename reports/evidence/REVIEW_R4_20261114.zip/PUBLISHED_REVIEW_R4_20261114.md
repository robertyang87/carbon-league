# Carbon League 全局复审 r4

日期：2026-11-14。仓库：`robertyang87/carbon-league`。

- 上轮基线：`496ee1cce2238f6174396577f7a71e7436e939f0`。
- 本轮源码冻结：`907c105965c8429919201e4d7b84ca8fb93ae0bc`。
- 最终同步：`ddc8808124261751724d060221f3d29c1f869eab`。最后一笔只增加四份数据清单，源码与复现版相同。
- 审查阶段只读：同步本地 main，未修改仓库源码、未部署。复审完成后按用户要求，将本报告与证据包单独提交入库。

证据下载：[REVIEW_R4_20261114.zip](evidence/REVIEW_R4_20261114.zip)。ZIP 内保留冻结报告、探针与结果。本文结论只覆盖上述复审版本；`ddc88081` 之后的新修复需另行复核，不能由本报告推断仍未修复。

## 交付时补充核验：W02

入库前核对发现，W02 修复提交 `d3a3f79b` 晚于冻结基线 `ddc88081`。同型反例对两版复跑：冻结版训练标签 A、记录 B 身份且允许 B 恢复；修复版训练 A、记录 A 身份，并因 `aux.sidecar_sha256` 不一致拒绝 B 恢复。**W02 原反例在 d3a3f79b 修复后关闭**。下文 W 矩阵描述冻结版状态，保留以便审计。新增证据位于 ZIP 的 `w02-post-review/`。后续冻结器与 join 新提交本次仅保留，未在本文宣布通过复审。

## 结论

新增 **1 P1、7 P2、2 P3**，编号 **X01–X10**。当前 K0 蒸馏实现不能据此启动正式训练或认定配方已验收：X01 会把合法候选动作当作非法动作计算损失；X02、X06 则使认证目标和数据连接契约不成立。标注与测量的身份绑定也需修复。

这不推翻 PPO 或教师蒸馏路线的研究价值。问题发生在数据、训练和测量实现，不能把当前产物的好坏直接归因为算法路线的上限。

旧问题单独对账：**W01/W05/W06/W07/W08 原反例关闭；W02/W03/W04/W09/W10/W11 保留；W12 已批准 fix-on-touch 缓修**。本轮没有把已经关闭的 V 条目重新列成未修复。J/K′/L/M′/N 文档修订已落实，仍不等于实验结论已获得。

## 新问题

### X01 · P1 · 蒸馏没有按每个候选动作重算 Prefix

位置：`code/k0_distill.py:655`、`:664`、`:665`；`code/cnet2_model.py:232`。

`expanded_batch()` 将一个根的所有特征重复 K 次，只替换 `y`。`decode()` 的动作嵌入确实会随前一个动作变化，但现金、占位、单位关系特征和合法动作掩码来自既有 `uf/mf/legal`，不会随候选重算。注释声称“each candidate … OWN prefix”，实际未满足。

复现采用真实 FastCarbon、Feat、Prefix、CNet2 与 `k0_distill.main()`：step=200、cash=40、两个基地，候选为 `(招募,停)` 与 `(停,招募)`。二者各自合法；复用第一臂前缀后，第二臂的招募被错误 mask。实际 CE 为 **353,718,778.785733**；逐候选重放所得正确 CE 为 **1.620111730**。训练退出码仍为 0，发布了 checkpoint 和 complete 标记。相同前缀正例误差为 0。

修复：为每个候选从同一根状态独立重放 Prefix，生成候选各自的 `uf/mf/legal`；或在封存数据中提供等价、可验证的候选级特征。现有 consumer 格式只有根级前缀特征，单纯做 join 不会修复此问题。训练前应检查候选在其自身前缀下合法。

验收：上述两臂的联合 log-prob、CE 与独立 Prefix 计算一致；加入占位冲突与共享预算候选；真实标注→join→加载→短训必须覆盖这些候选。

证据：`distill/probe.py`、`distill/results.json`、`distill/main.stdout`。主审独立重跑同一脚本，结果一致。消费封存集为受控构造，不冒称尚不存在的真实 join 已通。

### X02 · P2 · 认证 train_temp 与实际蒸馏目标脱节

位置：`code/k0_distill.py:161`、`:404`、`:412`；`code/k0_annotate.py:175`；`code/stage1_teacher_gate.py:558`。

标注保存 raw q，正式 q 闸认证的是 `normalize(q ** train_temp)`；蒸馏只重建 raw q，并只要求配置 hash 存在，没有消费或核验实际 `train_temp`。

实测登记 `train_temp=2` 的封存集被接受，训练目标仍为 `[0.6462812224, 0.3537187776]`，认证目标应为 `[0.7694955688, 0.2305044312]`，最大差 **0.1232143464**。默认 1 正确；问题限于非默认温度或身份缺失。将 `--q-temp` 减半不能替代，因为它只改变 Q 的指数，未同时改变先验指数。

修复：join 和 consumer 显式携带、校验认证配置及 `train_temp`，对 S/C 两臂按登记语义构造目标；不支持非 1 时明确拒绝，不能静默忽略。验收至少覆盖 1、2 和配置不一致拒收。

证据：`distill/results.json:temperature`、`integration/temperature_formula.json`。

### X03 · P2 · 标注恢复身份缺少回放内容和执行代码

位置：`code/k0_annotate.py:266`、`:382`、`:563`。

run identity 包含配置、权重、抽样和根集合，却不含实际 replay 内容 hash、执行代码身份。代码 hash 到发布阶段才读取。因此相同 ID/根集合下，修改回放或教师实现后恢复，会继续接受旧 shard；还可能给旧标签附上新代码指纹。

实测更改同 ID replay 内容、保持根集合不变，identity 相等，旧 generation 被直接复用；模拟发布时教师代码指纹变化后，旧标签被封存到带新指纹的 generation。后者为代码身份替换探针，未声称运行了另一份教师实现。

修复：开工前冻结执行代码与每局 replay 身份，加入 run/shard identity；恢复逐项核验。发布只能使用已冻结、与计算一致的身份。换代码或回放必须新代重算或明确拒绝。

证据：`annotate/probe.py`、`annotate/results.json:changed_replay_resume/changed_code_resume`。

### X04 · P2 · 标注和测量的 hash 没有绑定实际读取的字节

位置：`code/k0_annotate.py:239`、`:285`；`code/k0_duel.py:273`、`:300`、`:307`、`:327`。

两个入口先按路径计算权重 hash，再由 worker 按原路径加载。duel 也在校验 replay 后重新按路径提取场景。输入被正常更新或原子替换时，记录身份可能与实际执行对象不同。

实证：

- annotator 记录权重 A；加载前换 B，真实教师 Q 从 **0.98201379** 变为 **0.01798621**，manifest 仍记录 A。
- duel 记录 STAY 权重；实际加载 RECRUIT，ΔU 为 **−0.2574977508**，与真实 RECRUIT 对照一致，所声明 STAY 应为 0。
- duel 在 `load_roots()` 后替换 replay，无需修改执行函数，场景现金从 `[80,80]` 变为 `[50,80]`，结果仍带旧 roots SHA。

修复：一次读取不可变字节，在同一字节缓冲上计算 hash 和解析；大型回放可冻结副本/内容寻址快照后由 worker 消费。仅先后各 hash 一遍仍不能证明解析对象相同。不同 worker 必须消费同一冻结版本。

证据：`annotate/results.json:weight_swap`、`duel/probe_results.json:checkpoint_identity_window/replay_identity_window`。权重探针用 hook 精确安排合法文件替换，模型推理、模拟和统计均为真实实现。

### X05 · P2 · 新 annotator 复用了 W05 的旧缺陷

位置：`code/k0_annotate.py:618`、`:634`。

复用已存在 generation 时校验了 manifest 和数组文件，遗漏 `meta.json` 的实际 seal。历史 A 的 meta 损坏、当前指向健康 B 时，重发 A 返回 `reused=true` 并切回坏 A；消费端随后才报 meta seal mismatch，健康指针已被替换。

同类旧入口 `exit_merge.py` 的 W05 本轮已修好并复测通过；此项是新入口遗漏，不能回填成“W05 未修”。

修复：翻转 current 前对已落地代执行完整验证，包括 meta 实际字节。验收必须保留“坏历史 A / 健康 current B / 重发 A”反例，失败后 current 仍指 B。

证据：`annotate/results.json:reuse_corrupt_meta`；对照 `fixes/exit/results.json`。

### X06 · P2 · join 新规格的连接键不唯一且跨代 gid 不同义

位置：`reports/K0_ROUND2_RULING_20261114.md:74`；`code/cnet2_build.py:340`、`:391`；`code/k0_annotate.py:203`、`:247`。

补件规定按 `(gid,step)` 1:1 连接再验 seat。真实 builder 同一局同一步双席共享 `(gid,step)`，且特征代没有 seat 列；annotator 则明确保留两席。两个 generation 的 gid 又分别由自身局表枚举，不能直接等同。

真实仓内 replay 复现：builder 四行键为 `(0,200),(0,201),(0,200),(0,201)`；标注为相应四个 `(0,step,seat)`。因此规格中的 1:1 连接前提不成立。

修复：先按稳定 replay ID 与源内容身份对齐局表，再按 `(game_id,step,seat)` 连接；build/join/consumer 显式提供并核验 seat，拒绝多对多、缺行和身份冲突。两个局表顺序相反且双席状态不对称应作为验收用例。

已披露的“join 尚未实现”按已知待办记录；本项只指出新增补件规格本身的错误。

证据：`integration/join_key_probe.json`。根特征与历史字段的 36 项对照相等，不能据此推导候选前缀正确，后者见 X01。

### X07 · P2 · 测量器接受 NaN 权重并发布正常有限指标

位置：`code/k0_duel.py:238`；`code/cnet2_np.py:211`。

权重加载没有有限性门。NaN logits 经 argmax 可以变成普通离散动作，因此最终 U 有限不能证明被测模型有效。

将真实小网 `bhead.bias` 置 NaN，实际 duel CLI 退出码 0、无 stderr、发布 **U=0.5、ΔU=0**。这会把损坏模型伪装成正常测量对象。

修复：对加载的所有数值参数做有限性与结构校验；推理时遇到非有限 logits/输出必须拒绝该次测量，不能仅检查终局 U。验收保留正常同权重与不同权重正例。

证据：`duel/probe_results.json:nonfinite_checkpoint`、`duel/control_results.json`。

### X08 · P3 · 测量器允许同一 game ID 绑定不同回放版本

位置：`code/k0_duel.py:265`、`:273`、`:341`。

验证仅要求文件 basename 与 game 相同，缓存按 path，没有约束 `game → replay identity`。不同目录的 `game1.json.gz` 可提供不同内容，只要根 step 不同便被接受，最终聚成一局。实测两种局面被报为 **2 根 / 1 局**。

修复：同一 game 的所有根必须绑定相同回放内容；内容相同而路径不同可以允许。当前正常单版本清单不受影响，未发现本轮真实测量已经混入冲突回放。

证据：`duel/probe_results.json:same_game_two_replay_contents`。

### X09 · P3 · 标注自检和封存验证漏掉 q/priors 的 NaN

位置：`code/k0_annotate.py:475`。

负数比较和 `abs(sum-1)>tol` 不会拒绝 NaN。向正常 shard 的真实候选 q 或 priors 注入 NaN并重算数组 seal，经过 shard 校验、publish、14 个文件核验及实际加载仍被接受。Q 与 π 的 NaN 正确拒绝。

修复：真实候选的 q/priors 明确检查 finite、取值和归一化，padding 单独校验。Q_std 为诊断字段，另行定义可空语义。

此项降为 P3：没有证明当前教师自然产生这些 NaN；下游 distill 另有有限性门，未证明 NaN 已进入训练 loss。

证据：`annotate/nan_publish.py`、`annotate/nan_publish_results.json`。

### X10 · P2 · 新 Condition E 登记表把 200 局 replay_id 全写成 selfplay

位置：`data/k0_consumed_gen1r_shard1_registry.json:19` 起。

登记的 200 行虽然保留不同的 game 数字和完整路径，`replay_id` 却全部为 `selfplay`。实际 gate 的 ID 解析保留完整文件 stem，应为 `selfplay-994400` 至 `selfplay-994599`。若隔离消费者使用登记的 replay_id，200 局会塌成一个无效键。

反例把 `selfplay-994400` 放入待检集合：按登记 replay_id 求交为 0，按实际正确 ID 为 1。

修复：按生产消费者同一 ID 解析规则生成登记，强制记录数和唯一身份数同为 200；重算伴随 hash；以登记中任一局进入测试清单的反例证明拒绝。不能因为现有 test 都是历史 hash ID 就保留错误字段。

**当前 323 局 test 与修正后的 200 局集合交集仍为 0，未发现实际数据泄漏。**此项是隔离登记身份错误，不是已经发生泄漏的结论。

证据：`integration/ddc88081/checks.json`、`integration/ddc88081/registry_key_probe.json`。

## 旧 W 清单逐项状态

| ID | 原级别 | 本轮结论 | 证据/边界 |
|---|---|---|---|
| W01 | P2 | 原反例关闭 | 旧无 subset 身份默认拒绝；显式迁移记录留痕；已知不匹配有无旗都拒绝；新版连续/恢复参数差 0 |
| W02 | P2 | 仍复现 | aux 先读 A 后记 B hash，训练头与 A 对照差 0，B 恢复仍接受 |
| W03 | P2 | 保留 | 考官依赖共享 import 命名空间；代码和可达调用链未变 |
| W04 | P2 | 保留 | 考官依赖中的数据文件递归冻结遗漏；代码未变 |
| W05 | P2 | 原反例关闭 | exit_merge 拒绝坏历史 meta，健康 current 保持；正常复用/失败保全正例通过 |
| W06 | P2 | 原反例关闭 | 测试覆盖来源标记 test_override，require-quota 拒绝；真实子进程反例翻转 |
| W07 | P2 | 原反例关闭 | v1/v2 多挂载的可见祖先约束正确取最严值 |
| W08 | P2 | 原反例关闭 | 双向 hybrid 控制器都读取；unlimited 负例拒绝 |
| W09 | P2 | 保留 | 动态绝对路径复制后仍读原路径；代码未变 |
| W10 | P2 | 保留 | AST 参数遮蔽全局解析错误；代码未变 |
| W11 | P3 | 保留 | snapshot 改名破坏 policy_* 工厂约定；代码未变 |
| W12 | P3 | 已批准缓修 | 用户明确裁定 fix-on-touch；不计为未经批准未修 |

W02 定位：`k0_train.py:480` 读取、`:507` 另读 hash。其余旧项定位与逐文件 MD5/SHA256 见 `fixes/unchanged_status.json`；字节未变项未重复运行相同反例。完整旧复现随此前 W 证据包交付。

## 本轮正面核验与边界

1. **裁定书**：J 的正式 q 前置、K′ 四条件联合功效、L 撤销 1/20 显著性、M′ 要求 Δ_S 聚类 CI 下界 >0、N 的训练噪声正名均已写入。文档落实与实验达标分开记账。
2. **测量语义**：双席同权重 ΔU=0；两种小网、对称/非对称回放共 8 项续弈 U 与 gate 直调逐值相等；scene 无跨臂污染；单/双 worker 行相同；终局299、重复根、错误 game 均拒绝。单局 CI 为 null，长短局汇总用按局均值。driver 无教师调用，也不声明正式 PASS；没有把缺 formal 清单重复报成 bug。
3. **quota**：11 个合成场景均符合预期：10 个有效布局 PASS，unlimited 负例 FAIL；另有真实子进程覆盖来源核验。实际容器读到 4 CPU/16 GiB。没有修改 cgroup，也没有执行平台 1.5 CPU/512 MiB 整场认证，不能把此项称为完整平台认证。
4. **it95 包**：MD5=`9e16085acd3549df210c6209ab3fd3cb`；4 份内嵌源码与本轮权威源码及声明 hash 一致。186 个权重张量无缺键、多键、形状错误、非有限值或压缩大小错误，配置 SEARCH=false/guard-on。未持有源 NPZ，不独立证明训练谱系，也未做天梯强度或整场资源认证。
5. **新增数据**：22 份 k4v3 replay 与索引得分、席位、终局记录一致；4 份跨 corpus 同名副本内容相同。3 份更新 matches 表各自 ID 唯一。原 builder 去重语义本轮未变。
6. **ddc88081 清单**：test=323、train=1202，各自唯一、互不相交，合计1525；分层计数、配额和伴随 MD5 合。原 pool、118/34 隔离清单及远端 replay 路径未在本机独立取得，因此不独立背书 union=原 pool、这些隔离交集或远端文件存在性。
7. **N=323 解释**：是教师正式切分，不是学生联合功效 N。全步硬引导 du 的 σ 可支持其自身 CI 规划计算，但不能因此宣称终局软 q 的所有合取判据具有 80% 功效。当前 q 分支不消费 du pilot 工件，未报告不存在的 mode/window 工件硬冲突。

## 建议修复顺序与复核条件

先修 X01，并与 X06 一起定下真实候选前缀和 seat 契约；接着对齐 X02 的认证分布。再修 X03/X04 的冻结输入与恢复身份、X05 发布验证、X07 非有限模型拒绝及 X10 登记 ID。X08/X09 做相应校验补强。

正式开跑前应在同一最终 SHA 上，拿真实 annotation 产物完成 join→loader→两臂短训→父代/学生测量，连同本报告各反例与正例重跑。检查点、数据代和认证分布都绑定该次输入身份。旧 W02/W03/W04/W09/W10/W11 继续独立登记，不与本轮 X 项混号。

## 可复现材料

`review_manifest.json` 记录最终 SHA、源码 MD5/SHA256 和 Python/NumPy/PyTorch/SciPy 版本。主要脚本：

- `distill/probe.py`：X01、X02，受控小网与真实训练入口。
- `annotate/probe.py`、`annotate/nan_publish.py`：X03/X04/X05/X09。
- `duel/probe_duel.py` 及同目录控制探针：X04/X07/X08 与续弈等价正例。
- `integration/`：连接键、温度公式、最新清单和登记 ID。
- `fixes/probe_k0.py`、`fixes/probe_aux_race.py`、`fixes/probe_exit.py`：W01/W02/W05。
- `quota/probe_quota.py`、`quota/probe_override_real.py`、`quota/probe_source_modes.py`：W06–W08。
- `artifacts/probe_pack.py`、`artifacts/probe_data.py`：包和新增回放核验。

本地解释器：`/workspace/carbon-review-venv/bin/python`。脚本使用当前工作区绝对路径；迁移运行需对应改目录并签出冻结 SHA。随包保留探针与结果，不打包受控大权重/缓存；它们由脚本生成。源代码检查与合成反例、真实小网运行、真实比赛证据的边界已分别说明。
