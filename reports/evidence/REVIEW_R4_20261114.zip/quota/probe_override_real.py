import os,sys,json,subprocess,tempfile
from pathlib import Path
out=Path('/workspace/review-20261114-r4/quota')
with tempfile.TemporaryDirectory(dir=out) as d:
 p=Path(d); tree=p/'fake_cgroup';tree.mkdir()
 (tree/'cpu.max').write_text('150000 100000\n');(tree/'memory.max').write_text('536870912\n')
 (p/'cgroup').write_text('0::/\n');(p/'mountinfo').write_text(f'36 25 0:32 / {tree} rw - cgroup2 cgroup rw\n')
 pack=p/'pack.py';pack.write_text('def agent(obs,cfg): return {}\n')
 env=dict(os.environ,CERTIFY_PACK_TEST_CGROUP_FILE=str(p/'cgroup'),CERTIFY_PACK_TEST_MOUNTINFO_FILE=str(p/'mountinfo'),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
 cp=subprocess.run([sys.executable,'/workspace/carbon-league/code/certify_pack.py',str(pack),'--steps-per-game','1','--require-quota'],env=env,capture_output=True,text=True,timeout=40)
 (out/'override_real_stdout.json').write_text(cp.stdout)
 (out/'override_real_stderr.log').write_text(cp.stderr)
 data=json.loads(cp.stdout)
 print(json.dumps({'rc':cp.returncode,'overall':data['overall'],'quota':data['identity']['params']['quota'],'checks':data['checks']['quota_self_proof'],'game_steps':[x['steps'] for x in data['games']]},indent=2))

assert cp.returncode == 1 and data['overall'] == 'FAIL'
assert data['checks']['quota_self_proof']['source'] == 'test_override'
assert 'test_override' in data['checks']['quota_self_proof']['missing']
