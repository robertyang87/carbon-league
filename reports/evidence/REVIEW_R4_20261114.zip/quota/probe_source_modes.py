import os,sys,json,subprocess,tempfile
from pathlib import Path
out=Path('/workspace/review-20261114-r4/quota')
res={}
with tempfile.TemporaryDirectory(dir=out) as d:
 p=Path(d);tree=p/'fake';tree.mkdir()
 (tree/'cpu.max').write_text('150000 100000\n');(tree/'memory.max').write_text('536870912\n')
 (p/'cgroup').write_text('0::/\n');(p/'mountinfo').write_text(f'36 25 0:32 / {tree} rw - cgroup2 cgroup rw\n')
 pack=p/'pack.py';pack.write_text('def agent(obs,cfg): return {}\n')
 cases={'real_no_override':({},True),'one_override_cgroup':({'CERTIFY_PACK_TEST_CGROUP_FILE':str(p/'cgroup')},True),'one_override_mountinfo':({'CERTIFY_PACK_TEST_MOUNTINFO_FILE':str(p/'mountinfo')},True),'marked_report_only':({'CERTIFY_PACK_TEST_CGROUP_FILE':str(p/'cgroup'),'CERTIFY_PACK_TEST_MOUNTINFO_FILE':str(p/'mountinfo')},False)}
 for name,(over,required) in cases.items():
  env={k:v for k,v in os.environ.items() if not k.startswith('CERTIFY_PACK_TEST_')}
  env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',**over)
  cmd=[sys.executable,'/workspace/carbon-league/code/certify_pack.py',str(pack),'--steps-per-game','1']+(['--require-quota'] if required else [])
  cp=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=40)
  data=json.loads(cp.stdout)
  res[name]={'exit_code':cp.returncode,'overall':data['overall'],'quota':data['identity']['params']['quota'],'quota_check':data['checks']['quota_self_proof']}
 assert res['real_no_override']['overall']=='PASS'
 for name in ('one_override_cgroup','one_override_mountinfo'):
  assert res[name]['overall']=='FAIL' and res[name]['quota']['source']=='test_override'
 assert res['marked_report_only']['quota_check']['pass'] is None
 assert res['marked_report_only']['quota']['source']=='test_override'
(out/'source_modes.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps({k:{'rc':v['exit_code'],'overall':v['overall'],'source':v['quota']['source'],'quota_pass':v['quota_check']['pass']} for k,v in res.items()},indent=2))
