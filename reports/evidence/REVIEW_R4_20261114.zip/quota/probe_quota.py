"""Real quota reader + real certificate emission with synthetic cgroup mounts.
No cgroups changed; run_game alone stubbed to isolate quota classification.
"""
import builtins, contextlib, hashlib, io, json, sys, tempfile
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, '/workspace/carbon-league/code')
import certify_pack as C
OUT=Path('/workspace/review-20261114-r4/quota')
root='/sys/fs/cgroup'
base={'/proc/self/cgroup':'0::/fleet/certifier\n',
      '/proc/self/mountinfo':'36 25 0:32 / /sys/fs/cgroup rw - cgroup2 cgroup rw\n'}
cases={
 'root_finite_positive':dict(base, **{root+'/cpu.max':'150000 100000',root+'/memory.max':'536870912'}),
 'nested_finite_root_unlimited':dict(base, **{root+'/cpu.max':'max 100000',root+'/memory.max':'max',root+'/fleet/certifier/cpu.max':'150000 100000',root+'/fleet/certifier/memory.max':'536870912'}),
 'nested_finite_root_larger':dict(base, **{root+'/cpu.max':'800000 100000',root+'/memory.max':'8589934592',root+'/fleet/certifier/cpu.max':'150000 100000',root+'/fleet/certifier/memory.max':'536870912'}),
 'ancestor_finite_leaf_unlimited':dict(base, **{root+'/cpu.max':'max 100000',root+'/memory.max':'max',root+'/fleet/cpu.max':'150000 100000',root+'/fleet/memory.max':'536870912',root+'/fleet/certifier/cpu.max':'max 100000',root+'/fleet/certifier/memory.max':'max'}),
 'v1_nested_combined_mount':{'/proc/self/cgroup':'2:cpu,cpuacct:/fleet/certifier\n3:memory:/fleet/certifier\n','/proc/self/mountinfo':'36 25 0:32 / /sys/fs/cgroup/cpu,cpuacct rw - cgroup cgroup rw,cpu,cpuacct\n37 25 0:33 / /sys/fs/cgroup/memory rw - cgroup cgroup rw,memory\n',root+'/cpu,cpuacct/fleet/certifier/cpu.cfs_quota_us':'150000',root+'/cpu,cpuacct/fleet/certifier/cpu.cfs_period_us':'100000',root+'/memory/fleet/certifier/memory.limit_in_bytes':'536870912'},
}
cases.update({
 'subtree_only_positive':{'/proc/self/cgroup':'0::/fleet/certifier\n','/proc/self/mountinfo':'36 25 0:32 /fleet /visible rw - cgroup2 cgroup rw\n','/visible/cpu.max':'150000 100000','/visible/memory.max':'536870912','/visible/certifier/cpu.max':'max 100000','/visible/certifier/memory.max':'max'},
 'v2_duplicate_subtree_mount':{'/proc/self/cgroup':'0::/fleet/certifier\n','/proc/self/mountinfo':'36 25 0:32 / /sys/fs/cgroup rw - cgroup2 cgroup rw\n37 25 0:32 /fleet/certifier /visible rw - cgroup2 cgroup rw\n','/sys/fs/cgroup/cpu.max':'max 100000','/sys/fs/cgroup/memory.max':'max','/sys/fs/cgroup/fleet/cpu.max':'150000 100000','/sys/fs/cgroup/fleet/memory.max':'536870912','/sys/fs/cgroup/fleet/certifier/cpu.max':'800000 100000','/sys/fs/cgroup/fleet/certifier/memory.max':'8589934592','/visible/cpu.max':'800000 100000','/visible/memory.max':'8589934592'},
 'hybrid_v2_cpu_v1_memory':{'/proc/self/cgroup':'0::/fleet/certifier\n3:memory:/fleet/certifier\n','/proc/self/mountinfo':'36 25 0:32 / /sys/fs/cgroup/unified rw - cgroup2 cgroup rw\n37 25 0:33 / /sys/fs/cgroup/memory rw - cgroup cgroup rw,memory\n','/sys/fs/cgroup/unified/fleet/certifier/cpu.max':'150000 100000','/sys/fs/cgroup/memory/fleet/certifier/memory.limit_in_bytes':'536870912'},
})
cases.update({
 'v1_duplicate_subtree_mount':{'/proc/self/cgroup':'2:cpu,cpuacct:/fleet/certifier\n3:memory:/fleet/certifier\n','/proc/self/mountinfo':'36 25 0:32 / /sys/fs/cgroup/cpu,cpuacct rw - cgroup cgroup rw,cpu,cpuacct\n37 25 0:32 /fleet/certifier /visible/cpu rw - cgroup cgroup rw,cpu,cpuacct\n38 25 0:33 / /sys/fs/cgroup/memory rw - cgroup cgroup rw,memory\n39 25 0:33 /fleet/certifier /visible/memory rw - cgroup cgroup rw,memory\n','/sys/fs/cgroup/cpu,cpuacct/fleet/cpu.cfs_quota_us':'150000','/sys/fs/cgroup/cpu,cpuacct/fleet/cpu.cfs_period_us':'100000','/sys/fs/cgroup/cpu,cpuacct/fleet/certifier/cpu.cfs_quota_us':'800000','/sys/fs/cgroup/cpu,cpuacct/fleet/certifier/cpu.cfs_period_us':'100000','/visible/cpu/cpu.cfs_quota_us':'800000','/visible/cpu/cpu.cfs_period_us':'100000','/sys/fs/cgroup/memory/fleet/memory.limit_in_bytes':'536870912','/sys/fs/cgroup/memory/fleet/certifier/memory.limit_in_bytes':'8589934592','/visible/memory/memory.limit_in_bytes':'8589934592'},
 'hybrid_v1_cpu_v2_memory':{'/proc/self/cgroup':'0::/unified_path\n2:cpu,cpuacct:/v1_path\n','/proc/self/mountinfo':'36 25 0:32 / /sys/fs/cgroup/unified rw - cgroup2 cgroup rw\n37 25 0:33 / /sys/fs/cgroup/cpu,cpuacct rw - cgroup cgroup rw,cpu,cpuacct\n','/sys/fs/cgroup/unified/unified_path/memory.max':'536870912','/sys/fs/cgroup/cpu,cpuacct/v1_path/cpu.cfs_quota_us':'150000','/sys/fs/cgroup/cpu,cpuacct/v1_path/cpu.cfs_period_us':'100000'},
 'unlimited_negative':{'/proc/self/cgroup':'0::/fleet/certifier\n','/proc/self/mountinfo':'36 25 0:32 / /sys/fs/cgroup rw - cgroup2 cgroup rw\n','/sys/fs/cgroup/fleet/certifier/cpu.max':'max 100000','/sys/fs/cgroup/fleet/certifier/memory.max':'max'},
})
observations={}
real_open=builtins.open
with tempfile.TemporaryDirectory() as td:
 p=Path(td)/'pack.py';p.write_text('def agent(obs,cfg): return {}\n')
 pack_md5=hashlib.md5(p.read_bytes()).hexdigest()
 self_md5=hashlib.md5(Path(C.__file__).read_bytes()).hexdigest()
 def healthy(*args):
  return {'steps_ms':[1.0], 'init_wall_s':.01,'game_wall_s':.1,'peak_rss_mib':1.,'a_errors':0,'fatal':None,'rc':0,'child_pack_id':{'md5':pack_md5},'child_self_md5':self_md5,'harness_mods':{}}
 for name, files in cases.items():
  reads=[]
  def mapped(path,*args,**kwargs):
   path=str(path)
   if path.startswith('/sys/fs/cgroup') or path.startswith('/visible') or path in ('/proc/self/cgroup','/proc/self/mountinfo'):
    reads.append(path)
    if path not in files:raise FileNotFoundError(path)
    return io.StringIO(files[path])
   return real_open(path,*args,**kwargs)
  stdout=io.StringIO()
  with patch('builtins.open',mapped), patch.object(C,'run_game',healthy),patch.object(C.os,'sched_getaffinity',return_value=set(range(64))),patch.object(sys,'argv',['certify_pack',str(p),'--steps-per-game','1','--require-quota']),contextlib.redirect_stdout(stdout):
   try:C.main()
   except SystemExit as exc:rc=exc.code
  data=json.loads(stdout.getvalue())
  observations[name]={'expected_effective_cpu':1.5,'expected_effective_memory':536870912,'exit_code':rc,'overall':data['overall'],'quota':data['checks']['quota_self_proof'],'read_paths':reads,'only_failed_checks':[k for k,v in data['checks'].items() if v['pass'] is False]}
for name in ('root_finite_positive','nested_finite_root_unlimited','nested_finite_root_larger','ancestor_finite_leaf_unlimited','v1_nested_combined_mount','subtree_only_positive','v1_duplicate_subtree_mount','hybrid_v1_cpu_v2_memory'):
 assert observations[name]['overall']=='PASS', name
 assert observations[name]['quota']['memory_max']==536870912,name
assert observations['v2_duplicate_subtree_mount']['quota']['memory_max']==536870912
assert observations['hybrid_v2_cpu_v1_memory']['overall']=='PASS'
assert observations['unlimited_negative']['overall']=='FAIL'
(OUT/'quota_results.json').write_text(json.dumps(observations,indent=2)+'\n')
print(json.dumps({k:{'overall':v['overall'],'cpu':v['quota']['cpu_max'],'memory':v['quota']['memory_max'],'failed':v['only_failed_checks']} for k,v in observations.items()},indent=2))
