# k0_duel independent read-only review

Frozen source: `907c105965c8429919201e4d7b84ca8fb93ae0bc`, baseline `496ee1cc`.
The repository was not modified. Probe scripts, generated small weights, synthetic replays, and outputs are confined to this directory.

## Confirmed findings

### D01 — P2: invalid numeric checkpoints produce apparently valid measurement artifacts

Location: `code/k0_duel.py:238-239`; inference path `code/cnet2_np.py:199-211`.

`_load_policy` constructs `CachePolicy` without checking numeric tensors. NumPy greedy decode applies `argmax` to nonfinite logits. A real small checkpoint with `bhead.bias = [NaN,NaN,NaN]` is therefore silently interpreted as a concrete action policy. The real CLI exits 0, writes `kind=k0_duel_result`, and reports both root values 0.5 and Delta U 0. The root/summary finite checks alone would not detect this because the corruption disappears into the discrete action selection.

This can turn a divergent exported student into an apparently neutral evaluation and contaminate C/S noise or power measurements. Check all numeric policy parameters before inference, reject nonfinite active logits at execution, and fail before publishing a measurement. This is a reproduced input-integrity failure, not a claim that current production checkpoints contain NaNs.

Evidence: `probe_results.json.nonfinite_checkpoint`, `control_results.json.nan_cli`, and `nan_cli.json`. No inference/simulator/scoring stubs; actual CNet2 export, NP Policy, guard, FastCarbon, terminal scoring, aggregation, CLI.

### D02 — P2: reported model/root identities are not bound to consumed bytes

Locations: `code/k0_duel.py:327-339`, `:300-307`, and `:273-288`.

The parent process hashes checkpoint paths, then each worker independently loads those paths. A replacement between these calls gives a result attributed to old bytes while actually evaluating new bytes. Similarly, `load_roots` parses/hashes a replay, but each task rereads the replay via `extract_scene` without matching its stored hash or terminal facts. Long multiworker runs can consume a mix of generations under a single declared identity.

Reproduction: swap `mutable.npz` immediately before the real worker initializer. Header/rows claim the all-STAY policy MD5, but measured Delta U is -0.25749775080970505, exactly the real RECRUIT policy result, rather than the true claimed-policy Delta U 0. The only hook schedules the external file replacement in the pre-existing hash/load window; all policy loading, games, statistics, and result construction are real. For replay replacement no hook is needed: `load_roots`, replace replay path, `run_duel`; reconstructed root cash changes [80,80] to [50,80] while result retains the original roots SHA.

Read/hash/parse each input from one immutable byte buffer or immutable snapshot; pass expected hashes to workers and fail on mismatches, with hashes computed from the same bytes used for parsing. A pre-read hash followed by another independent open is insufficient.

Evidence: `probe_results.json.checkpoint_identity_window` and `.replay_identity_window`.

### D03 — P3: one game ID can map to conflicting replay contents

Location: `code/k0_duel.py:265-278` (cache keyed by path), combined with game-keyed clustering at `:341`.

Manifest rows `(game1, a/game1.json.gz, step297, me0)` and `(game1, b/game1.json.gz, step298, me0)` pass even when the files describe different games. Distinct roots avoid the duplicate-key gate, basename checks pass, and both are combined into one source-game cluster. This is a static consistency gap, independent of D02's replacement timing. Validate a unique canonical replay identity for each game ID within a run. The probe uses genuinely different game states, not only different gzip headers.

Evidence: `probe_results.json.same_game_two_replay_contents` (two distinct hashes accepted; 2 roots grouped as 1 game).

## Passing checks and boundaries

- Same checkpoint, both seats: exact per-root Delta U = 0; different-policy control produces nonzero Delta U.
- Parent continuation uses parent on both seats; student continuation changes only the root seat.
- Direct gate bare continuation matches new driver value-for-value for both seats, two real tiny policies, symmetric and asymmetric replay prefixes.
- Input scene serialization unchanged across both arms; actual feature and guard snapshots are deep-copied/restored per seat. Source inspection found the loop and terminal scoring faithful to the original gate, including pre-step survivor cash and step299 stop.
- Driver import loads neither teacher nor gate modules. Later direct-gate parity tests replace `evaluate_root` with a raising stub to detect any accidental teacher invocation; none occurs. This stub is an assertion only, not a scoring substitute.
- Sequential and two-worker outputs match on the deterministic test roots.
- Invalid duplicate root, wrong game basename, and terminal step299 root are rejected.
- Game-level aggregation control: 10 roots +0.1 in one game, 1 root -0.1 in another yields game mean 0 (root mean 0.081818...). One-game t/bootstrap intervals are null, avoiding fake precision.
- This driver produces raw measurements, not a formal PASS verdict. Missing train/pilot isolation lists or multi-seed final decision logic were **not** filed as hidden defects: those must remain run-plan/aggregation responsibilities until an explicit formal wrapper is implemented. Latest K/M supplement II requires all four conditions, including student-vs-parent clustered CI lower >0; this file makes no stronger claim.
- Stage2 artifacts, available production weights, and physical workers were not used. Synthetic fixtures exercise the real local implementation; they do not establish production model quality or fleet deployment parity.

## Reproduce

```
/workspace/carbon-review-venv/bin/python -B /workspace/review-20261114-r4/duel/probe_duel.py
/workspace/carbon-review-venv/bin/python -B /workspace/review-20261114-r4/duel/probe_controls.py
```

The first script regenerates local fixtures; run it before the second.
