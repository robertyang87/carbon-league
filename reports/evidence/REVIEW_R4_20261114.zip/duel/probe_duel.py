import os
for v in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[v]='1'
import sys, json, gzip, shutil, hashlib, copy
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,'/workspace/carbon-league/code')
import numpy as np
import torch
torch.set_num_threads(1)
from cnet2_model import CNet2
from rl2_ppo_cnet2 import Cnet2Adapter
import k0_duel as D
from fastsim import FastCarbon
from eval_v53 import CFG

P=Path('/workspace/review-20261114-r4/duel')
torch.manual_seed(42)
net=CNet2(C=16,NB=1,D=16,NH=2,L=1,E=8,G=4)
base=Cnet2Adapter().export(net)
for k,v in base.items():
    if k!='meta': v.fill(0)
base['bhead.bias'][:]=[10,0,0]
base['whead.bias'][:]=[10,0,0,0,0]
np.savez(P/'stay.npz',**base)
rec={k:v.copy() for k,v in base.items()}
rec['bhead.bias'][:]=[0,10,0]
np.savez(P/'recruit.npz',**rec)
bad={k:v.copy() for k,v in base.items()}
bad['bhead.bias'][:]=float('nan')
np.savez(P/'nan.npz',**bad)

def save_replay(path, early_recruit=False):
    path.parent.mkdir(parents=True,exist_ok=True)
    sim=FastCarbon(CFG).reset(seed=1)
    steps=[]
    for t in range(300):
        actions=({}, {})
        if t:
            if early_recruit and t==1: actions=({'player-0-recrtCenter-0':'RECCOLLECTOR'}, {})
            sim.step(*actions)
        f=[]
        for seat in (0,1):
            obs=sim.full_observation(seat)
            obs['full_carbon']=obs['carbon']
            f.append({'observation':obs, 'action':actions[seat], 'status':'DONE' if t==299 else 'ACTIVE'})
        steps.append(f)
    with gzip.open(path,'wt') as h: json.dump({'steps':steps},h)
    return steps

a=P/'a'/'game1.json.gz';b=P/'b'/'game1.json.gz'
save_replay(a,False);save_replay(b,True)
manifest=P/'roots.json'
roots=[{'game':'game1','path':str(a),'step':298,'me':s} for s in (0,1)]
manifest.write_text(json.dumps(roots))
specs,sha=D.load_roots(str(manifest),200,299)
res={}
same=D.run_duel(str(P/'stay.npz'),str(P/'stay.npz'),specs,sha)
res['same_weight']={'deltas':[r['du'] for r in same['rows']], 'summary':same['summary']}
different=D.run_duel(str(P/'recruit.npz'),str(P/'stay.npz'),specs,sha)
res['different_weight']={'deltas':[r['du'] for r in different['rows']], 'u_student':[r['u_student'] for r in different['rows']]}
nan=D.run_duel(str(P/'nan.npz'),str(P/'stay.npz'),specs,sha)
res['nonfinite_checkpoint']={'accepted':True,'nan_parameter':bool(np.isnan(bad['bhead.bias']).all()),'rows':nan['rows'], 'summary':nan['summary']}

# Precisely schedule an atomic checkpoint replacement in the existing
# hash/read window. Policy, simulation and statistics all remain real.
mutable=P/'mutable.npz';shutil.copyfile(P/'stay.npz',mutable)
before=D.md5_of(str(mutable));old_init=D._init_worker
def replace_then_init(student_path,parent_path):
    shutil.copyfile(P/'recruit.npz',student_path)
    return old_init(student_path,parent_path)
D._init_worker=replace_then_init
race=D.run_duel(str(mutable),str(P/'stay.npz'),specs,sha)
D._init_worker=old_init
res['checkpoint_identity_window']={'declared_student_md5':race['student']['md5'],'before_md5':before,'actual_loaded_md5':D.md5_of(str(mutable)), 'du':[r['du'] for r in race['rows']], 'matches_actual_recruit_result':race['rows'][0]['du']==different['rows'][0]['du']}

# Replay replacement requires no hooks: public load_roots, replace,
# public run_duel. Calls correspond to main's consecutive statements.
old_md5=specs[0]['replay_md5']
old_scene=D.extract_scene(specs[0])
shutil.copyfile(b,a)
new_scene=D.extract_scene(specs[0])
replayed=D.run_duel(str(P/'stay.npz'),str(P/'stay.npz'),specs,sha)
res['replay_identity_window']={'declared_replay_md5':old_md5,'actual_replay_md5':D.md5_of(str(a)),'old_cash':old_scene['state']['cash'],'new_cash':new_scene['state']['cash'],'reported_roots_sha256':replayed['roots_sha256'],'still_original_rootsha':replayed['roots_sha256']==sha}

# Same declared game may bind different replay bytes across root rows.
save_replay(a,False)
mixed=[{'game':'game1','path':str(a),'step':297,'me':0},{'game':'game1','path':str(b),'step':298,'me':0}]
manifest.write_text(json.dumps(mixed))
ms,msha=D.load_roots(str(manifest),200,299)
mixedout=D.run_duel(str(P/'stay.npz'),str(P/'stay.npz'),ms,msha)
res['same_game_two_replay_contents']={'accepted':True,'replay_md5s':[s['replay_md5'] for s in ms], 'n_games_reported':mixedout['summary']['n_games'],'n_roots':mixedout['summary']['n_roots']}

# Positive validation checks and source-game aggregation.
checks={}
for label,ls in [('duplicate',[roots[0],roots[0]]),('terminal',[dict(roots[0],step=299)]),('wrong_game',[dict(roots[0],game='other')])]:
    manifest.write_text(json.dumps(ls))
    try: D.load_roots(str(manifest),200,299);checks[label]='ACCEPTED'
    except SystemExit as e:checks[label]=str(e)
res['validation_controls']=checks
res['cluster_control']=D.cluster_stats([{'game':'long','du':.1} for _ in range(10)]+[{'game':'short','du':-.1}],'du')
(P/'probe_results.json').write_text(json.dumps(D._sanitize(res),indent=2,allow_nan=False))
print(json.dumps(D._sanitize(res),indent=2,allow_nan=False))
