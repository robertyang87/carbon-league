import os
for v in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[v]='1'
import sys, json, copy, pickle, subprocess
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,'/workspace/carbon-league/code')
import k0_duel as D
P=Path('/workspace/review-20261114-r4/duel')
res={'teacher_module_imported':('stage0_teacher' in sys.modules),
     'gate_module_imported':('stage1_teacher_gate' in sys.modules)}
import stage1_teacher_gate as G
def forbidden(*a,**kw):raise AssertionError('teacher unexpectedly called')
G.T.evaluate_root=forbidden
specs=[{'game':'game1','path':str(P/'a/game1.json.gz'),'step':298,'me':s} for s in (0,1)]
parity=[]
for s in specs + [dict(s,path=str(P/'b/game1.json.gz')) for s in specs]:
    scene=D.extract_scene(s)
    initial=pickle.dumps(scene)
    for w in ('stay.npz','recruit.npz'):
        du=D.continue_game_2pol(D._load_policy(str(P/w)),D._load_policy(str(P/w)),scene,995698,teacher_style=2)
        gate=G.continue_game(D._load_policy(str(P/w)),scene,None,995698,teacher=2)
        parity.append({'me':s['me'],'replay':s['path'],'weights':w,'duel':du,'gate':gate,'equal':du==gate})
    assert pickle.dumps(scene)==initial
res['same_net_gate_parity']=parity
res['scene_inputs_unchanged_after_both_arms']=True

# Parallel and sequential paths get the same two real policies, roots.
manifest=P/'controls_roots.json';manifest.write_text(json.dumps(specs))
rs,sha=D.load_roots(str(manifest),200,299)
mp=D.run_duel(str(P/'recruit.npz'),str(P/'stay.npz'),rs,sha,workers=2)
seq=D.run_duel(str(P/'recruit.npz'),str(P/'stay.npz'),rs,sha,workers=1)
res['parallel_rows_equal']=mp['rows']==seq['rows']

# Real CLI, corrupt checkpoint: no policy/simulator/statistics stubs.
out=P/'nan_cli.json'
cmd=[sys.executable,'-B','/workspace/carbon-league/code/k0_duel.py','--student',str(P/'nan.npz'),'--parent',str(P/'stay.npz'),'--roots',str(manifest),'--out',str(out)]
p=subprocess.run(cmd,text=True,capture_output=True)
res['nan_cli']={'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'artifact_exists':out.exists()}
(P/'control_results.json').write_text(json.dumps(res,indent=2))
print(json.dumps(res,indent=2))
