"""Compare observed outcomes on shared opponents. Read scores from a frozen git tree."""
import argparse
import json
import statistics
import subprocess
from collections import defaultdict
from pathlib import Path


def read_results(repo, ref, model):
    path = f'data/{model.lower()}_matches.json'
    raw = subprocess.check_output(['git', 'show', f'{ref}:{path}'], cwd=repo)
    games = json.loads(raw)
    seen = set()
    out = defaultdict(list)
    for game in games:
        identity = (game['id'], game['game'])
        assert identity not in seen and game['state'] == 'done'
        seen.add(identity)
        ours = 'a' if game['name_a'] == 'claude-AlphaCarbon-' + model else 'b'
        assert game['name_' + ours] == 'claude-AlphaCarbon-' + model
        other = 'b' if ours == 'a' else 'a'
        difference = game['scores'][ours] - game['scores'][other]
        out[game['name_' + other]].append(difference)
    return out


def summarize(margins):
    return {'n':len(margins), 'w':sum(v > 0 for v in margins), 'd':sum(v == 0 for v in margins), 'median_margin':round(statistics.median(margins), 2)}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('repo', type=Path)
    parser.add_argument('--ref', default='24c154f7')
    args = parser.parse_args()
    left, right = (read_results(args.repo, args.ref, m) for m in ('Master5s','Master6'))
    shared = left.keys() & right.keys()
    rows = [{'opponent':o, '5s':summarize(left[o]), '6':summarize(right[o])} for o in sorted(shared, key=lambda k:(-min(len(left[k]), len(right[k])), k))]
    print(json.dumps({'shared_opponents':len(rows), 'rows':rows}, ensure_ascii=False, indent=2))
