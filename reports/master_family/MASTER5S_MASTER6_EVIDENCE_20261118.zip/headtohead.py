"""Recompute the two Master5s–Master6 match snapshots from the pinned Git data.

Run python headtohead.py to write CSV to stdout. Optionally pass the repository
directory as the first argument. The score columns are cash in the named state.
"""

import csv
import gzip
import json
import subprocess
import sys
from pathlib import Path


REV = "5cc3329d"
REPO = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1] / "carbon-league"
STEPS = (50, 70, 150, 250, 299)
NAMES = {"claude-AlphaCarbon-Master5s": "5s", "claude-AlphaCarbon-Master6": "6"}


def blob(path):
    return subprocess.check_output(["git", "-C", str(REPO), "show", f"{REV}:{path}"])


def main():
    fieldnames = ["match_id", "step", "seat0", "seat1", "cash_delta_6_minus_5s"]
    for name in ("5s", "6"):
        fieldnames.extend(f"{field}_{name}" for field in ("cash", "workers", "trees", "cargo"))
    writer = csv.DictWriter(sys.stdout, fieldnames=fieldnames, lineterminator="\n")
    writer.writeheader()

    matches = json.loads(blob("data/master6_matches.json"))
    direct = [m for m in matches if m["state"] == "done" and {m["name_a"], m["name_b"]} == NAMES.keys()]
    assert len(direct) == 2, "Unexpected number of direct matchups at the pinned revision"
    for match in direct:
        path = f"data/master6_corpus/{match['id']}-{match['game']}.json.gz"
        replay = json.loads(gzip.decompress(blob(path)))
        order = match["order"]
        seats = [NAMES[match[f"name_{side}"]] for side in order]
        assert replay["rewards"] == [match["scores"][side] for side in order]
        for step in STEPS:
            obs = replay["steps"][step][0]["observation"]
            assert obs["step"] == step
            row = {"match_id": match["id"], "step": step, "seat0": seats[0], "seat1": seats[1]}
            cash_by_name = {}
            for name, player in zip(seats, obs["players"]):
                cash, _, workers, trees = player
                cash_by_name[name] = cash
                row[f"cash_{name}"] = f"{cash:.2f}"
                row[f"workers_{name}"] = len(workers)
                row[f"trees_{name}"] = len(trees)
                row[f"cargo_{name}"] = f"{sum(worker[1] for worker in workers.values()):.2f}"
            if step == 299:
                assert [cash_by_name[name] for name in seats] == replay["rewards"]
            row["cash_delta_6_minus_5s"] = f"{cash_by_name['6'] - cash_by_name['5s']:.2f}"
            writer.writerow(row)


if __name__ == "__main__":
    main()
