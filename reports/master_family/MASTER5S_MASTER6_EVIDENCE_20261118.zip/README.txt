Requires Python 3 and a git checkout of robertyang87/carbon-league with 5cc3329d and 24c154f7 available.
python headtohead.py /path/to/carbon-league
python opponents.py /path/to/carbon-league
The scripts read archived game records from git. Live leaderboard results are recorded separately in public_snapshot.json.
