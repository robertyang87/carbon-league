"""Portable, read-only probes. Usage: python RUN_PROBES.py --repo /path/carbon-league publisher"""
import argparse,os,subprocess,sys,tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--repo',required=True,type=Path);p.add_argument('probe',choices=['publisher','identity']);a=p.parse_args()
here=Path(__file__).resolve().parent
src=here/('probe_publisher.py' if a.probe=='publisher' else 'probe_curriculum_identity.py')
code=src.read_text().replace('/workspace/carbon-league',str(a.repo.resolve()))
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
with tempfile.TemporaryDirectory(prefix='carbon-decision-review-') as d:
 f=Path(d)/'probe.py';f.write_text(code)
 raise SystemExit(subprocess.run([sys.executable,str(f)],cwd=a.repo,env=env).returncode)
