"""Exercise only the real entrypoint's parent/teacher identity guard; no model or training."""
from pathlib import Path
import hashlib, json, sys, tempfile
import numpy as np
repo=Path('/workspace/carbon-league')
sys.path.insert(0,str(repo/'code'))
import k0_distill_u as u
with tempfile.TemporaryDirectory() as d:
    parent=Path(d)/'stage1_student.npz'
    # Mismatch is deliberately before NPZ decoding; no real weight is needed.
    parent.write_bytes(b'synthetic-distinct-stage1-student-identity')
    old_teacher=hashlib.md5(b'synthetic-frozen-ring-parent-identity').hexdigest()
    u.load_annotation=lambda *a,**kw:{'info':{'teacher_weights_md5':old_teacher,'roots':1,'max_candidates':1}}
    u.targets_with_flatten=lambda *a,**kw:np.ones((1,1))
    sys.argv=['k0_distill_u.py','--data',d,'--parent',str(parent),'--out',str(Path(d)/'must_not_exist.npz')]
    try:
        u.main()
    except SystemExit as e:
        message=str(e)
        assert 'teacher_weights_md5' in message and 'refusing to start' in message
        assert not (Path(d)/'must_not_exist.npz').exists()
        print(json.dumps({'freeze':'db5e454bf5d8527a495194d2a5bcde39948a090c','probe':'synthetic annotation identity, real trainer entrypoint guard','rejected':True,'message':message,'model_or_optimizer_constructed':False},indent=2))
    else:
        raise AssertionError('Expected parent-teacher mismatch rejection')
