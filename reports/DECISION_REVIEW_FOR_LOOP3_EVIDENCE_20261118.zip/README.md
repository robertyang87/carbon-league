# 决策复核证据

冻结 db5e454bf5d8527a495194d2a5bcde39948a090c。六线笔记是各自证据，最终建议以仓内 DECISION_REVIEW_FOR_LOOP3_20261118.md 为准，尤其所有者后补CPU/时间约束优先于早期资金建议。

环境：Python3.12、NumPy1.26.4；identity探针需Torch2.5.1 CPU。使用自己的仓库和依赖，解压后运行：

```
python RUN_PROBES.py --repo /path/carbon-league publisher
python RUN_PROBES.py --repo /path/carbon-league identity
```

publisher为合成40根数据、真实publisher与join_u loader；只在临时目录删除测试REGISTRATION，不改仓内数据。identity在真实trainer入口注入合成数据身份，止于身份拒绝，不构造模型、不训练。两个探针都不属于生产事故或正式性能测量。

剂量与成本是注明条件的算术，原始A场／机器当前B状态本轮未直读。root_calculations、replay_dose与power_seeds_numbers存数值计算。消费源文件hash见manifest；zip不含模型、真实回放、凭据。
