"""Read-only portable runner for the R2 evidence package.
Usage: python RUN_REVIEW_PROBES.py --repo /path/carbon-league comparator
"""
import argparse
import os
from pathlib import Path
import subprocess
import sys
import tempfile

PROBES = {
    'comparator': 'comparator/probe_r2.py',
    'environment': 'real_env/probe_r2.py',
    'extinction': 'verification/probe_extinction.py',
    'memory': 'verification/probe_offline_memory.py',
    'gate': 'acceptance/probe_gate.py',
    'suite': 'acceptance/run_tests.py',
    'bridge': 'bridge/probe_bridge.py',
    'strategy': 'strategy/probe_strategy_r2.py',
    'production-comparator': 'comparator/probe_production_delta.py',
    'production-environment': 'real_env/probe_production_delta.py',
    'production-boundary': 'acceptance/probe_production_boundary.py',
    'production-timer': 'verification/probe_production_timer.py',
    'production-fallback': 'verification/probe_production_fallback.py',
    'production-bridge': 'bridge/probe_production_delta.py',
    'production-strategy': 'strategy/production_delta_probe.py',
}
p = argparse.ArgumentParser()
p.add_argument('--repo', required=True, type=Path)
p.add_argument('probe', choices=PROBES)
a = p.parse_args()
here = Path(__file__).resolve().parent
repo = a.repo.resolve()
code = (here / PROBES[a.probe]).read_text()
code = code.replace('/workspace/carbon-league', str(repo))
code = code.replace('/workspace/search-r2-review-20261116', str(here))
env = dict(os.environ, OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1',
           MKL_NUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1')
with tempfile.TemporaryDirectory(prefix='carbon-r2-probe-') as d:
    f = Path(d) / 'probe.py'
    f.write_text(code)
    r = subprocess.run([sys.executable, str(f)], env=env, cwd=repo)
    raise SystemExit(r.returncode)
