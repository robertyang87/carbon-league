import json
import math

def u(m):
    w = 1.0 if m > 0 else 0.0 if m < 0 else .5
    return .5*w + .5/(1+math.exp(-m/1000))

pairs = [{'baseline_margin':10,'changed_margin':-10}, {'baseline_margin':-1000,'changed_margin':-900}]
for pair in pairs:
    pair['delta_margin'] = pair['changed_margin']-pair['baseline_margin']
    pair['delta_u'] = u(pair['changed_margin'])-u(pair['baseline_margin'])
pi=.1
q_short=1-(1-pi)**1
q_long=1-(1-pi)**10
out={
  'baseline':'ffd813bd152998d7bf494c752f8176e1f6bf9fdb',
  'examples_are_synthetic_not_observed_results':True,
  'cash_vs_u': {'pairs':pairs,'mean_delta_margin':sum(p['delta_margin'] for p in pairs)/2,'mean_delta_u':sum(p['delta_u'] for p in pairs)/2},
  'root_sampling_game_inclusion': {'root_inclusion_probability':pi,'short_game_roots':1,'long_game_roots':10,'short_game_gain':1,'long_game_gain':-1,'short_game_inclusion_probability':q_short,'long_game_inclusion_probability':q_long,'equal_game_population_mean':0,'large_population_mean_if_only_sampled_games_get_equal_weight':(q_short-q_long)/(q_short+q_long)},
  'invalid_drop': {'games':100,'valid_games':99,'invalid_games':1,'invalid_fraction':.01,'valid_each_gain':.001,'invalid_unobserved_gain':-.2,'reported_valid_only_mean':.001,'actual_all_game_mean':(99*.001-.2)/100,'automatic_sensitivity_threshold':.05}
}
print(json.dumps(out,ensure_ascii=False,indent=2,allow_nan=False))
