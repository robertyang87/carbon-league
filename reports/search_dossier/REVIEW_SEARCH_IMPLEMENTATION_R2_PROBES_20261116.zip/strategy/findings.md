# Strategy re-review at b15b475d

Frozen source: `b15b475dcc900c84241304a1a5caed2fd428e693`. Scope: PPO-U2 decision/recovery amendments, search preregistration, S1 positive-control amendment, and status-document fixes. Read-only. No remote machines or active jobs inspected. Evidence extraction and literal decision-table replay are in `probe_strategy_r2.py` / `evidence.json`.

## Previous findings

### SI09 — Closed at the decision-contract level

`reports/PPOU2_FILING_20261114.md:409–415` now explicitly orders the branches, stops at the first match, and defines the ambiguous CI-crossing condition as crossing **both** L1 and L2. The original counterexample p=.075, CI [.062,.088] now uniquely rolls back; p=.090, CI [.077,.103] uniquely continues as harmless. p=.075, CI [.062,.090] is uniquely indeterminate by the first rule. A small exact-grid replay covers 286 valid `(lo,p,hi)` triples, including threshold equality, with one outcome each. This closes the original contradictory-instructions finding.

Boundary: the rule is a chosen operational policy, not proof that point-estimate crossing establishes a statistically significant deterioration. The document says it was settled before it35 results; this review verifies committed text and commit history, not private read chronology. No need to reopen SI09 merely because one could prefer another policy.

### SI10 — Closed by an explicit recovery-policy amendment, not by restoring the lost state

`reports/PPOU2_FILING_20261114.md:417–422` now acknowledges the reported L20+DGX search found no full it30 state, supersedes “resume ckpt30 state”, and specifies a new run initialized from the exact actor ckpt30 with the same actor as reference, new critic/optimizer state, a declared league, and renamed iterations 31′–40′. It explicitly discloses loss of trainer continuity, rejects unexamined it33 state as a substitute, and reports a frozen full it35 state for future decisions.

That is a valid documented response to SI10: no longer instruct an impossible full-state resume. Do **not** report the old absence as an unaddressed requirement. Also do **not** describe it as a bitwise full-training rollback or as proven equivalent to continuing the original it30 trainer.

Execution remains an ordinary precondition: before launching this branch, inspect argv/effective parameters, verify actor/reference bytes, confirm complete frozen it35 identity and actual league membership, and ensure the 31′–40′ label matches the fresh trainer's local numbering. This review has not performed or certified those machine-side actions. A new error should only be asserted if those concrete checks fail.

### MS03 residual and P3 document completeness — Closed

- `reports/search_dossier/PREREG_ECHO4_TACTICAL_SEARCH.md:25` now separates H0 depth reporting from inclusion of real A0 zero-gain roots in the S3 main metric, with explicit precedence to the S3 clause.
- `SEARCH_LINE_STATUS_20261116.md:118` onward restores the missing next-actions and risk sections. The literal `...[truncated 1107 chars]` marker is gone.
- λ0.92's “≈ λ0.95” wording at PPO filing:371 is unchanged. Keep that as the already-reported low-priority wording item; it is not a new regression.
- Battery evidence now includes run_id, code hashes, configuration, fixture identity, budget caliber and a FAIL verdict. Whether the hashes/fixtures truly bind the replay is owned by the acceptance/code review lines; mere field existence is not independently certified here.

## New P2 design finding: proposed S1 evidence replacement drops the independent “changed to a known-better action” requirement

**Location:** `reports/search_dossier/AMENDMENT_S1_POSITIVE_LEG_20261116.md:17–20`, especially line17 calling natural changes direct evidence of finding a **better** action and line19 concluding the changes are not noise because other terminal fixtures are exact. Line7 says the standard is unchanged.

**Verified evidence:**

- `s1_battery2_formal_evidence.json`: 48 natural roots, 16 changes, root steps8–56 and changed-root steps11–54. Their `verification` list is empty. Formal verdict remains **FAIL**, solely A2 in the recorded assertion table.
- Terminal fixtures A4/A5 report 8 exact best-action checks and 9 exact settlement comparisons. These are separate constructed late-game cases; they do not supply terminal outcomes for the early natural changed roots.
- `s1_addendum_results.json`: the 8 family-D changes occur at step150; their verified successor is step151 and the heuristic difference is +27.0. This verifies immediate resource accounting for those constructions, not terminal U ordering under the production continuation.
- `s1_verify3_results.json`: selected roots0, verifications0, valid verifications0. The proposed fourth leg currently supplies no continuation evidence.

**Why the inference fails:** exact terminal settlement arithmetic can coexist with a badly ranked nonterminal heuristic. An argmax can systematically prefer a branch with more next-step cargo whose eventual terminal return is worse. Changing 16 actions proves the override path is live; matching leaf to terminal settlement on unrelated fixtures proves a terminal channel; the conjunction does not prove that any of those 16 overrides is actually better. Similarly, +30 immediate cargo is not a demonstrated positive terminal ΔU. The comparison selects using its own heuristic, so that heuristic's positive difference cannot independently validate its choice.

**Consequence:** approving the proposed “first1–3 legs suffice” option as an unchanged S1 positive-control standard would remove the original ability to catch a search that actively changes valid actions in the wrong direction. This is a **pending-design issue**, not a claim that strategy has already improperly accepted S1: the amendment explicitly awaits a ruling, the stored battery still FAILs, and the status report correctly lists remaining acceptance work.

**Minimal sound paths:**

1. Preserve a known-better positive control with independent exact terminal values and require the real candidate/comparator path to choose the better alternative. A deliberately controlled bad baseline can be a labelled mechanism fixture, provided it is not passed off as a measured improvement of the unchanged Echo4 actor. It should fail under an always-A0 or deliberately reversed-ranking comparator.
2. Alternatively, freeze a new natural-root protocol and obtain actual paired continuation evidence for the selected changed actions with complete policy memory and the authoritative terminal rule. Such evidence can justify the newly defined requirement, with its own exact scope. Do not use unrelated terminal fixtures as its missing return labels.
3. If the strategic choice is deliberately to split “mechanism plumbing passes” from “positive choice not yet proven”, state that change plainly and keep the latter as an open prerequisite. It is not merely a new presentation of already equivalent evidence.

### Registration chronology

The amendment is explicitly motivated by observed failure of the existing positive fixtures and uses the same observed successful activity counts. It is therefore a prospective protocol amendment based on already inspected diagnostic results, not a prospective success under the original rule. Such an amendment is permissible; preserve the original FAIL, distinguish revised claims, freeze the new acceptance procedure before collecting its confirming evidence, and keep S3/S4 unmodified as the amendment already promises. There is no need to accuse p-hacking or invalidate unrelated timing/mechanism checks.

### Minor wording boundary

The phrase “298 根独立真跑” in amendment:19/status can be read as a count of 298 roots, but the source means **roots at step298**. The evidence has 14 part-B rows total, five with `root_step=298`; label it “step298 根” to avoid inflating apparent sample count. This is not scored as an intentional count fabrication.

## Reportable outcome

SI09 and SI10 original contract failures are addressed; MS03 residual and literal truncation fixed. Do not roll these forward as unfixed. Keep the new proposed S1 positive-leg substitution pending: present evidence supports active comparison and some exact terminal mechanics, but does not yet replace independent proof of a genuinely better changed action.
