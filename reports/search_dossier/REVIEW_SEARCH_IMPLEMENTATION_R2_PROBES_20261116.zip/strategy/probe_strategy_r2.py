"""Document-rule replay and committed evidence extraction; no training/matches."""
import collections
import itertools
import json
import pathlib

ROOT = pathlib.Path('/workspace/carbon-league')
def decision(p, lo, hi):
    if lo <= .0760 and hi >= .0890:
        return 'indeterminate_continue35'
    if p < .0760:
        return 'rollback_actor30_fresh_trainer'
    if p >= .0890 and lo > 0:
        return 'harmless_continue35'
    return 'middle_continue35'

values = [-.1, 0, .05, .075, .076, .08, .088, .089, .09, .103, .2]
grid = [(p, lo, hi) for lo,p,hi in itertools.product(values,repeat=3) if lo <= p <= hi]
counts = collections.Counter(decision(*x) for x in grid)
evidence = json.loads((ROOT/'code/search_proto/s1_battery2_formal_evidence.json').read_text())
verify = json.loads((ROOT/'code/search_proto/s1_verify3_results.json').read_text())
addendum = json.loads((ROOT/'code/search_proto/s1_addendum_results.json').read_text())
roots = evidence['roots']
changed = [r for r in roots if r['changed']]
attempts = addendum['part1_collision_escape']['attempts']
changed_d = [a for a in attempts if a.get('changed') and a.get('attempt','').startswith('D_')]
status = (ROOT/'reports/search_dossier/SEARCH_LINE_STATUS_20261116.md').read_text()
prereg = (ROOT/'reports/search_dossier/PREREG_ECHO4_TACTICAL_SEARCH.md').read_text()
out = {
  'baseline': 'b15b475dcc900c84241304a1a5caed2fd428e693',
  'SI09_old_counterexamples': [{'point':p,'ci':[lo,hi],'unique_new_decision':decision(p,lo,hi)} for p,lo,hi in [(.075,.062,.088),(.09,.077,.103),(.075,.062,.090)]],
  'SI09_grid': {'valid_intervals_tested':len(grid),'decision_counts':dict(counts),'unmatched':0,'procedure':'ordered first-match, as stated in lines410-415'},
  'MS03_explicit_H0_main_metric': 'H=0 且确实回 A0 的根按 S3 条记 0 入主尺' in prereg,
  'status_literal_truncation_remaining': '...[truncated 1107 chars]' in status,
  'S1_natural_roots': {'count':len(roots),'changed':len(changed),'steps':[min(r['step'] for r in roots),max(r['step'] for r in roots)],'changed_steps':[min(r['step'] for r in changed),max(r['step'] for r in changed)],'terminal_continuation_rows':len(evidence['verification']),'formal_verdict':evidence['verdict'],'failing_assertions':[a for a in evidence['assertions'] if a['status']=='FAIL']},
  'S1_terminal_fixtures': {'total_part_b_rows':len(evidence['part_b']),'reported_rule':evidence['settlement_rule'],'step298_rows':sum(r.get('root_step')==298 for r in evidence['part_b']),'A4':next(a for a in evidence['assertions'] if a['id']=='A4'),'A5':next(a for a in evidence['assertions'] if a['id']=='A5')},
  'S1_family_D': {'changed':len(changed_d),'root_steps':sorted(set(r['step'] for r in changed_d)),'post_step_counts':sorted(set(o['step_count'] for r in changed_d for o in r['outcomes'].values())),'reported_heuristic_differences':[r['leaf_chosen_minus_a0'] for r in changed_d]},
  'S1_verify3': {'selected_roots':len(verify['selected_roots']),'verifications':len(verify['verifications']),'valid_verifications':verify['valid_verifications']},
  'limitations':'Rule examples are synthetic; S1 counts are extracted from committed artifacts, not an independent rerun; no remote machines inspected.'
}
print(json.dumps(out,ensure_ascii=False,indent=2,allow_nan=False))
