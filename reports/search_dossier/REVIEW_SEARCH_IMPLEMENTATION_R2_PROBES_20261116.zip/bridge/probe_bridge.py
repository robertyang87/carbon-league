import importlib.util, json, pathlib, sys, tempfile, types
import numpy as np
ROOT=pathlib.Path('/workspace/carbon-league'); P=ROOT/'code/search_proto'
sys.path.insert(0,str(P))
import pack_bridge
out={}
with tempfile.TemporaryDirectory() as td:
 pack_bridge.VENDOR_DIR=str(pathlib.Path(td)/'vendor');pack_bridge.VENDOR_PATH=str(pathlib.Path(td)/'vendor/cnet2_search.py')
 out['offline_created']=sorted(pack_bridge.bootstrap_offline(str(ROOT/'code')).keys())
 out['offline_hashes']=pack_bridge.verify_vendor_cache()
 fresh=pack_bridge.load_all_sources();out['clean_load_modules']=sorted(fresh)
 out['clean_np_feat_same_object']=fresh['cnet2_np'].F is fresh['cnet2_feat']
 # Existing arbitrary module comes from another tool/checkpoint import in same interpreter.
 stale=types.ModuleType('cnet2_feat');exec(compile((ROOT/'code/cnet2_feat.py').read_bytes(),'stale_feat','exec'),stale.__dict__)
 stale.LOGC=13.0
 sys.modules['cnet2_feat']=stale
 again=pack_bridge.load_all_sources()
 out['cache_hashes_still_all_pass']=pack_bridge.verify_vendor_cache()
 out['stale_module_survives_in_np']=again['cnet2_np'].F is stale
 out['np_feat_LOGC']=again['cnet2_np'].F.LOGC;out['verified_feat_LOGC']=again['cnet2_feat'].LOGC
 x={'tok_kind':np.zeros(24,dtype=int),'tok_cargo':np.full(24,100.),'tok_pos':np.zeros(24,dtype=int),'hist_cell':np.zeros((24,8),dtype=int),'hist_cargo':np.zeros((24,8)),'hist_move':np.zeros((24,8),dtype=int)}
 out['cargo_feature_for_100']={'actual_np_tok_features':float(again['cnet2_np'].Policy.tok_features(x)[0,6]),'pinned_expected':float(np.log1p(100)/again['cnet2_feat'].LOGC)}
 path=pathlib.Path(pack_bridge.VENDOR_DIR)/'cnet2_search.py';path.write_text('STALE_SENTINEL=True\n')
 try:pack_bridge.verify_vendor_cache();out['cached_sentinel_rejected']=False
 except RuntimeError as e:out['cached_sentinel_rejected']=True;out['cached_sentinel_error']=str(e)
 # Smoke's fetching helper still requires machine-local cache/helper even with checkout pack.
 sys.argv=['smoke_real_s1.py']
 import smoke_real_s1
 smoke_real_s1.PACK_CACHE=str(pathlib.Path(td)/'absent_pack.py')
 try:smoke_real_s1.fetch_pack();out['clean_smoke_fetch_succeeded']=True
 except Exception as e:out['clean_smoke_fetch_succeeded']=False;out['clean_smoke_fetch_error']=type(e).__name__+': '+str(e)
 out['checkout_pack_available']=(ROOT/'code/packs/echo4_int8.py').is_file()
print(json.dumps(out,indent=2))
