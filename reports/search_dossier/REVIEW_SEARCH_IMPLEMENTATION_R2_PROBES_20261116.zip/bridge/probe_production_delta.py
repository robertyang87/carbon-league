import ast,hashlib,importlib.util,json,pathlib,time
import numpy as np
R=pathlib.Path('/workspace/carbon-league')
def literals(p):
 d={}
 for n in ast.parse(p.read_text()).body:
  if isinstance(n,ast.Assign):
   for t in n.targets:
    if isinstance(t,ast.Name):
     try:d[t.id]=ast.literal_eval(n.value)
     except:pass
 return d
p=R/'code/packs/echo4_search_int8.py';o=literals(R/'code/packs/echo4_int8.py');n=literals(p)
out={'source_sha':'ffd813bd152998d7bf494c752f8176e1f6bf9fdb','pack_md5':hashlib.md5(p.read_bytes()).hexdigest(),'pack_bytes':p.stat().st_size,'remaining_bytes':10000000-p.stat().st_size,'same_actor_payload':{k:n[k]==o[k] for k in ['_B1','_Q1','_M1']},'second_payload_duplicates_actor':{k:n[k]==n[k.replace('2','1')] for k in ['_B2','_Q2','_M2']},'embedded_source_md5':{k:hashlib.md5(v.encode()).hexdigest() for k,v in n['_SRC'].items()},'source_identity':{k:n['_SRC'][k]==(R/path).read_text() for k,path in [('cnet2_comparator','code/cnet2_comparator.py'),('cnet2_search','code/search_proto/cnet2_search_cmp.py')]}}
t0=time.perf_counter();spec=importlib.util.spec_from_file_location('review_search_pack',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);out['local_import_s']=time.perf_counter()-t0
sim=m._P['fastsim'].FastCarbon();sim.reset(seed=986499)
t0=time.perf_counter();a=m.agent(sim.obs(0),{});out['local_first_call_s']=time.perf_counter()-t0
out['first_call_action']=a;out['first_call_errors']=m._AG.stats.get('errors',0);out['first_call_cmp_stats']=m._AG.cmp_stats.snapshot();out['loaded_weight_sets']=[None if w is None else len(w) if isinstance(w,dict) else len(w) for w in m._W]
print(json.dumps(out,ensure_ascii=False,indent=2))
