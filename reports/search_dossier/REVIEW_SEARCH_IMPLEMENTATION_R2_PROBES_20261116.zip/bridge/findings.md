# Bridge / bootstrap / S0a follow-up

Frozen source: `b15b475dcc900c84241304a1a5caed2fd428e693`. Read-only repository review; isolated temp vendor copies only; no match, deployment or production source change.

## SI08 disposition: the old bridge counterexamples flip; complete smoke bootstrap remains incomplete

Verified by `probe_bridge.py/json`:

- `bootstrap_offline(code/)` succeeds without `gh_api`, creates all four vendor files, and all four full MD5 values equal the frozen expectations.
- `load_all_sources()` successfully imports the clean cache.
- Replacing the temporary search cache with the original stale sentinel now raises the expected hash mismatch in `verify_vendor_cache()`. The old “trusted cached stale search module” counterexample is closed. `load_all_sources()` tries a pinned online refresh when validation fails; if successful it can recover, but it cannot intentionally load that stale source after validation.

Residual **P2 / fresh-checkout smoke is still machine-cache dependent**: `smoke_real_s1.py:46–55,79–84` accepts only `/tmp/echo4_int8.py` (correct MD5) then imports machine-local `gh_api`. It never tries the tracked `code/packs/echo4_int8.py`, nor accepts a `--pack` parameter. Independent probe uses an absent temporary PACK_CACHE while the exact pinned pack exists in the checkout; `fetch_pack()` raises `ModuleNotFoundError: No module named 'gh_api'`. Consequently the repository README's smoke command still cannot be run from a clean offline checkout after its new vendor bootstrap. The four-source bridge itself is repaired; the complete advertised command path remains incomplete. A minimal remedy is a hash-checked local `--pack`/checkout fallback plus the explicit bootstrap command in README. README lines 18–20 also still advertise the old `s1_battery.py` as formal even though its own file list correctly labels it historical; update that invocation to battery2.

## New P2 / verified vendor sources can still bind an unverified already-imported feature module

Location: `pack_bridge.py:185–210`, particularly load order at L209. `cnet2_np.py:14` imports `cnet2_feat as F`, but bridge explicitly loads **np before feat**. Python therefore reuses any existing `sys.modules['cnet2_feat']`; the later `_load_module('cnet2_feat')` replaces that module slot, but cannot change the `F` reference captured by already-loaded np. Even a clean load creates two independent feat module objects (np auto-imports one, explicit loop replaces it with another).

Reproduction does not alter any vendor bytes: put an independently loaded earlier feature module with LOGC=13.0 in sys.modules, call `load_all_sources`, and verify all four disk hashes still pass. `mods['cnet2_np'].F` remains the earlier module, while returned `mods['cnet2_feat'].LOGC` is pinned 6.5. The actual `Policy.tok_features` cargo feature for 100 becomes **0.3550092578**, versus pinned **0.7100185411**. Thus the helper can report a fully pinned dependency set while executing mixed feature semantics. Load verified feat before np and isolate/restore module names; assert dependency references point to the validated module set.

Scope limit: the current `RealEnvSearch` path uses the Echo4 pack's private embedded modules, not `load_all_sources()`. This is a concrete helper defect and a future integration hazard, **not evidence current S1 numerical results or Echo4 pack were contaminated**.

## SI11 disposition: still open, accurately labelled

Current status §9 calls SI11 prototype debt and §10 explicitly says segment 0 is under construction, no derived package delivered. Its three points (authoritative code/ vs packs mirror order; comparator module embedded/hash-verified; SEARCH=True + ROLL=self/no-roll packing contract) remain unimplemented in source at this frozen HEAD. Do not close SI11, but do not count it as a new contradictory “fixed” claim. Prior targeted note remains applicable.

## S0a original evidence: certificate is consistent; init attribution text is wrong

Artifact `reports/search_dossier/s0a_echo4_cost.json`, MD5 `7f61830aefe337585e5165c13c9a3d54`.

- Its certify source hash `fc33be6cc0255d87d69c8eef8b9a2875` equals current tracked `code/certify_pack.py` bytes. Pack identity `819250bfc82632786063dabd46a616bd` agrees across parent/children/post-read; opponent wrapper and harness identities are also recorded.
- 20 games, seed 993000–993019, 299 measured calls each = 5,980. `side=seed%2` in certify L615 establishes 10 games per seat.
- Effective real cgroup-v2 record: cpu.max `150000 100000`, memory.max `536870912`, scope `/system.slice/s0a-echo4-cost.scope`, not a test override. The parent spawns game children inside this inherited scope; 64 affinity CPUs does not contradict the CPU quota.
- Every per-game slow-step count and overage is zero; max step 93.4 ms, reported PASS is internally consistent. This inspection is evidence verification, not our own resource rerun or a claim about a new search artifact.
- **Cost attribution correction**: status L52 labels exec mean142.6 ms as “解压/反量化/Policy 构造”. Actual artifact mean is142.62 ms, but certify L563–564 only measures pack top-level `exec`. Frozen Echo4 sets `_W=None, _AG=None`; weight dequantization and make_search_agent occur lazily in public `agent` L63–76, measured in first call (`certify` L628–650), whose artifact mean is92.345 ms. Document exec as import/embedded-module compilation/setup, and first call as lazy policy creation plus step0 action. This **does not invalidate the resource PASS**: first-call time was included in the step gate correctly. No moving that lazy work into the init budget is justified.

Evidence files: `probe_bridge.py`, `probe_bridge.json`, `s0a_audit.json`.
