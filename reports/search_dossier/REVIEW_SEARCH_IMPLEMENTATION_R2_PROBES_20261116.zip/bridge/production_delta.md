# Production artifact final delta

Frozen delta HEAD `ffd813bd152998d7bf494c752f8176e1f6bf9fdb`. Read actual artifact and build record; one public first-call smoke only, no match/resource certification.

## What is now delivered and verified

- `code/packs/echo4_search_int8.py` exists, **9,030,752 bytes**, MD5 `be96d457c8c6d5a5da41dea861e4639d`, SHA256 `8078434a3369c22b2bc622c30af527df1248e1c5fe679b550aef9de08375a4b0`. Size/hash match SEG0_BUILD_RECORD.json. It is under 10,000,000 bytes by **969,248 bytes**.
- `_MODS` now includes comparator before search, so the old “comparator missing from single-file” subitem is fixed in this actual artifact.
- All five embedded source hashes independently recompute to the build record. Embedded comparator equals `code/cnet2_comparator.py`; embedded successor search equals `code/search_proto/cnet2_search_cmp.py` byte for byte.
- Actor `_B1`, `_Q1`, `_M1` are each byte/value identical to frozen original Echo4. This is stronger than metadata alone and supports the actor-unchanged claim.
- Import and one public `agent(step0)` call succeed locally, internal errors=0. This root had comparator calls=0, so this establishes only entrypoint viability, not candidate search correctness or resource acceptance. Local import~0.097s, firstcall~0.181s are not platform certification numbers.

## SI11 remains partial: current official artifact verification fails

Executed the repository's existing authoritative verifier:

```
python code/packs/cnet2_search_pack.py --verify-pack code/packs/echo4_search_int8.py --expect-commit ffd813bd --record .../production_verify.json
```

**Exit 1 / ok=false / mismatches=[cnet2_search]**. At this commit the authoritative `code/cnet2_search.py` remains MD5 `94f7fb64...`, while the artifact intentionally embeds successor `664744ef...` from search_proto. The new build record establishes the intended successor identity for manual review, but the release check has not been taught that authority mapping. Both versions may be retained legitimately; register the successor authority explicitly and update the verifier, rather than bypass it.

The verifier additionally still enumerates only its old four-entry MODS list (`code/packs/cnet2_search_pack.py:33,165–184`), so the new comparator is not covered by the automatic authoritative comparison. `_BUILD_HASHES` is absent (the build record honestly notes this); absence is allowed by the current checker and **is not itself the observed failure**. Fix the five-module inventory/source mapping and use a recorded frozen build entry before claiming SI11 closed.

The successor-source generator also hardcodes `~/workspace/search-group/proto/vendor/cnet2_search.py` (`make_search_cmp.py:16–23`); it has pinned-byte checking, but no repository-local source argument. The checked-in artifact is reviewable; a clean-checkout deterministic rebuild still needs a documented/buildable entry rather than relying on this creator-local path and an unstored patch to the packer module list.

## Actual package duplicated the entire actor as the rollout net

`_B2 == _B1`, `_Q2 == _Q1`, `_M2 == _M1` exactly. Each base64 weight blob is 4,394,364 characters. This is a second copy of it20 actor, **not L-vnet33**. The original actor-only Echo4 had an empty B2.

It is not merely dead package padding: successor `make_search_agent` constructs a separate NP.Policy whenever rweights is supplied (`code/search_proto/cnet2_search_cmp.py:663–665`), even with CONF ROLL='self'. Thus the public first call dequantizes and constructs both identical networks. Numerically this can represent the same self rollout, but increases package, loading and memory cost compared with sharing the actor.

The artifact is currently below the hard size limit; **do not label it size FAIL**. However, the earlier estimated 4.7MB heuristic / 8.1–8.3MB critic totals no longer describe this actual construction. With only 969KB free, adding a full extra critic payload will need removal of the duplicate actor or another explicit packaging change and remeasurement. Proper support for SEARCH=True with self rollout and omitted second payload remains the clean resolution of the old NO_ROLL contract gap.

Evidence: `production_verify.json`, `probe_production_delta.py`, `probe_production_delta.json`.

## Final bounded addendum: 0fab1947 / d7878475

No checkout change or further experiment. Git-object reads only.

- `0fab1947` adds `PACK_DEDUP_INVESTIGATION.md`. It acknowledges duplicate weights and reports temporary alias/omission experiments at 4,628,272 / 4,628,271 B. It does **not** replace the checked-in production artifact or update the verifier. Consequently the 9,030,752 B / be96d457 artifact identity, repeated B2 and authority-verifier FAIL above remain unchanged. The document correctly labels future vnet size estimates; these are not a delivered compressed/critic package.
- `d7878475` adds the fp32 vnet extract and manifest. Independently read binary from Git, `allow_pickle=False`: **13,971,852 B**, MD5 `bb9c5b00980c8f36b939c635bfba39f5`; **186 float32 tensors, all finite**; every tensor SHA256/shape/dtype equals manifest; parameter count **3,480,775**, tensor bytes **13,923,100**; key/shape set equals Echo4 actor architecture. Evidence `vnet_finaldelta.json`.
- The original trainer state is not in the repository; source it33 / e3df8f02 provenance is the manifest's recorded claim, not independently re-extracted by this review. NPZ contains no `meta`, so backend configuration must be supplied and bound explicitly at integration. There is still no new backend, critic-bearing production artifact or four-gate acceptance in these commits.
- Update leaf readiness wording to **“fp32 extract now present and internally verified; backend, behavior/calibration/cost/size acceptance pending”**, not “artifact unavailable” and not “critic search ready”.
