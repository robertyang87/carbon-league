import pathlib,sys,contextlib
R=pathlib.Path('/workspace/carbon-league')
sys.path.insert(0,str(R/'code/search_proto'));sys.argv=[sys.argv[0]]
import tests_s1_fix as t
t.fetch_pack=lambda:str(R/'code/packs/echo4_int8.py')
with open('/workspace/search-r2-review-20261116/acceptance/tests_s1_fix.log','w') as f,contextlib.redirect_stdout(f):
 rc=t.main()
print('tests_s1_fix exit',rc)
