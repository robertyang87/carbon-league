import copy,json,pathlib,sys
R=pathlib.Path('/workspace/carbon-league');O=pathlib.Path('/workspace/search-r2-review-20261116/acceptance')
sys.path.insert(0,str(R/'code/search_proto'))
import s1_battery2 as b
x=json.loads((R/'code/search_proto/s1_battery2_formal_evidence.json').read_text())
meta={'settlement_rule':x['settlement_rule'],'evidence_meta_complete':True}
def judge(x):
 aa=b.evaluate_formal(x['summary'],x['roots'],x['part_b'],x['verification'],meta)
 return {'verdict':b.verdict_of(aa),'assertions':aa}
results={'actual_evidence':judge(x),'actual_B_aborts':[{'case':c['case'],'abort_reason':c['abort_reason']}for c in x['part_b'] if c.get('abort_reason')]}
# Explicit synthetic positive controls, to isolate which other failures gate rejects.
y=copy.deepcopy(x)
for c in y['part_b']:
 if c.get('expect_changed') is True:c['expect_met']=True
results['synthetic_positive_control_with_existing_B_overruns']=judge(y)
z=copy.deepcopy(y)
for c in z['part_b']:
 c['abort_reason']=None
 if 'leaf_vs_settlement_max_abs_err' in c:c['leaf_vs_settlement_max_abs_err']=float('nan')
results['synthetic_nan_all_B_settlement_errors']=judge(z)
w=copy.deepcopy(y)
w['part_b']=[{'case':'SYNTHETIC_POS','expect_changed':True,'expect_met':True,'chosen_is_settlement_best':True,'leaf_vs_settlement_max_abs_err':0.}, {'case':'SYNTHETIC_NEG','expect_changed':False,'expect_met':True}]
w['roots']=[w['roots'][0]]
results['synthetic_missing_canonical_cases_one_root_summary48']=judge(w)
c0={'case':'B_capture_step298_seat0','expect_changed':True,'step':298,'me':0,'spec':{'cash':[100,100],'workers':{}}}
c1=copy.deepcopy(c0);c1['step']=100;c1['me']=1
results['fixture_step_seat_omission']={'original':b.fixture_identity([c0],986300,{}),'changed_step_seat':b.fixture_identity([c1],986300,{})}
(O/'gate_probe_results.json').write_text(json.dumps(results,indent=2,ensure_ascii=False))
for name,r in results.items():
 if isinstance(r,dict) and 'verdict' in r:print(name,r['verdict'],[(a['id'],a['status']) for a in r['assertions']])
 else:print(name,json.dumps(r,ensure_ascii=False))
