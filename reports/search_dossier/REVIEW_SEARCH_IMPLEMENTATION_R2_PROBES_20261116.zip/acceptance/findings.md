# Acceptance review R2 (b15b475dcc900c84241304a1a5caed2fd428e693)

Scope: s1_battery2.py, tests_s1_fix.py, committed formal/replay evidence. No source changes. No full natural battery rerun. Tests run from frozen source using local pinned Echo4 package with one BLAS thread; replacing fetch_pack with a local path is the only harness adaptation.

## Verification and what is actually fixed

- Shipped `tests_s1_fix.py`: **15/15 PASS**, exit 0, including terminal boundary/rejection, fresh-seat1, budget covering candidate generation, NaN/Inf and multi-round fallback. Exact log `tests_s1_fix.log`, runner `run_tests.py`.
- Current formal evidence source hashes for the current prototype files match disk at this freeze. Historical wall-limited and replay evidence legitimately name older s1_battery2 hashes; do not label those as current-run corruption.
- Original SI03 counterexample now **FAIL**: committed old replay and latest formal JSON both have overall FAIL. Positive-control failure is no longer ignored. Current formal artifact: 48 natural roots, 3 started games, all four positive capture cases still fail. This is not S1 closure; artifact does not claim otherwise.
- Formal vs diagnostic exit codes now distinct. Atomic evidence publication, run_id, source hash collection and explicit 6-second VM budget reporting are meaningful improvements. VM timing is explicitly not deployment certification.

## RA01 — P2: formal A8 silently ignores real B-case deadline failures

Locations `code/search_proto/s1_battery2.py:367–370`, `:227–245`.

B cases record `abort_reason`, but A8 scans only natural-root aborts and B `error`/`exception`. A negative case that times out and returns A0 gets `expect_met=True`; later unbudgeted leaf measurements can make A4/A5 pass. It was never a successfully completed comparison under the registered call budget, yet the formal “中止与异常计数为 0” assertion is green.

This is not hypothetical: current committed `s1_battery2_formal_evidence.json` contains:

- `B_capture_step297_seat1`: `abort_reason="single_call_overrun"`;
- `B_deposit_step297_seat1`: same abort, `expect_met=true`;
- A8: **PASS**, detail says all abort/exception counts zero.

`probe_gate.py` independently recomputes the actual artifact and reproduces A8 PASS. To isolate this gate from the known still-failing positive controls, an explicitly synthetic test changes only four positive expect_met flags to true while retaining those original aborts: the evaluator returns **overall PASS**. That is a counterexample to the gate, not a claim that the real run passed.

Fix: every B case must record completed rounds/comparisons and include abort/nonfinite/exception status; distinguish successful negative control from failed search falling back to A0. A8 must reject all B aborts, and A3 must require a completed valid comparison where that fixture requires one. Explicit terminal-rejection fixtures have a separate typed contract.

## RA02 — P2 / validation hardening: formal numeric and structural validation remains permissive

Locations `s1_battery2.py:192–214`, `:219–225`, `:247–250`.

- A5 checks only `v is None or v > 1e-6`: **NaN passes**, as do negative “absolute errors”. Controlled probe sets every B settlement error to NaN (with positive controls deliberately made valid as above and aborts cleared); all assertions and overall verdict PASS. Require `math.isfinite(v)` and `0 <= v <= tol`; reject strict-JSON NaN at publication.
- A4/A5 only inspect cases carrying the fields; missing required fields in one or many cases disappear from their denominator. No canonical case roster or uniqueness is checked. A6 is a string declaration, not checked against individual boundary/oracle fields. A7 trusts summary counts rather than cross-checking unique roots and contributing game identities. A9 trusts the caller's boolean rather than validating the assembled evidence.
- Explicit synthetic deletion test keeps only one root (but summary48/3 unchanged), two ad-hoc cases, one of which has neither optimum nor error fields; all nine assertions PASS. This probes `evaluate_formal` directly, **not the CLI --replay path** (replay hardcodes metadata incomplete and therefore cannot formally PASS). Live loops currently normally produce the full roster; this is missing corruption/regression detection, not evidence that the posted live artifact lost rows.

Fix: typed canonical fixtures with per-type required fields (comparison / extinction identity / terminal rejection), exact unique roster matching manifest, recomputed root/game counts and a full-document validator before verdict/write. Retain the useful new source hashes.

## RA03 — P3: fixture fingerprint omits semantically important fields

Location `s1_battery2.py:130–142`.

`fixture_identity()` hashes only case name, expected flag and spec. Current comparison case definitions place `step`, `me`, and `key_uid` outside `spec`. The probe changes step298→100 and seat0→1 while preserving name/spec: identical fixture SHA256 (`8515157c...`). The case name is not an independently enforced encoding of those parameters. It also casts expect_changed=None for terminal-rejection cases into false in the exported list.

Include exact step, seat, horizon, terminal/rejection kind, key IDs, carbon data and all construction parameters in canonical serialized identity; preserve null semantics. Source hashes partially constrain the factory implementation today but do not make this advertised fixture identity self-contained.

## Remaining older helper caveat

v2 still imports b1 constants and calls `b1.verify_changed_root` for saved late roots. With MAX_STEPS_PER_GAME=200 and VERIFY_MIN_STEP=220 this branch remains unreachable; new dedicated verify3 is reviewed separately. Do not apply this old-helper defect to verify3 without inspecting that path. Likewise, formal battery still has no successful positive; that is correctly recorded as FAIL, not a newly concealed failure.

Artifacts:
- `gate_probe_results.json`: actual verdict plus explicitly labeled controlled gate counterexamples.
- `probe_gate.py`: exact standalone lightweight probes.
- `tests_s1_fix.log` and `run_tests.py`: 15/15 suite reproduction.
