import importlib.util,json,pathlib,sys
R=pathlib.Path('/workspace/carbon-league');O=pathlib.Path('/workspace/search-r2-review-20261116/acceptance')
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
old=load('old',R/'code/packs/echo4_int8.py');new=load('new',R/'code/packs/echo4_search_int8.py')
new.CONF['SEARCH']=False
F=old._P['fastsim'].FastCarbon
checks=[]
for seat in (0,1):
 old._AG=None;new._AG=None
 sim=F();sim.reset(seed=986300)
 for step in range(5):
  obs=sim.obs(seat)
  a=old.agent(obs,{});b=new.agent(obs,{})
  checks.append({'seat':seat,'step':step,'equal':a==b})
  sim.step(a if seat==0 else {},a if seat==1 else {})
# Production telemetry on one constructed tactical root. This is only wiring,
# not a successful-benefit fixture or deployment timing.
new.CONF['SEARCH']=True;new._AG=None
sim=F();sim.reset(seed=986300);s=sim.get_state();s['step']=298;s['cash']=[100,100];s['trees']={};s['trees_dict']={};s['carbon']=[0.]*225
s['workers']={'player-0-worker-0':{'player':0,'pos':49,'carbon':44.,'type':'COLLECTOR'},'player-0-worker-1':{'player':0,'pos':160,'carbon':0.,'type':'COLLECTOR'},'player-0-worker-2':{'player':0,'pos':160,'carbon':0.,'type':'COLLECTOR'},'player-1-worker-0':{'player':1,'pos':64,'carbon':8.,'type':'COLLECTOR'},'player-1-worker-1':{'player':1,'pos':70,'carbon':0.,'type':'COLLECTOR'}};s['wid_counter']=[3,2];sim.set_state(s)
a=new.agent(sim.obs(0),{})
x={'no_search_equivalence_checks':checks,'matches':sum(c['equal']for c in checks),'public_stats':new.agent.last_stats,'public_has_cmp_stats':hasattr(new.agent,'cmp_stats'),'private_cmp_stats':new._AG.cmp_stats.snapshot()}
(O/'production_boundary_results.json').write_text(json.dumps(x,indent=2,default=str))
print(json.dumps(x,indent=2,default=str))
