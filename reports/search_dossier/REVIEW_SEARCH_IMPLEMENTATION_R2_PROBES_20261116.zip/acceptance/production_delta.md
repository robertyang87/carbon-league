# Production-delta acceptance audit — ffd813bd152998d7bf494c752f8176e1f6bf9fdb

Bounded lightweight checks only, no deployment/cgroup certification or full battery.

## Identity gate: actual artifact fails the existing source verifier

Executed:

```
python code/packs/cnet2_search_pack.py --verify-pack code/packs/echo4_search_int8.py --expect-commit ffd813bd152998d7bf494c752f8176e1f6bf9fdb --record /workspace/search-r2-review-20261116/acceptance/production_verify_pack.json
```

Exit **1**. Embedded `cnet2_search` is `664744efb27cb8d47f888add77d6ffe4`, while authoritative `code/cnet2_search.py` at this commit is `94f7fb6438bb7577b141e388f068e122`. No released authoritative-source mapping has been provided to the existing gate for the successor generated source. The pack file itself is `be96d457c8c6d5a5da41dea861e4639d`, 9,030,752 bytes, matching SEG0_BUILD_RECORD.

**Do not attribute this failure to missing `_BUILD_HASHES`:** this verifier explicitly tolerates an absent record and verifies extracted source. `certify_pack.py` separately checks whole loaded artifact bytes and never uses `_BUILD_HASHES`; missing stamps alone does not make resource certification fail. However source verifier's fixed `MODS` list contains only the old four modules and ignores the new fifth `cnet2_comparator`, so merely approving the changed search source would still leave the new executable module outside that authority check. Use an explicit five-module successor manifest and recompute hashes from the actual artifact.

## P2: independent comparator telemetry is lost at the public pack boundary

Locations: `code/packs/echo4_search_int8.py:74–77`; generated search `:1736–1746`, `:2148`; `code/eval_v53.py:178`, `:548–550`.

- Generated internal agent exposes `agent.cmp_stats`; wrapper only copies `_AG.stats` to public `agent.last_stats`.
- Actual constructed tactical root: private snapshot reports calls1 / completed_rounds1 / leaf_calls4 / phase costs; public wrapper has **no cmp_stats attribute** and its last_stats has only legacy searched/branches/changed/depth_sum/etc. Thus zero/nonzero leaf work, full completion and abort reasons cannot be independently read by the existing public evaluation channel, even though the private collector is active.
- Existing eval whitelist does not retain these comparator fields. `cmp_guard_err` also fails the evaluator's `errors` or `*_errors` health naming convention; such a guard exception counter would not increase `a_errors`. This naming consequence follows directly from the current producer/consumer code; no exception-injection run was done.
- Fix both producer publication and evaluation serialization, then exercise completed, budget-rejected and failure cases through the final single-file public callable. A private collector check alone does not certify the deployment telemetry path.

Evidence: `probe_production_boundary.py`, `production_boundary_results.json`.

## Limited baseline equality check passed

With the new pack's SEARCH switched off, compared its actual public callable against the original Echo4 callable on 5 sequential states for each seat (10 calls). **10/10 actions identical.** This is a short smoke only; it neither proves full-history guard equivalence nor search-mode correctness, and no timing conclusion is drawn from the shared machine.

## Prototype certificates do not cover this new artifact

`tests_s1_fix.py` imports `search_proto/comparator.py` and `real_env.py`, whereas the pack embeds `cnet2_comparator.py` and generated `cnet2_search_cmp.py`. The existing 15/15 and formal evidence source hashes therefore bind different executable paths. The formal battery remains overall FAIL regardless. Rerun terminal/guard/deadline/finite/positive-control tests against the actual embedded modules and public wrapper before transferring any acceptance claim. Other review lines own the concrete semantic regressions in the generated production code.
