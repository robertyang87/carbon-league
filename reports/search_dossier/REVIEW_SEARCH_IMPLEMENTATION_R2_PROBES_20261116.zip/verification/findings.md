# S1 verification v3 review — b15b475dcc900c84241304a1a5caed2fd428e693

## V3-01 / P1: extinction verification uses prior cash for the extinct player, producing a valid but false outcome

`code/search_proto/s1_verify3.py:275–277` and `:292–294` set the whole final score vector to `cash_before` / `cb` whenever either player becomes extinct. F01 requires a per-seat distinction: extinct seat receives `sim.step_count - episodeSteps - 1`; surviving seat receives pre-transition cash. The same pinned implementation exposes this at `code/cnet2_search.py:665–675`; authoritative `code/eval_v53.py:504–514` agrees. `verify_root:341–344` then marks both completed arms valid without correcting the outcome.

Independent counterexample (`probe_extinction.py`, `extinction_results.json`): real pinned FastCarbon root at step298, own cash10 and last collector with cargo44 adjacent to own base and an enemy lighter collector. Safe DOWN delivers: final margin −46. Alternative RIGHT dies: authoritative final score is [−2,100], margin −102; v3 records [10,100], margin −90. All four root-reproduction checks are true; v3 publishes `valid=true` and Δmargin −44 instead of the correct −56. Policies are deterministic stubs to isolate scoring; transitions, terminal detection, run_arm/verify_root and comparison authority are actual frozen code. This is not a claimed real Echo4 recommendation or performance measurement.

Repair and acceptance: use one authoritative terminal-score/utility helper, with extinction taking priority over time termination, and check both seats / single and double extinction / coincident time boundary. Keep raw margin as explicitly named diagnostic; calculate U separately if claiming registered ΔU. Present v3 output contains only raw score difference, so it is not yet a ΔU gate.

## V3-02 / P2: offline decision re-observes a POST-call opponent snapshot and cold-resets its history

`offline_decide:214–223` installs `rec['post'][seat]` and then calls `harness.begin_step(obs_copy)`. That snapshots the opponent Feat **after it has already observed the root step**. `_build_root` (`real_env.py:411`) subsequently calls `.observe()` on the same observation step. `Feat.observe` resets all memory when `step <= self.step` (`code/cnet2_feat.py:164–167`). Thus the offline decision uses a different opponent model than the declared persistent online comparator even though own f/x/lg0 are restored correctly. The pre-call snapshot was saved but is not used for this reconstruction.

Independent actual-Echo4 check (`probe_offline_memory.py`, `offline_memory_results.json`), natural selfplay root at step11: online opponent prediction for `player-1-worker-1` is LEFT; offline prediction is RIGHT. Four worker history lengths drop 8→1, 34 last-seen-step cells differ, 81 belief cells differ, max estimate discrepancy 38.7573. This short root is an inexpensive mechanism proof; the same reset condition applies unchanged to the intended step240+ roots. No large game or deployment performed.

Repair: own/current root data may use post-call memory, but `_fo_snap` must be cloned from `rec['pre'][seat]['st']['fo']` (or save the exact online xo before it is consumed), and correct seat/game identity must remain explicit. Prove live-online vs offline root opponent inputs, prediction, candidates, scores and chosen action match on persistent-history roots for both seats, not merely baseline A0 restoration.

## V3-03 / P3: restoring guard and st separately breaks their shared guard_base alias

`restore_agent:203–208` deepcopies `st['guard_base']` separately from the copied `guard.__dict__['guard_base']`, losing the alias created by `make_search_agent`. The same structural split is present in `offline_decide:216–220`.

Actual frozen Echo4 probe: before restoration `st['guard_base'] is guard.guard_base` is true; afterward false. Adding base slot10 to the guard no longer appears in st. This is real structural drift, but current Echo4 has BASE_KEY disabled, so do not claim an observed baseline-action regression from it. Rebind st['guard_base'] to the restored guard's set after all copies, and assert alias preservation plus independent sets between arms. Evidence included in `offline_memory_results.json`.

## Fixed or improved, with evidence limits

- v3 does now capture pre-call and post-call strategy state, restore both seats into fresh agents, and enforce root-action reproduction in both arms. This addresses the original cold-start design in the continuation path; it does **not** validate the separate offline-decision restoration (V3-02).
- Regular time termination now stops at terminal step299. Incomplete arms get null/invalid difference. Good changes; F01 still wrong as above.
- Continuation runs the real guard-on agent, and the root opponent executes the actual restored opponent agent response, independent of the offline search's approximate root opponent prediction. Those are distinct measured objects and that distinction is legitimate for an independent real-continuation check.
- Committed `s1_verify3_results.json` contains 58 decisions, **zero changed roots, zero verification arms, zero valid verifications**. No supplied result exercises the repaired restore/continuation path. `s1_verify3_diag.json` has ten roots, all `completed_rounds=0`, `abort_reason=deadline`. These accurately do not establish gains or successful SI07 validation. The diagnostic run covers ten specific roots, not a per-root timing explanation of all58 prior decisions.
- `tie_check` currently returns “未复现 … 无镜像退化迹象” even on an empty verifications list. For this actual artifact it should say no completed arms were available to assess, not interpret missing evidence as a negative result.
- Neither JSON binds source hashes/run_id or saves the actual memory/root snapshots needed to replay selected verification independently. There currently are no selected roots to audit; capture those identities and replay material before treating future v3 results as an acceptance package.

## Additional diagnostic-only defects

`_norm_seat1:237–241` only renames `player-1-` IDs; it does not transform raw LEFT/RIGHT under the game's seat reflection. Perfect mirror action pairs RIGHT/LEFT therefore appear unequal, while same-direction LEFT/LEFT appear equal. This is not a valid mirror metric as written. `tie_analysis:380–385` also deduplicates roots using only (step,seat), omitting seed/game, so equal-step roots from different games can be conflated. These do not change the current zero-arm outcome but must be corrected before reading the mirror diagnostics.
