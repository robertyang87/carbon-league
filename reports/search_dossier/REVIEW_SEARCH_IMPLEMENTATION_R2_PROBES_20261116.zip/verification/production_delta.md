# Production addendum — frozen ffd813bd152998d7bf494c752f8176e1f6bf9fdb

## P2: new exported pack still anchors the deadline after lazy loading, not at public entry

`code/packs/echo4_search_int8.py:60–76` decodes/dequantizes B1 and B2 and constructs both policies before calling `_AG`. Only inner agent `code/search_proto/cnet2_search_cmp.py:835–836` starts the timer. The search segment subtracts elapsed time from that late timer at :1647 and passes a newly formed deadline at :1733. Therefore all first-call weight decoding and policy construction remain outside the claimed whole-public-call envelope.

Actual exported-pack controlled probe: `probe_production_timer.py`, `production_timer_results.json`. With the production CONF unchanged (BUDGET=.7) and a single injected .8s cold-load delay, Comparator still starts **1.0431s after the public entry**, with **.6240s of nominal search deadline remaining**, completes four leaf evaluations, and publishes only .0766s total internal time. This proves a deadline-origin defect; it does not assert that the same latency occurs on the examination machine. Cold load must be migrated into allowed initialization or charged to an absolute public-entry deadline that every layer shares.

## Positive counterexample check: comparator exceptions correctly return A0, not empty actions

The apparent outer `except: return {}` at cnet2_search_cmp:2069–2074 is not the normal path for search failure. `_inner` catches opponent/search exceptions at :1101–1104 and returns its already-produced post-guard `acts`.

`probe_production_fallback.py` injected a RuntimeError from the **actual embedded Comparator.decide**. The exported pack returned exactly the frozen baseline A0 (`worker DOWN`, `base1 RECPLANTER`), recorded `errors=1`, and retained the specific error string. Do not report “search error yields {}” on this evidence. Root/baseline failures before A0 exists remain a distinct legacy fallback case.

## Cross-entry differences requiring independent acceptance

- Production source retains `keep = first min(K,4)` in generation order (:1627), while the corrected prototype's candidate selection is a separate path. Its S1 evidence cannot be borrowed without matching candidate sets, scores, guard outcomes and final actions across both entries.
- The production continuation at :1697–1701 calls raw act_b and directly advances; it does not apply the newly fixed per-seat guard rollout. Current exported CMP_H=1 does not enter that continuation, so this is an H≥2 enablement blocker, not proof of a current H1 runtime error.
- Exported B2 is byte-identical to B1, despite ROLL='self'. The pack still decodes it and constructs a second policy. This is avoidable size/initialization/memory overhead; no unsupported claim that the 10MB/RSS limits are currently exceeded.
- Root opponent action is generated before candidate simulation from the real agent's live fo and current xo; this production path does not use verify3's faulty post-call reconstruction. The old v3 bug therefore does not automatically transfer to this production entry.

Evidence was generated locally and source files were not changed. No deployment or full games were run.
