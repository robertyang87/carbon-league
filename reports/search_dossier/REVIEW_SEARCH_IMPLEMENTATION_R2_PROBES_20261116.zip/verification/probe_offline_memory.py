import sys,json,copy
from pathlib import Path
import numpy as np
sys.path.insert(0,'/workspace/carbon-league/code/search_proto')
import real_env,s1_verify3 as v3
PACK='/workspace/carbon-league/code/packs/echo4_int8.py'
ps=[];ags=[];hs=[]
for _ in range(2):
 p,a=real_env.load_pack(PACK);ps.append(p);ags.append(a);hs.append(real_env.RealEnvSearch(a))
FC=hs[0].inx.FastCarbon;fc=hs[0].inx.mod['feat_copy'];sim=FC();sim.reset(seed=986400)
for step in range(12):
 obs=[sim.obs(0),sim.obs(1)]
 pre=[v3.snapshot_memory(ags[s],fc) for s in range(2)] if step==11 else None
 for s in range(2): hs[s].begin_step(obs[s])
 acts=[ags[s](obs[s]) for s in range(2)]
 if step==11:
  post=[v3.snapshot_memory(ags[s],fc) for s in range(2)]
  root=hs[0]._build_root(obs[0],acts[0])
  expected={'acts_o':root.acts_o,'hist_lengths':{k:len(v) for k,v in hs[0]._fo_snap.hist.items()},'last_step':hs[0]._fo_snap.last_step.copy(),'est':hs[0]._fo_snap.est.copy()}
  rec={'seat':0,'obs':obs,'pre':pre,'post':post,'a0':acts[0],'base_cost':0.0,'scenario_seed':986400+step}
  break
 sim.step(*acts)
p,a=real_env.load_pack(PACK);off=real_env.RealEnvSearch(a);captured={};orig=off._build_root
def observe_root(ob,ac):
 rr=orig(ob,ac);captured.update({'acts_o':rr.acts_o,'hist_lengths':{k:len(v) for k,v in off._fo_snap.hist.items()},'last_step':off._fo_snap.last_step.copy(),'est':off._fo_snap.est.copy()});return rr
off._build_root=observe_root
v3.offline_decide(off,rec,fc)
# Alias preservation is a separate structural invariant.
p,rest=real_env.load_pack(PACK);ri=real_env.extract_internals(rest)
before=ri.st['guard_base'] is ri.guard.guard_base
v3.restore_agent(rest,pre[0],fc)
after=ri.st['guard_base'] is ri.guard.guard_base
ri.guard.guard_base.add(10)
propagates=10 in ri.st['guard_base']
out={'source_sha':'b15b475dcc900c84241304a1a5caed2fd428e693','root_step':11,'online':{k:v for k,v in expected.items() if k not in ('last_step','est')},'offline':{k:v for k,v in captured.items() if k not in ('last_step','est')},'changed_last_step_cells':int(np.sum(expected['last_step']!=captured['last_step'])),'changed_est_cells':int(np.sum(expected['est']!=captured['est'])),'max_est_difference':float(np.max(np.abs(expected['est']-captured['est']))),'guard_alias':{'before':before,'after':after,'mutation_propagates':propagates}}
assert expected['hist_lengths']!=captured['hist_lengths']
assert before and not after and not propagates
print(json.dumps(out,indent=2));Path('/workspace/search-r2-review-20261116/verification/offline_memory_results.json').write_text(json.dumps(out,indent=2)+'\n')
