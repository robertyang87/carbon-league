import importlib.util,sys,json
from pathlib import Path
sys.path.insert(0,'/workspace/carbon-league/code/search_proto')
import real_env
P='/workspace/carbon-league/code/packs/echo4_search_int8.py'
spec=importlib.util.spec_from_file_location('review_cmp_fallback',P);p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
FC=p._P['fastsim'].FastCarbon;s=FC();s.reset(seed=986201);q=s.get_state();q['step']=100;q['cash']=[100,100];q['carbon']=[0.0]*225
q['workers']={'player-0-worker-0':{'player':0,'pos':49,'carbon':44.0,'type':'COLLECTOR'},'player-1-worker-0':{'player':1,'pos':50,'carbon':8.0,'type':'COLLECTOR'}}
q['wid_counter']=[1,1];q['trees']={};q['trees_dict']={};q['tid_counter']=[0,0];s.set_state(q)
_,base=real_env.load_pack('/workspace/carbon-league/code/packs/echo4_int8.py');a0=base(s.obs(0))
def broken(*a,**kw):raise RuntimeError('review injected comparator failure')
p._S.Comparator.decide=broken
actual=p.agent(s.obs(0),None)
out={'source_sha':'ffd813bd152998d7bf494c752f8176e1f6bf9fdb','baseline_a0':a0,'actual':actual,'equal':actual==a0,'errors':p._AG.stats['errors'],'last_error':p._AG.stats['last_error']}
assert a0 and actual==a0 and out['errors']==1
print(json.dumps(out,indent=2));Path('/workspace/search-r2-review-20261116/verification/production_fallback_results.json').write_text(json.dumps(out,indent=2)+'\n')
