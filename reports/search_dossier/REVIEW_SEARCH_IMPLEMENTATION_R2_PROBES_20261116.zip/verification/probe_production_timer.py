import importlib.util,time,json,sys
from pathlib import Path
P='/workspace/carbon-league/code/packs/echo4_search_int8.py'
spec=importlib.util.spec_from_file_location('review_cmp_pack',P);p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
FC=p._P['fastsim'].FastCarbon;s=FC();s.reset(seed=986201);q=s.get_state();q['step']=100;q['cash']=[100,100];q['carbon']=[0.0]*225
q['workers']={'player-0-worker-0':{'player':0,'pos':49,'carbon':44.0,'type':'COLLECTOR'},'player-1-worker-0':{'player':1,'pos':50,'carbon':8.0,'type':'COLLECTOR'}}
q['wid_counter']=[1,1];q['trees']={};q['trees_dict']={};q['tid_counter']=[0,0];s.set_state(q)
# Controlled cold-start delay, not a hardware throughput claim.
orig_d=p._dequantize; counter=[0]
def delayed(*a):
 counter[0]+=1
 if counter[0]==1: time.sleep(0.8)
 return orig_d(*a)
p._dequantize=delayed
orig=p._S.Comparator.decide; calls=[];pubstart=[0]
def observed(self,*a,**kw):
 calls.append({'elapsed_from_public':time.monotonic()-pubstart[0],'remaining_deadline':kw['deadline']-time.monotonic(),'budget':p.CONF['BUDGET']})
 return orig(self,*a,**kw)
p._S.Comparator.decide=observed
pubstart[0]=time.monotonic();outacts=p.agent(s.obs(0),None);duration=time.monotonic()-pubstart[0]
out={'source_sha':'ffd813bd152998d7bf494c752f8176e1f6bf9fdb','controlled_load_delay_s':0.8,'public_elapsed_s':duration,'comparator_calls':calls,'actions':outacts,'cmp_stats':p._AG.cmp_stats.snapshot(),'errors':p._AG.stats['errors'],'b2_is_duplicate_b1':p._B2==p._B1}
assert calls and calls[0]['elapsed_from_public']>p.CONF['BUDGET'] and calls[0]['remaining_deadline']>0
print(json.dumps(out,indent=2));Path('/workspace/search-r2-review-20261116/verification/production_timer_results.json').write_text(json.dumps(out,indent=2)+'\n')
