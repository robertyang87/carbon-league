import sys,json,types
from pathlib import Path
sys.path.insert(0,'/workspace/carbon-league/code/search_proto')
import real_env, s1_verify3 as v3
pack,base=real_env.load_pack('/workspace/carbon-league/code/packs/echo4_int8.py')
h=real_env.RealEnvSearch(base); FC=h.inx.FastCarbon
sim=FC();sim.reset(seed=986200);q=sim.get_state();q['step']=298;q['cash']=[10,100];q['carbon']=[0.0]*225
q['workers']={'player-0-worker-0':{'player':0,'pos':49,'carbon':44.0,'type':'COLLECTOR'},'player-1-worker-0':{'player':1,'pos':50,'carbon':8.0,'type':'COLLECTOR'}}
q['wid_counter']=[1,1];q['trees']={};q['trees_dict']={};q['tid_counter']=[0,0];sim.set_state(q)
a0={'player-0-worker-0':'DOWN'}; chosen={'player-0-worker-0':'RIGHT'}
rec={'game':0,'seed':986200,'step':298,'seat':0,'sim_state':sim.get_state(),'obs':[sim.obs(0),sim.obs(1)],'pre':[None,None],'a0':a0,'opp_a0':{},'dec':types.SimpleNamespace(chosen_index=1,action=chosen)}
# Isolate terminal scoring with two deterministic frozen policies; real FastCarbon transition,
# real new verify_root/run_arm and pinned authoritative terminal/leaf functions.
count=[0]
def fresh(_):
 seat=count[0]%2; count[0]+=1
 return lambda obs: dict(a0) if seat==0 else {}
v3.make_fresh_agent=fresh; v3.restore_agent=lambda *a:None
r=v3.verify_root('unused',FC,h.inx.terminal_fn,h.inx.mod['feat_copy'],rec)
expected={}
for label,act in [('a0',a0),('chosen',chosen)]:
 s=FC();s.set_state(q);pre=list(s.cash);s.step(act,{})
 expected[label]={'step':s.step_count,'extinct':h.inx.terminal_fn(s),'margin':h.inx.leaf_fn(s,0,0,pre),'post_cash':list(s.cash)}
expected_delta=expected['chosen']['margin']-expected['a0']['margin']
out={'source_sha':'b15b475dcc900c84241304a1a5caed2fd428e693','verification':r,'authority':expected,'expected_delta':expected_delta,'actual_delta':r['chosen_minus_a0_final_diff']}
assert r['valid'] is True and out['actual_delta']!=expected_delta
print(json.dumps(out,indent=2));Path('/workspace/search-r2-review-20261116/verification/extinction_results.json').write_text(json.dumps(out,indent=2)+'\n')
