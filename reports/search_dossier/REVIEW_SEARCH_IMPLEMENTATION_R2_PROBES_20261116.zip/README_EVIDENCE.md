# Echo4 搜索第二轮复核证据

主轮代码冻结 b15b475dcc900c84241304a1a5caed2fd428e693；生产包与协议增量已六线追加复核到 ffd813bd152998d7bf494c752f8176e1f6bf9fdb。最终收尾核对到 d7878475cf7f4c80d6635a261beadc16903826aa；其中vnet U标签文档已修，R2-11以主报告最新收窄范围为准。复现全套请检出最终版本。
最终结论与R2-01至R2-12编号以仓内 REVIEW_SEARCH_IMPLEMENTATION_R2_20261116.md 为准。
各线findings.md保留独立审查笔记，不把其局部编号重复计为新问题。

需要Python3.12、NumPy1.26.4；仓库含code/search_proto、code/packs/echo4_int8.py、四件权威源和reports。
本包不含训练权重、凭据或生产改动。所有实际包读取均来自你自己的仓库；远端机器未在本轮直读。

```sh
python RUN_REVIEW_PROBES.py --repo /path/to/carbon-league comparator
python RUN_REVIEW_PROBES.py --repo /path/to/carbon-league environment
python RUN_REVIEW_PROBES.py --repo /path/to/carbon-league extinction
python RUN_REVIEW_PROBES.py --repo /path/to/carbon-league memory
python RUN_REVIEW_PROBES.py --repo /path/to/carbon-league gate
python RUN_REVIEW_PROBES.py --repo /path/to/carbon-league suite
python RUN_REVIEW_PROBES.py --repo /path/to/carbon-league bridge
python RUN_REVIEW_PROBES.py --repo /path/to/carbon-league strategy
```

Runner仅在临时脚本副本替换原评审路径；不修改业务源码，输出更新在解压的证据目录。请在复跑前保留原始结果副本。
对修复后的main复跑须记录新SHA，历史反例结果不自动等于新版本仍有问题。

environment含真实Echo4/FastCarbon终局和席位验证；其guard行为反例用受控动作标签＋真实guard/模拟器。
extinction用策略桩隔离真实verify3终局结算，不能读作Echo4实战选择。
memory使用真实短局；gate含当前提交工件重算和明确标注的合成输入；comparator时钟为确定性注入，不是性能实测。
suite为原15例修复测试，通过本地钉版pack代替网络fetch，未跑完整正式电池。
bridge仅在隔离临时副本测试加载，四源磁盘hash不受污染；s0a_audit.json是原认证证书的核验，不是新认证。

root/是主审对关键反例的复跑输出。所有长期比赛、训练、部署均未执行。

生产增量探针：将上面的probe参数换为 production-comparator、production-environment、production-boundary、production-timer、production-fallback、production-bridge 或 production-strategy。production-timer的0.8秒为受控注入延迟，不是部署硬件性能测量；production-strategy是标明的合成反例。production-environment已使用实际生产内嵌模块依赖，初次错误注入原型依赖的TypeError不属于发现。
