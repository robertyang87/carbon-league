# 审查期间新增生成件复核

追加冻结 SHA：`ffd813bd152998d7bf494c752f8176e1f6bf9fdb`。
范围：`code/search_proto/make_search_cmp.py`、其生成件 `cnet2_search_cmp.py`，实际依赖为 `code/cnet2_comparator.py`（**不是** `code/search_proto/comparator.py`）。真实 Echo4 原包权重，单个构造根，不跑整局。探针 `probe_production_delta.py`，结果 `production_results.json`。

## 1. 生成路径没有搬入 SI04，H≥2 再次直接裸网续弈（P2，原项跨入口残留）

- 生成件 `cnet2_search_cmp.py:1697–1705`、生成器 `make_search_cmp.py:135–143`：act_b → to_actions → step，没有任何分席守卫快照和 apply。
- 这与修复版 real_env 至少“会调用续弈守卫”的行为不一致；不能继承其 S1 验收。
- 实际生产依赖、原包权重、生成代码，设置 SEARCH=True/CMP_H=2/BUDGET=20：正常完成一轮，errors0、branches4、changed1。
- 在 Comparator 调用边界做只读计数：act_b=4次，guard.apply=0次。根候选guard_screen在Comparator外，不混入此计数。计数包装器没有替换动作、叶值或时限参数。
- 必须先修 real_env 的守卫历史归属，再把同一经过测试的续弈实现纳入生产生成件；不要复制两份不同版本算法。

## 2. 候选集合改变，原型验收不能认证生成件（P2）

- `cnet2_search_cmp.py:1625–1627` 明确按生成顺序截前4个；生成器 `63–65` 固化同逻辑。
- `real_env.py:491–500` 按根先验lg0选三替代动作。两种方案不是等价重构；生成顺序主要是动作枚举编号，而不是先验排序。
- 相同真实包、相同root、A0为DOWN：
  - 修复原型候选 `[DOWN, UP, RIGHT, LEFT]`；
  - 生成件候选 `[DOWN, NONE, UP, RIGHT]`。
- 候选联合动作的后续基地动作也由真实Prefix重新解码，详见JSON；这里不是只比较标签命名。
- 需明确注册生产候选机制，并对实际生产模块重跑机制/计时/续弈验证。不能将原型的候选选择收益、改子率、测试通过状态直接移给这个不同比较器。

## 正向确认与范围

- **deadline调用签名实际兼容**：生产 `code/cnet2_comparator.py` 接受deadline。最初误接到原型Comparator时曾产生TypeError，那是探针接错依赖，已撤销，不是仓库问题。最终证据与探针均已使用真实生产依赖并复跑 errors0。
- 生成件已加入 step299 冻结及灭绝 pre_cash处理，未把已关闭的原始时间越界重新登记为错误。
- 纯到时叶仍通过旧leaf(left=0, prev_cash=None)而非real_env显式final_cash分流；本轮未构造有效可达状态上的数值差异，因此不单列已证缺陷。
- 无业务源码修改；设置20秒预算只用于避免本机计时遮挡机制，不能引用为部署计时认证。
