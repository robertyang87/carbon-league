import sys,json,dataclasses
from pathlib import Path
import numpy as np
sys.path.insert(0,'/workspace/carbon-league/code/search_proto'); import real_env
PACK='/workspace/carbon-league/code/packs/echo4_int8.py'
OUT=Path('/workspace/search-r2-review-20261116/real_env')
def fresh(step=100,seat=0,cash=(100,100),positions=(49,50),cargo=(44,8)):
 p,a=real_env.load_pack(PACK);h=real_env.RealEnvSearch(a);s=h.inx.FastCarbon();s.reset(seed=986201);q=s.get_state();q.update(step=step,cash=list(cash),carbon=[0.0]*225,trees={},trees_dict={},tid_counter=[0,0],wid_counter=[1,1]);q['workers']={f'player-{i}-worker-0':{'player':i,'pos':positions[i],'carbon':float(cargo[i]),'type':'COLLECTOR'} for i in(0,1)};s.set_state(q);obs=s.obs(seat);h.begin_step(obs);a0=a(obs);return a,h,s,obs,a0
out={}
# Correct terminal freeze at valid root and rejection before private builder for already-terminal roots.
for seat in(0,1):
 a,h,s,obs,a0=fresh(298,seat);r=h._build_root(obs,a0);run=h._make_rollout(r);records=[]
 calls=[0];orig=h.inx.mod['act_b']
 def spy(*a,**kw):calls[0]+=1;return orig(*a,**kw)
 h.inx.mod['act_b']=spy
 for H in(1,2,3):
  ls=run(r.full,a0,H,0);records.append({'H':H,'step':ls.sim.step_count,'leaf':h._raw_leaf(ls),'terminal_kind':ls.terminal_kind,'cash':list(ls.sim.cash),'continuation_calls':calls[0]})
 h.inx.mod['act_b']=orig
 for step in(299,300):
  obs2=dict(obs,step=step);assert h.decide_at_root(obs2,a0,0.0) is None
 out[f'terminal_seat{seat}']={'horizons':records,'terminal_roots_rejected':h.terminal_roots_rejected}
# Fresh late seat1 now obtains true opponent identifiers.
a,h,s,obs,a0=fresh(100,1);r=h._build_root(obs,a0);out['fresh_seat1']={'snapshot_seat':h._fo_snap.seat,'acts_o':r.acts_o};assert h._fo_snap.seat==0 and all(k.startswith('player-0-') for k in r.acts_o)
# Independent histories are not independent if the initial payload is copied from wrong seat.
for seat in(0,1):
 a,h,s,obs,a0=fresh(100,seat,cash=(10,10),positions=(112,113),cargo=(0,100));r=h._build_root(obs,a0);r=dataclasses.replace(r,acts_o={});orig=h.inx.mod['act_b'];guard0=h.inx.guard;records=[]
 def fixed(pol,xs,aux,teachers,forced=None):
  labs=[]
  for x in xs:
   lab=np.where(x['tok_mask'][:12],0,-1).astype(np.int64);labs.append(lab)
  # Force absolute player1 collector LEFT into player0; current direction reflected in seat1 frame.
  target=1 if seat==0 else 0
  labs[target][0]=h.inx.F.CANON_MOVE[4] # global LEFT (MOVES[4]); seat1 canonical RIGHT
  return np.stack(labs)
 h.inx.mod['act_b']=fixed
 bad=h._make_rollout(r)(r.full,{},2,0)
 actual={'step':bad.sim.step_count,'leaf':h._raw_leaf(bad),'kind':bad.terminal_kind,'workers':{u:int(w.pos) for u,w in bad.sim.workers.items()},'guards':[{'lostw':g.lostw,'prevw':sorted(g.prevw)} for g in h._last_rollout_guards]}
 # Reference: own history is original; opposing history belongs to that opposing seat, no historical losses.
 other=h.inx.mod['BankruptcyGuard'](h.cfg);other.prevw={f'player-{1-seat}-worker-0'}
 class CorrectCopies:
  def __init__(self):self.i=0
  def copy(self):
   g=guard0 if self.i%2==0 else other;self.i+=1;return g.copy()
 h.inx.guard=CorrectCopies();good=h._make_rollout(r)(r.full,{},2,0)
 reference={'step':good.sim.step_count,'leaf':h._raw_leaf(good),'kind':good.terminal_kind,'workers':{u:int(w.pos) for u,w in good.sim.workers.items()},'guards':[{'lostw':g.lostw,'prevw':sorted(g.prevw)} for g in h._last_rollout_guards]}
 h.inx.guard=guard0;h.inx.mod['act_b']=orig
 out[f'guard_history_seat{seat}']={'root_own_guard':{'lostw':guard0.lostw,'prevw':sorted(guard0.prevw)},'actual':actual,'reference':reference,'probe_note':'act_b labels controlled to force visible risk; actual BankruptcyGuard and FastCarbon are production implementations; no claimed natural occurrence frequency'}
print(json.dumps(out,indent=2));(OUT/'results.json').write_text(json.dumps(out,indent=2)+'\n')
