import sys,types,importlib.util,json,base64,zlib
from pathlib import Path
import numpy as np
sys.path[:0]=['/workspace/carbon-league/code/search_proto','/workspace/carbon-league/code']
import real_env, comparator,leaf_adapters,telemetry
pack,base_agent=real_env.load_pack('/workspace/carbon-league/code/packs/echo4_int8.py');h=real_env.RealEnvSearch(base_agent)
w=pack._dequantize(zlib.decompress(base64.b64decode(pack._B1)),pack._Q1);w['meta']=np.array(pack._M1)
import cnet2_comparator as production_comparator
spec=importlib.util.spec_from_file_location('delta_search','/workspace/carbon-league/code/search_proto/cnet2_search_cmp.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
s=h.inx.FastCarbon();s.reset(seed=986201);q=s.get_state();q.update(step=100,cash=[100,100],carbon=[0.0]*225,trees={},trees_dict={},tid_counter=[0,0],wid_counter=[1,1]);q['workers']={'player-0-worker-0':{'player':0,'pos':49,'carbon':44.,'type':'COLLECTOR'},'player-1-worker-0':{'player':1,'pos':50,'carbon':8.,'type':'COLLECTOR'}};s.set_state(q);obs=s.obs(0)
h.begin_step(obs);a0=base_agent(obs);root=h._build_root(obs,a0);expected=h._gen_candidates_raw(root,a0)[0]
conf=dict(pack.CONF,SEARCH=True,BUDGET=20.,CMP_H=2)
a=mod.make_search_agent(conf,weights=w);actual=a(obs)
out={'baseline':a0,'actual_generated_action':actual,'generated_last_stats':a.last_stats,'harness_candidates':expected,'probe_setup':'actual code/cnet2_comparator.py dependency, original generated code unchanged'}
# Instrument actual production dependency boundary without adapting signatures.
counts={'guard':0,'act_b':0};ga=mod.BankruptcyGuard.apply;ab=mod.act_b
class Capture(production_comparator.Comparator):
 def decide(self,*args,**kw):
  out['generated_candidates']=[c.action for c in args[1]]
  before=dict(counts)
  ans=super().decide(*args,**kw)
  out['production_counter_probe']={'completed':ans.completed_rounds,'guard_apply_inside_comparator':counts['guard']-before['guard'],'act_b_inside_comparator':counts['act_b']-before['act_b'],'changed':ans.changed}
  return ans
def guardspy(self,*args,**kw):counts['guard']+=1;return ga(self,*args,**kw)
def abspy(*args,**kw):counts['act_b']+=1;return ab(*args,**kw)
mod.Comparator=Capture;mod.BankruptcyGuard.apply=guardspy;mod.act_b=abspy
b=mod.make_search_agent(conf,weights=w);b(obs)
mod.BankruptcyGuard.apply=ga;mod.act_b=ab
print(json.dumps(out,indent=2));Path('/workspace/search-r2-review-20261116/real_env/production_results.json').write_text(json.dumps(out,indent=2)+'\n')
