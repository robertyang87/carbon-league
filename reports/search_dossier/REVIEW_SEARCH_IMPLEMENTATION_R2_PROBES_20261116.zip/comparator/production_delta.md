# Bounded production-module delta at ffd813bd

Reviewed latest local HEAD `ffd813bd152998d7bf494c752f8176e1f6bf9fdb`, especially newly added `code/cnet2_comparator.py`. Existing prototype fixes remain present. Independent direct comparison is saved in `probe_production_delta.py` / `production_delta_results.json`.

## P2: new production fork carries the pre-SI06 / pre-anytime implementation

The production module is not a bundling of the fixed prototype. It has forked old behavior:

| Contract | Fixed search_proto version | New code/cnet2_comparator.py |
|---|---|---|
| NaN/Inf rejects whole round | yes | no finite check; unchecked values :215 then normal commit :223–232 |
| runtime callback error→typed abort | catches rollout/leaf | direct callback calls :202/:211, exceptions escape |
| vnet Inf checked before tanh | yes | :398–399 maps Inf to valid 1.0 |
| anytime H1→H2 fallback | decide_multi present | only single-horizon decide :153–232 |
| admission cost parameter | est_candidate_cost_s | absent |
| absolute deadline API | deadline_abs | deadline (different signature) |

Independent same-input results:

- Values A0=.1 / alternative=+Inf: prototype returns A0/nonfinite_leaf/0 rounds; production selects alternative, 1 completed round, abort_reason=None.
- A0=NaN / alternative=.9: prototype rejects; production reports 1 completed round with A0, abort_reason=None.
- Runtime rollout exception: prototype produces safe error decision; production raises RuntimeError.
- VNet backend +Inf: prototype passes Inf through for comparator rejection and counts it; production returns1.0 with no nonfinite counter.

This is a **cross-entry regression**, not a reason to withdraw the correct closure of SI06 in the prototype. Certification/pack integration must use one canonical implementation and rerun SI06/anytime tests against the actually imported/embedded module. `tests_s1_fix.py` tests `comparator` from search_proto and cannot certify `cnet2_comparator` automatically.

### Runtime exception scope, precisely

Generated production search imports this new module (`code/search_proto/cnet2_search_cmp.py:70`) and calls it at :1730. Its enclosing agent catches search exceptions at :1101–1104 and returns the existing baseline actions. Therefore **do not claim a callback error necessarily crashes the game**. However, control bypasses comparator telemetry publication at :1736–1746; it records only general `stats[errors/last_error]`, loses the typed comparator abort record, and cannot retain a previous completed round (none exists). Nonfinite output does not throw, so outer catch does not repair the invalid successful-comparison result.

## Deadline findings: transfer carefully

- New module itself honors an explicitly passed absolute `deadline` and does not top up. It has no admission controller whatsoever. A long indivisible callback can still overrun before post-call detection. No platform failure is asserted here.
- Generated wiring measures `rem = BUDGET - (clk()-t0)` at :1647 after candidate generation/guard, and passes `time.monotonic()+rem` at :1733. This continues the late-check problem: already-exhausted baseline/preparation is not rejected before expensive preparation. Also rem is sampled before comparator setup, so the absolute deadline is recomputed after those setup instructions, instead of carrying one immutable deadline.
- `_inner` obtains t0 at :835–836, with `clk=time.time` by default (:833; CLOCK=wall). It is not yet proof of a whole packed public-call deadline: outer wrapper / lazy weight load precedes the inner entry, and output/outer layers follow it. Pack reviewer should establish actual initialization placement; do not inherit prototype's separate begin_step-snapshot leak literally because generated production path has no such external begin_step API.
- Prototype's C_hi global-mean problem is replaced here by **no C_hi input/gate at all**; neither implementation is resource-certified. Anytime production absent should be marked outstanding while prototype's implementation is credited as complete.

No business files changed. Direct probes do not run matches, load actor weights or claim measured game benefit.
