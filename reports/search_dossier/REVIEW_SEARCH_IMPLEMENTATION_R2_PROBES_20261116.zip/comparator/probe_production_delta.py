import sys,json,dataclasses,inspect,math
from pathlib import Path
sys.path[:0]=['/workspace/carbon-league/code','/workspace/carbon-league/code/search_proto']
import cnet2_comparator as prod
import comparator as proto
import leaf_adapters as p_leaf
rows={}
for label,module in [('fixed_prototype',proto),('new_production',prod)]:
 cs=[module.Candidate(0,'a0',True),module.Candidate(1,'a1',False)]
 out={'has_decide_multi':hasattr(module.Comparator,'decide_multi'),'decide_signature':str(inspect.signature(module.Comparator.decide)),'cases':{}}
 for key,vals in [('infinite_alternative',[.1,float('inf')]),('nan_baseline',[float('nan'),.9])]:
  d=module.Comparator(1.).decide(None,cs,lambda s,a,h,se:a,lambda a:vals[0 if a=='a0' else 1],1,0)
  out['cases'][key]=dataclasses.asdict(d)
 try:
  module.Comparator(1.).decide(None,cs,lambda s,a,h,se:(_ for _ in ()).throw(RuntimeError('probe')),lambda a:.5,1,0)
  out['cases']['exception']='handled'
 except Exception as exc:out['cases']['exception']={'escaped':type(exc).__name__}
 rows[label]=out
for label,module in [('fixed_prototype',p_leaf),('new_production',prod)]:
 v=module.VNetLeafAdapter(33,'probe',lambda s:float('inf'));z=v(None)
 rows[label]['vnet_inf_output']=z if math.isfinite(z) else str(z)
 rows[label]['vnet_tracks_nonfinite']=hasattr(v,'nonfinite_count')
p=Path('/workspace/search-r2-review-20261116/comparator/production_delta_results.json');p.write_text(json.dumps(rows,indent=2,allow_nan=False)+'\n');print(p.read_text())
