import sys, json, dataclasses
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,'/workspace/carbon-league/code/search_proto')
import comparator
from comparator import Candidate, Comparator
from telemetry import StatsCollector
from leaf_adapters import HeuristicLeafAdapter, VNetLeafAdapter
from real_env import RealEnvSearch

class Clock:
 def __init__(self):self.t=0.
 def now(self):return self.t
 def tick(self,dt):self.t+=dt
clock=Clock();orig=comparator.time.monotonic;comparator.time.monotonic=clock.now
cands=[Candidate(0,'a0',True),Candidate(1,'a1',False)]
rows={}
def ds(d):return dataclasses.asdict(d) if d else None
try:
 for val in [float('nan'),float('inf'),float('-inf')]:
  clock.t=0
  for kind in ['raw','heuristic','vnet']:
   leaf=lambda a:.1 if a=='a0' else val
   if kind=='heuristic':leaf=HeuristicLeafAdapter(leaf)
   if kind=='vnet':leaf=VNetLeafAdapter(33,'probe',leaf)
   d=Comparator(.1).decide(None,cands,lambda s,a,h,se:a,leaf,1,0)
   assert d.chosen_index==0 and d.completed_rounds==0 and d.abort_reason=='nonfinite_leaf'
   rows[f'numeric_{str(val)}_{kind}']=ds(d)
 for where in ['rollout','leaf']:
  clock.t=0
  def roll(s,a,h,se):
   if where=='rollout':raise RuntimeError('rollout failure')
   return a
  def leaf(a):raise ValueError('leaf failure')
  d=Comparator(.1).decide(None,cands,roll,leaf,1,0)
  assert d.chosen_index==0 and d.abort_reason=='exception'
  rows[f'callback_exception_{where}']=ds(d)
 for fail in ['overrun','exception','nonfinite']:
  clock.t=0
  def roll(s,a,h,se):
   clock.tick(.001 if h==1 else (.04 if fail=='overrun' else .001))
   if h==2 and a=='a1' and fail=='exception':raise RuntimeError('later round')
   return a,h
  def leaf(x):
   a,h=x
   if h==2 and a=='a1' and fail=='nonfinite':return float('nan')
   return (.9 if a=='a1' else .1) if h==1 else (.9 if a=='a0' else .1)
  d=Comparator(.05).decide_multi(None,cands,roll,leaf,[1,2],0)
  assert d.chosen_index==1 and d.completed_rounds==1 and d.deepest_completed_h==1
  rows[f'anytime_h1_survives_h2_{fail}']=ds(d)
 def fake_harness(prep=.0,begin=.0):
  h=RealEnvSearch.__new__(RealEnvSearch);h.cfg={'BUDGET':.7};h.notes=[]
  h.collector=StatsCollector();h.terminal_roots_rejected=0;h._cand_cost_sum=0;h._cand_cost_n=0
  h.leaf_adapter=HeuristicLeafAdapter(lambda a:.1 if a=='a0' else .9)
  phase_calls=[]
  h._fo_snap=None
  class Feat:
   def __init__(self,seat):self.seat=seat
  def copy_feat(fo):clock.tick(begin);phase_calls.append('begin_snapshot');return fo
  h.inx=SimpleNamespace(terminal_fn=lambda sim:False,st={'fo':Feat(1)},F=SimpleNamespace(Feat=Feat),mod={'feat_copy':copy_feat})
  root=SimpleNamespace(full=None,step=10)
  def build(obs,a0):clock.tick(prep/2);phase_calls.append('build_root');return root
  def gen(root,a0):clock.tick(prep/2);phase_calls.append('candgen');return ['a0','a1'],None
  def guard(root,labels):phase_calls.append('guard');return set()
  def rollout(root):
   def fn(s,a,ho,se):clock.tick(.001);phase_calls.append('rollout');return a
   return fn
  h._build_root=build;h._gen_candidates_raw=gen;h._guard_screen=guard
  h._probe_sim=lambda:SimpleNamespace(load_observation=lambda s:None)
  h._make_rollout=rollout
  return h,phase_calls
 for name,base,prep,begin in [('old_prep_repro_now_closed',.2,.9,0),('old_refill_repro_now_closed',.8,0,0),('snapshot_still_excluded',.2,0,.6),('already_exhausted_still_does_prep',.8,.9,0)]:
  clock.t=0;h,calls=fake_harness(prep,begin)
  h.begin_step({'player':0});clock.tick(base)
  d=h.decide_at_root({'step':10},'a0',base)
  rows[name]={'decision':ds(d),'public_elapsed':clock.t,'phase_calls':calls,'telemetry':h.collector.snapshot()}
 assert rows['old_prep_repro_now_closed']['decision']['abort_reason']=='deadline'
 assert rows['old_refill_repro_now_closed']['decision']['abort_reason']=='deadline'
 # Whole-round cost uses prior H1 average; model same cheap state as above,
 # now H3 per-candidate cost is .04, while stale H1 estimate remains .001.
 clock.t=0
 def expensive(s,a,h,se):clock.tick(.04);return a
 d=Comparator(.05).decide(None,cands,expensive,lambda a:.1 if a=='a0' else .9,3,0,est_candidate_cost_s=.001)
 rows['unstratified_estimate_admits_expensive_h3']=ds(d)
 # A no-candidate root consumes setup work but returns without a telemetry row.
 clock.t=0;h,calls=fake_harness(prep=.1);h._gen_candidates_raw=lambda root,a0:None
 d=h.decide_at_root({'step':10},'a0',.2)
 rows['no_candidate_no_total_accounting']={'decision':ds(d),'public_elapsed':clock.t+.2,'telemetry':h.collector.snapshot()}
finally:comparator.time.monotonic=orig
p=Path('/workspace/search-r2-review-20261116/comparator/results.json');p.write_text(json.dumps(rows,indent=2,allow_nan=False)+'\n');print(p.read_text())
