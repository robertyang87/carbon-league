# R2 comparator / telemetry / leaf review

Frozen source `b15b475dcc900c84241304a1a5caed2fd428e693`. Independent probe `probe_r2.py`, evidence `results.json`. Pure control-flow/injected-clock tests, not machine throughput or observed platform timeouts. No source modifications.

## Original issues rechecked

- **SI06 original numeric/exception reproductions closed.** NaN/+Inf/-Inf across direct leaf, HeuristicLeafAdapter, VNetLeafAdapter: all nine combinations return A0, completed_rounds=0, abort_reason=nonfinite_leaf. Vnet checks pre-tanh, so Inf no longer maps to a legal endpoint. Rollout and leaf exceptions both return A0 with reason=exception. Raw-margin finite values remain allowed; the fix does not confuse finite raw scale with [0,1]. Lines: comparator.py237–273; leaf_adapters.py54–67,100–113.
- **Anytime earlier open deliverable now implemented in kernel.** Independent H1-wins / H2-fails probes for timeout, runtime exception, nonfinite all retain H1's alternative, rounds=1, deepest=1 and appropriate abort reason. Do not repeat the earlier claim that code is single-horizon only. Lines comparator.py212–299.
- **SI02 two original counterexamples flip.** Baseline .2 + root/candidate .9 now returns A0/deadline, total_elapsed=1.1, no rollout. Baseline .8 with nominal .7 no longer gets .05 replenishment; it returns A0/deadline with total=.8. Accounting after decide_at_root entry is corrected. These improvements should be stated plainly.

## R2-C01 — SI02 residual: public-call snapshot still outside accounting; exhausted calls still execute preparation (P2, S2 blocker)

1. `real_env.py344–368 begin_step()` performs a feature snapshot before baseline. Actual smoke caller :114 takes that snapshot, then starts the baseline timer :115; battery2 :624–627 does the same. `decide_at_root :643–646` starts a new t_entry and receives only measured baseline cost. Its phase called "snapshot" :682–684 actually measures `_build_root`, not the earlier snapshot. There is no stored public t0/deadline covering begin_step.
2. `decide_at_root` checks remaining budget only :710–714, **after** `_build_root`, terminal-state probe, `_gen_candidates_raw`, and `_guard_screen` (:681–706). Even if supplied baseline cost already exceeds total, it runs expensive opponent/candidate neural work before returning A0. The end-of-kernel absolute deadline cannot undo that work.
3. Independent control-flow probes:
   - Snapshot=.6s, baseline=.2s, comparison=.002s: actual public elapsed=.802s vs registered=.7; commits alternative and reports total_elapsed=.202, snapshot phase0, abort_reason=None.
   - Baseline=.8s (> total .7), later preparation=.9s: root/candidate/guard functions all execute, finally returns A0 at1.7s. Correctly records1.7 now, but avoids no already-unaffordable work.
4. Fix: obtain the single absolute deadline at actual public entry/before begin_step and pass or retain it through baseline and search; check deadline before each potentially expensive preparation stage and use conservative stage/round admission. Cost report must include early snapshot and no-candidate roots.
5. Related reporting gap: `raw is None` at :701–702 returns before `_finish`; probe consumes .25s baseline+root cost but total_cost_accum_s remains0/calls0. Existing count names define comparator-trigger counts, so this is not a wrong trigger count; it is a limitation of calling the aggregate "whole-public-call cost". Track all calls separately from admitted comparison calls.

## R2-C02 — Claimed C_hi admission currently uses unstratified mean; multi-depth cost is not bounded (P2 before S2, already-open cost-table dependency)

- `real_env.py371–375` explicitly returns historical **mean** seconds/candidate; no samples=>0=>admission disabled. :737–740 updates one scalar across all roots/horizons. `comparator.py223–225` multiplies that scalar by eligible candidate count unchanged for every requested horizon.
- This is not the registered high-cost bound conditional on (K,J,H,units,backend,cold/hot). Cheap H1 roots can authorize expensive H3 roots and a cold first call has no admission at all. Valid anytime fallback action remains correct, but fallback does not make execution fit its budget.
- Logical example with stale H1 estimate .001/candidate and H3 cost .04/candidate: K2, .05 remaining is admitted as .002; executes .08 before single_call_overrun. This is not a measured H3 cost.
- Cost table and actual platform S2 remain open in status; do not claim this proves a platform failure or necessarily needs a separate issue number. It is a concrete reason the new admission code must not be called C_hi-complete or resource-certified. Require per-shape/horizon conservative entries, unseen-shape rejection/calibrated fallback and fixed return reserve before S2.

## Deliberate non-findings / scope

- Generic Comparator float(value) conversion is outside callback try and candidate-index/horizon validation remains incomplete, but real deployed adapters already produce float and generated indices are unique. Not elevated as a live source defect without a reachable malformed input.
- Original missing-callback exception handling is closed. Preparation-stage exceptions still propagate, but that is a distinct boundary and not evidence to reopen the old numeric counterexample.
- No full-model games or resource-limited certification run by this line; other parallel lines own shipped fix-suite/integration results.
