# Search acceptance review (frozen eeb1b4b93374a0aba2c61b8d2bf8e867f2c3b58c)

Read-only source review. Python /workspace/carbon-review-venv/bin/python, NumPy BLAS one thread. No platform certification or large matches were run. Evidence is under this directory; no repository source changed.

## A01 / P2: “正式 S1 电池” returns PASS after required positive controls fail

- Location: `code/search_proto/s1_battery.py:507–516` (especially line 514 `ok = len(completed) > 0`), B result fields at 239–249, B exception handlers at 408/426/445.
- The exit verdict does not consume `expect_met`, `chosen_is_settlement_best`, `leaf_vs_settlement_max_abs_err`, B errors/exceptions, minimum natural games, minimum roots, or a valid positive control. One completed natural root suffices. The permissive rule is accurately documented at file line 30, but is incompatible with naming this a **formal S1 battery**, whose prereg requires known-improved terminal action actually selected and boundary controls.
- Existing committed JSON already has P1/P2/P3 `expect_met=false`, N1 true; its natural 48 completed roots force the executable verdict PASS. Status document honestly calls positive controls pending and S1 not closed: **do not accuse Muse of already closing formal S1**. The problem is the executable gate cannot enforce that honest outstanding requirement.
- Executed `probe_acceptance.py`: only reduced natural volume to ROOTS_TARGET=1, MIN_GAMES=1, MAX_GAMES=1; reused exact source, pinned sources/package, and all three shipped B cases unmodified. Exit code **0**, B P2 false, P1 false, N1 true. `probe_result.json` and `battery_reduced.json/log` contain result. This is a real Echo4/real FastCarbon run, not a fabricated B result.
- Remedy: split explicit diagnostic and formal status, formal return PASS only if all prereg required tests pass; missing/failed controls, wrong selected action, nonzero terminal oracle discrepancy, invalid fixture count/identity must reject. Bind artifacts to exact code/config/package and include aggregate assertions. Diagnostic natural changed count cannot substitute for a true positive control.

## A02 / P2: late changed-root verification is unreachable by construction

- Location: `s1_battery.py:58–62`, `:325`, `:362–372`.
- MAX_STEPS_PER_GAME=200 limits collected pre-transition roots to step≤199. VERIFY_MIN_STEP=220 requires step≥220. The set intersection is empty even if the earlier per-game root quota is never hit. Thus `saved_verify` cannot ever be populated with current defaults. The status explains the empty verification as this particular batch ending before step56, but simply “trying again” cannot produce a late root with this implementation.
- Evidence: `probe_result.json` records explicit upper bound199 versus required220 and empty verification. Pure loop invariant establishes impossibility without expensive games.
- Remedy: choose/freeze late roots independently or continue baseline generation past the early collection quota with a dedicated late-root quota; distinguish no eligible root from verifier success.

## A03 / P2, latent until A02 is fixed: interrupted and history-reset continuation is mislabeled as terminal production-policy verification

- Location: `s1_battery.py:254–286`.
- Both arms allocate fresh agents at the saved late state (`:264–265`), and only simulator state is saved (`:367–371`), so Feat belief/history, guard lost-worker history, and opponent-model state are discarded. This evaluates cold-start continuations, not the persistent production policy represented by the collected root. Root fairness alone does not restore the target-policy semantics.
- The while loop can exit on wall time (`:273`) while state is nonterminal, yet writes `final_cash`/`final_diff_seat` and computes `chosen_minus_a0_final_diff` (`:277–286`) without checking terminal/completion. Independent injected-clock test (`probe_truncated_verification.py`) admits each arm then exhausts the continuation time; from step250 both stop at **251**, yet output `chosen_minus_a0_final_diff=44.0`. This 44 is an intermediate cash difference, not terminal utility evidence. `truncated_verification.json` contains exact result.
- It also runs to step300 without the authoritative terminal guard; main env reviewer owns the substantive step299 terminal bug. The B examples use the same FastCarbon model as the evaluated leaf rather than an independent authoritative env oracle, so matching cash values does not certify terminal parity.
- Currently no posted gain is contaminated: committed verification is empty because A02 prevents execution. Fix verifier before enabling it, preserve policy-memory snapshots per arm and full U/terminal contract; budget exhaustion → invalid/no gain, not “final”.

## Other validation limits / lower-priority test weaknesses

- Shipped `tests_s1.py` rerun: **7/7 pass** (`shipped_tests.log`). These are all horizon=1, scalar deterministic stub tests. They do not validate H2/H3 last-complete-round fallback, real guard history, hidden-carbon noninterference, fresh-seat1 root remapping, official terminal parity, or public-entry timing.
- T7 (`tests_s1.py:174–193`) cannot distinguish a one-call budget-banking regression: the comment itself notes 0.30-second rollout exceeds even 0.10+0.10 banked budget. A faulty comparator that banks the first call's remainder still aborts and passes. Use an injected deterministic clock with work between the two limits.
- `s1_battery_roots.json` has no top-level run_id, commit/source hashes, package hash, full config or fixture identity hash. A supplementary P3 case is explicitly marked `addendum=true` and the summary notes it was appended later. This is honestly disclosed, but the artifact is not one self-identifying reproducible formal run; the P3 generating code is absent from the battery. Publish canonical cases and per-run manifest before treating it as stage certification.
- All B cases are seat0, and all are crafted step299→300. Natural double-seat roots do not replace a seat1 terminal positive/negative control.
- Collector “completed_comparisons” values are 48 total while raw candidate leaves are192; this semantic naming is disclosed in status and comparator review owns whether it is merely confusing. Do not inflate it to an additional unreported failure.

## Latest-main delta read-only audit: 21098bad (s1_addendum)

Read via `git show`; working HEAD stayed eeb1b4b9. Copies saved as `s1_addendum_21098bad.py` and `s1_addendum_results_21098bad.json`.

- Added collision/escape battery ran **48 attempts**, `success=null`; the asserted positive remains unmet. All cases are seat0, step150. Some natural/constructed actions changed, but the independently defined escape predicate was never achieved. Do not describe changed alone as a successful positive control.
- Added late scanner removes the old hard 200-step cap, so **A02 is limited to the old battery and is not an architectural impossibility in addendum**. Actual added run stopped at197, 86 roots/40 changed, 0 roots≥220. Both saved roots are step150.
- The only verification has A0 reaching300 (`complete=true`) and chosen reaching255 (`complete=false`). It correctly sets `chosen_minus_a0_final_diff=null`. **Credit: addendum:273–295 fixes the interrupted-return masking bug in the new path**. Do not apply old A03's partial-cash-as-final-gain claim to this new function. The old function remains unfixed.
- New path still starts fresh agents at the root (264–265), preserves no Feat/guard/opponent history, and defines successful completion as step300 instead of authoritative terminal. Those issues are now in an actually exercised supplementary path, although no valid gain has yet been reported.
- `s1_addendum.py` explicitly documents exit0 as script completion only, and does not print formal PASS. It is not itself falsely certifying S1. `SWITCH_PLAN_20261116.md` still says S1 two legs unaccepted and any replacement of a constructed positive by natural continuation requires an explicit amendment. Therefore both latest data and status agree **S1 remains open**.
- Addendum output again lacks run_id/source/package/config/fixture hashes. It serializes outcomes/actions but no saved root full snapshot or policy histories, so another machine cannot reconstruct the exact late continuation from this JSON alone. Use source/policy identity manifest and reproducible state+memory fixture before formal acceptance.
- Root comparator reviewer independently owns additional addendum terminal probes.
