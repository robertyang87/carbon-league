import contextlib, hashlib, io, json, pathlib, sys
ROOT=pathlib.Path('/workspace/carbon-league')
OUT=pathlib.Path('/workspace/search-code-review-20261116/acceptance')
sys.path.insert(0,str(ROOT/'code/search_proto'))
sys.argv=[sys.argv[0]]
import s1_battery as b
vendor=OUT/'vendor'; vendor.mkdir(exist_ok=True)
for name,want in b.real_env.EXPECTED_VENDOR_MD5.items():
    raw=(ROOT/'code'/f'{name}.py').read_bytes()
    assert hashlib.md5(raw).hexdigest()==want,(name,hashlib.md5(raw).hexdigest())
    if name=='cnet2_search': raw=b'# review-local pinned copy\n# source main eeb1b4b9\n# no source changes\n'+raw
    (vendor/f'{name}.py').write_bytes(raw)
b.real_env._VENDOR=str(vendor)
b.fetch_pack=lambda: str(ROOT/'code/packs/echo4_int8.py')
b.ROOTS_TARGET=1; b.MIN_GAMES=1; b.MAX_GAMES=1
b.OUT_JSON=str(OUT/'battery_reduced.json')
with open(OUT/'battery_reduced.log','w') as log,contextlib.redirect_stdout(log):
    code=b.main()
x=json.loads(pathlib.Path(b.OUT_JSON).read_text())
summary={'test':'shipped main with reduced natural quota (1 root/1 game), actual B cases untouched',
 'return_code':code,'completed_roots':x['summary']['completed_roots'],
 'B_cases':[{'case':v['case'],'expect_met':v.get('expect_met'),'error':v.get('error'),'exception':v.get('exception')} for v in x['part_b']],
 'late_root_upper_bound':b.MAX_STEPS_PER_GAME-1,'verify_min_step':b.VERIFY_MIN_STEP,
 'verification_count':len(x['verification'])}
(OUT/'probe_result.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
