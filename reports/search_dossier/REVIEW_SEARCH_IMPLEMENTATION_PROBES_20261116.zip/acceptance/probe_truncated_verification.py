import json,pathlib,sys
ROOT=pathlib.Path('/workspace/carbon-league'); OUT=pathlib.Path('/workspace/search-code-review-20261116/acceptance')
sys.path.insert(0,str(ROOT/'code/search_proto'));sys.argv=[sys.argv[0]]
import s1_battery as b
pack=str(ROOT/'code/packs/echo4_int8.py')
_p,a=b.real_env.load_pack(pack)
h=b.real_env.RealEnvSearch(a)
F=h.inx.FastCarbon
sim=F();sim.reset(seed=986300)
snap=sim.get_state();snap['step']=250
snap['cash']=[100,100];snap['trees']={};snap['trees_dict']={}
snap['carbon']=[0.0]*225
# Keep actual actors nonextinct so advancing one step stays a nonterminal root.
snap['workers']={'player-0-worker-0':{'player':0,'pos':49,'carbon':44.,'type':'COLLECTOR'},'player-1-worker-0':{'player':1,'pos':70,'carbon':0.,'type':'COLLECTOR'}}
snap['wid_counter']=[1,1]
# Admit each arm, then interrupt the continuation at its while guard.
clock=iter([435.,465.,435.,465.]);b.wall=lambda:next(clock)
saved={'game':0,'seat':0,'step':250,'FastCarbon':F,'snap':snap,'a0':{},'chosen':{'player-0-worker-0':'DOWN'},'other':{}}
x=b.verify_changed_root(pack,saved)
(OUT/'truncated_verification.json').write_text(json.dumps(x,indent=2))
print(json.dumps(x,indent=2))
