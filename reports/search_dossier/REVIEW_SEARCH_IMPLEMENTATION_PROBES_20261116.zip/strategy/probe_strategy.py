"""Read-only evidence for strategy contract inconsistencies at eeb1b4b9."""
import json
import pathlib
import sys
import tempfile

ROOT = pathlib.Path('/workspace/carbon-league')
sys.path.insert(0, str(ROOT / 'code'))
import torch
from rl2_checkpoint import commit_checkpoint


def matching_branches(point, lo, hi):
    result = []
    if point < 0.0760:
        result.append('PPOU2:395 rollback to checkpoint 30')
    elif point >= 0.0890 and lo > 0:
        result.append('PPOU2:396 continue checkpoint 35, harmless')
    else:
        result.append('PPOU2:397 middle branch')
    crossed = [line for line in [0.0760, 0.0890] if lo <= line <= hi]
    if crossed:
        result.append('PPOU2:398 continue checkpoint 35, indeterminate')
    return {'point': point, 'ci': [lo, hi], 'crossed_trigger_lines': crossed, 'matching_instructions': result}


out = {'baseline': 'eeb1b4b93374a0aba2c61b8d2bf8e867f2c3b58c'}
out['it35_branch_collisions'] = [matching_branches(.075, .062, .088), matching_branches(.090, .077, .103)]
with tempfile.TemporaryDirectory(prefix='review-checkpoint-rotation-') as tmp:
    path = pathlib.Path(tmp)
    actor = path / 'ckpt_last.npz'
    actor.write_bytes(b'review stub actor artifact: no model inference')
    rotation = []
    for it in [30, 31, 32, 33]:
        state = {'it': it, 'net': {'w': torch.tensor([float(it)])}, 'vnet': {'w': torch.tensor([float(it)])}, 'opt': {'state': {}}, 'vopt': {'state': {}}}
        commit_checkpoint(tmp, state, str(actor), 'formal')
        rotation.append({'after_iteration': it, 'full_states': {p.name: torch.load(p, weights_only=False)['it'] for p in sorted(path.glob('*.pt'))}})
    out['checkpoint_rotation_actual_code'] = rotation
    out['it30_full_state_survives_after_it33'] = any(torch.load(p, weights_only=False)['it'] == 30 for p in path.glob('*.pt'))
status = (ROOT / 'reports/search_dossier/SEARCH_LINE_STATUS_20261116.md').read_text()
out['literal_truncation_marker_at_end_of_committed_status'] = status.endswith('...[truncated 1107 chars]')
out['status_last_two_lines'] = status.splitlines()[-2:]
out['l092_untriggered_is_not_equivalence_example'] = {'hypothetical_l092_point': .020, 'hypothetical_l092_ci': [.010, .030], 'main_point': .0466, 'relative_point_difference': .020-.0466, 'registered_superior_trigger': .020>.0568, 'registered_harm_trigger': .030<0, 'registered_label': 'directionally approximately equal (line 371)', 'justified_label': 'neither trigger fired; equivalence is not established'}
print(json.dumps(out, ensure_ascii=False, indent=2, allow_nan=False))
