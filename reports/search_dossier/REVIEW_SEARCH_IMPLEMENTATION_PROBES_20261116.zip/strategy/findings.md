# Strategy/preregistration review, eeb1b4b9

Scope: read-only review of the changed search strategy documents, `EXAM_VOLUME_DEFAULT.md`, and newly appended PPO-U2 registrations, at `eeb1b4b93374a0aba2c61b8d2bf8e867f2c3b58c`. No live training machine was inspected; machine-side claims below are attributed to the committed reports. Supporting executable: `probe_strategy.py`; actual output: `evidence.json`.

## New actionable findings

### STR01 — P2: it=35 decision branches can prescribe both rollback and continued training

- Source: `reports/PPOU2_FILING_20261114.md:395–398`.
- The first rule says point estimate <0.0760 means rollback to ckpt_30 and discard rounds 31–35 for continuation. The new fourth rule says a CI crossing its comparison line means indeterminate, continue from ckpt_35, and do not declare rollback. No priority or mutually exclusive conditions are defined.
- Concrete admissible result: point 0.075, CI [0.062,0.088]. It satisfies the rollback rule and crosses 0.0760, satisfying the opposite continuation rule. Point 0.090, CI [0.077,0.103] simultaneously qualifies as “无害” and “未判” by crossing 0.0890.
- This is independent of MS02 optional-stopping repair: the new experiment is correctly fixed at 2,000 seeds per field, but its single-look decision function remains ambiguous.
- Fix before reading it35 outcome: write one ordered, mutually exclusive decision table (and define which threshold is checked in which branch), or remove the leftover CI-crossing exception if decisions are intentionally based on point estimates. Avoid choosing precedence after seeing the result.
- `evidence.json.it35_branch_collisions` is a literal translation of the written conditions, not a claim about actual it35 results.

### STR02 — P2, potentially blocking the specified recovery action: the ckpt_30 rollback has no durable full-state recovery artifact established by the repository evidence

- New instruction: `reports/PPOU2_FILING_20261114.md:395` requires `resume ckpt_30 state`, reference ckpt_30, and discarding 31–35 for continuation.
- Current writer: `code/rl2_ppo_train.py:931–945` saves checkpoint-specific **actor NPZ**; the full state (net/opt/vnet/vopt/etc.) is passed to `commit_checkpoint`. `code/rl2_checkpoint.py:106–110` keeps only `state_last.pt` and `state_previous.pt`, plus a completion marker for the latest state. It does not persist `state_30.pt`.
- Corroborating contemporaneous inventory: `reports/search_dossier/SEARCH_LINE_STATUS_20261116.md:33–40` calls its list “现存全部完整 state” in the main run and lists it0/32/33, not it30. The newly frozen it33 file at lines66 does not restore it30. The same two-slot behavior is already the stated reason it20 vnet was lost.
- Actual lightweight execution of `commit_checkpoint` with finite stub tensors at it30→31→32→33 leaves only it33 and it32. See `evidence.json.checkpoint_rotation_actual_code`.
- Consequence: actor-only `ckpt_30.npz` cannot perform the registered full PPO resume with the old critic/optimizer state. Substituting the latest state or doing a fresh initialization changes the registered recovery operation.
- Fix: before relying on the rollback branch, locate and hash a real complete it30 state plus the required training/league recovery metadata; if none exists, amend the fallback explicitly. For future decision checkpoints, atomically freeze full states before rotation and record identity in the same decision manifest.
- Limit: I did **not** inspect L20/DGX or prove the absence of an unlisted backup. Phrase this as a missing established recovery prerequisite / mismatch between committed inventory and instruction, not an assertion that no backup can exist anywhere.

### STR03 — P3: the committed status report is actually truncated

- `reports/search_dossier/SEARCH_LINE_STATUS_20261116.md:118–119` ends mid-sentence after `根名单冻结法、无`, then the literal text `...[truncated 1107 chars]`.
- Confirmed directly from file bytes; this is not the terminal/tool output truncating the document.
- This loses part of the declared S3 protocol/next-actions handoff. Restore from the source document and verify complete byte count and end marker before re-publishing. `evidence.json.literal_truncation_marker_at_end_of_committed_status` is true.

### STR04 — P3 wording: “neither trigger fired” is not “λ0.92 ≈ λ0.95”

- `reports/PPOU2_FILING_20261114.md:368–371` correctly warns one run per arm is not a λ-effect estimate, but labels all results between its two triggers as directionally approximately equal.
- The triggers are l092 point>0.0568 and l092 CI upper<0. An l092 result +0.020 [0.010,0.030] fires neither trigger even though its point is 0.0266 below the main +0.0466. The rule never tests equivalence and its negative branch tests absolute harm relative to the original model, not relative harm against λ0.95.
- Keep the operational no-action rule if desired, but name this region “未触发优效或绝对有害条件；相对差异未确认”. This is not a claim that the illustrative result has occurred, nor a demand for a large new experiment now.

## Previous MS01–MS08 disposition: do not report them wholesale as unfixed

| ID | Assessment at frozen HEAD | Exact basis / remaining boundary |
|---|---|---|
| MS01 | Substantive document repair accepted | PREREG:18–19 makes S3 variance diagnostic only; S4 uses a matched whole-game pilot or identified conservative bound. FEASIBILITY:191,222–223,233 agrees. Actual pilot and N-lock work remain future prerequisites, not a present regression. |
| MS02 | Substantive document repair accepted | PREREG:19 explicitly fixed N, single look, no default extension. EXAM_VOLUME_DEFAULT:27–31 requires whole-procedure error control for any future two-look procedure; unqualified runs must use fixed N. PPO filing:402 independently locks it35 fixed 2,000 per field. STR01 is a new decision-function ambiguity, not a continuation of the old optional-stopping bug. |
| MS03 | Main statistical correction accepted; one conflicting coverage sentence remains | PREREG:18 has predeclared population, probabilities, game aggregation, H0 actual A0=0, invalid!=0, and mandatory S3 estimator/invalid cap supplement. FEASIBILITY:232–233 agrees. But PREREG:24 is unchanged: `H=0 只报分布、不判读；H≥1 的完整比较为判读域`. Update it to match the narrow depth-descriptive interpretation in FEASIBILITY:232. Do not call the entire weighting/denominator fix absent. |
| MS04 | Accepted at registration/document level | PREREG:7–9 closes unavailable it20 leaf and registers it33 as a new identified leaf with behavior/calibration/cost/size gates. It no longer calls later critic a same-source recovery. FEASIBILITY risk R1:240 and decision tree:211 agree. Do not certify the actual it33 artifact or its four gates based only on these statements. |
| MS05 | Accepted for the future B arm | FEASIBILITY:89–91,204 distinguishes same-horizon Sequential Halving from new multi-fidelity screening, protects A0 and same-depth final comparison, and demands B's own mechanism/timing checks. The generic line88 still has the broad “~2 simulations” summary, immediately qualified by line89; no mainline blocker. |
| MS06 | Accepted | FEASIBILITY:97 defines legal own history, public cargo vs hidden map carbon, separates J opponent axis from L hidden particles, and distinguishes ordinary E[U] from CFR counterfactual values. Line105 scopes antipeeking to the same pre-transition root and disclaims convergence guarantees. |
| MS07 | Accepted on the substantive historical separation | FEASIBILITY:31–48 and STATUS:109–111 distinguish the old graft negative results, persistent sweep depth2/no leaf, the 42-root probe, and the untested new design. Do not resurrect the old merged-ledger finding. |
| MS08 | Accepted | FEASIBILITY:116,128 explicitly quotes full-search-only training targets and treats mixed low-budget policy labels as this project's separate hypothesis. Phase5 is still a future separately registered activity. |

## Implementation/document cross-checks for integration with the other review lines

1. **Scope overclaim is already documented internally**: PREREG:23 grants adjudication coverage to collision/escape, home delivery, and end-of-time liquidation; WIRING_MAP:130,142 explicitly warns the latter two require default-off `KEY_LATE_HOME`/related variants. `real_env.py:361` calls the unchanged `key_units` under frozen Echo4 config. Have the environment reviewer validate a home-delivery root with no nearby enemy; do not silently count unsupported strata as tested.
2. **Heuristic scale**: STATUS:76 deliberately declares raw-margin argmax; FEASIBILITY:162–165/WIRING_MAP:54 retain unified U requirements. For deterministic J=1, pure argmax within a single scoring function is invariant to a strictly increasing transform, so raw margin alone is not a demonstrated action-selection bug. Resolve the contract/telemetry naming, and prohibit mixing raw margin with U or averaging them as if equal. Exact terminal parity and mixed-terminal behavior still need code-level verification.
3. **Stage state**: STATUS:104/115 openly says exact terminal positive controls have not passed. The report does not claim full S1 closure; keep that distinction. “48 completed roots / 16 changes” proves activity, not known-better action discovery. S0a evidence path remains remote and explicitly not yet archived (STATUS:47); I have not independently re-certified platform timing from it.
4. **Documentation precedence**: PREREG:9 authorizes S0b/S1 implementation in parallel with remaining S0a checks, while the old heading:12 and S0a:14 still broadly prohibit progression. Treat the later explicit authorization as permitting implementation; do not frame the authorized work as an unauthorized launch. Clean the stage wording before formal acceptance.
5. **New leaf plan remains pending**: it33's source identity is explicitly distinct from deployment actor it20; STATUS:117 correctly says behavior matching must be defined against actual actor20 continuation. Four tests are an open prerequisite, not grounds to mark an already completed evaluation invalid.

## Validation limits

No new matches, training, deployments, code mutations, or outside messages. Read-only source review plus literal rule examples and actual local checkpoint publication/rotation using temporary finite stub tensors. The recorded policy examples are synthetic counterexamples, not measured model performance. All repository file lines refer to the frozen SHA, not later moving main.

## Bounded latest delta checked: eeb1b4b9 → 21098bad

Read with `git diff`/`git show`; no checkout changes. The added `SWITCH_PLAN_20261116.md` and three-line preregistration amendment do not change STR01/STR02 or repair the residual MS03 coverage-table sentence (now line25 because a production-node line was inserted). The preceding MS disposition therefore stands.

Positive updates in this delta:

- S2 seeds are now explicitly separated (986500–986519), S3 retains 986200–986499, and S4 is newly allocated from 986600 after N lock. This fixes the previously shared S2/S3 pool ambiguity at the registration layer.
- SWITCH_PLAN §3.1 explicitly says substituting natural changed roots plus late continuation for the required exact positive control needs a separate amendment and cannot become effective automatically. Do not report that proposed substitute as an already authorized bypass.
- SWITCH_PLAN §4 has struck the proposed 1,000-plus-extension S4 rule and restores fixed N from matched pilot. It does not reopen MS01/MS02.
- The production node requires S4 PASS, S2 timing, size, leaf identity, separate production acceptance, and retains the owner's submission gate. Planning production integration in parallel with S1 does not itself claim deployment or authorize skipping acceptance.

One release control to preserve (not a newly proven bug): the **exact search source, CONF, leaf payload and quantization** that pass S4 must identify the final candidate. SWITCH_PLAN §2's “段5只换叶载荷与CONF定版” must not mean changing an already evaluated policy after S4. If it only rebuilds the already frozen S3/S4 version, demonstrate byte/behavior identity; any new leaf/CONF is a new subject needing applicable mechanism, timing and gain evidence. The document elsewhere says “S3/S4定版的叶” and separately registers later vnet changes, so a conservative reading already permits the correct implementation.
