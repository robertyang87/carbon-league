import importlib.util, json, pathlib, subprocess, sys, tempfile, types, base64, hashlib, math
ROOT=pathlib.Path('/workspace/carbon-league')
PROTO=ROOT/'code/search_proto'
sys.path.insert(0,str(PROTO))
result={'source_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()}
raw=(ROOT/'code/cnet2_search.py').read_bytes()
result['pinned_search_md5']=hashlib.md5(raw).hexdigest()
# Stub only transport, not bridge logic; no network/authentication involved.
calls=[]
transport=types.ModuleType('gh_api')
def get_file(owner,repo,path,ref):
 calls.append({'owner':owner,'repo':repo,'path':path,'ref':ref})
 return {'content':base64.b64encode(raw).decode()}
transport.get_file=get_file
sys.modules['gh_api']=transport
import pack_bridge
with tempfile.TemporaryDirectory() as td:
 vendor=pathlib.Path(td)/'vendor'
 pack_bridge.VENDOR_PATH=str(vendor/'cnet2_search.py')
 pack_bridge.fetch_vendor()
 result['fetch_vendor_transport_requests']=calls
 result['fetch_vendor_created_files']=sorted(p.name for p in vendor.iterdir())
 result['missing_required_vendor_files']=[name+'.py' for name in ['cnet2_feat','cnet2_np','fastsim'] if not (vendor/(name+'.py')).exists()]
 try:pack_bridge.load_pack_sources()
 except Exception as e:result['load_after_documented_fetch']={'error_type':type(e).__name__,'error':str(e)}
 # Existing vendor path is trusted by loader without checksum; minimal synthetic file.
 (vendor/'cnet2_search.py').write_text('STALE_SENTINEL = True\n')
 loaded=pack_bridge.load_pack_sources()
 result['cached_vendor_reverified']=not getattr(loaded,'STALE_SENTINEL',False)
from leaf_adapters import VNetLeafAdapter
result['vnet_default_disabled']=False
try:VNetLeafAdapter(33,'frozen').__call__(None)
except NotImplementedError:result['vnet_default_disabled']=True
result['vnet_injected_nonfinite_outputs']={str(v):str(VNetLeafAdapter(33,'frozen',lambda _,v=v:v)(None)) for v in [float('inf'),float('-inf'),float('nan')]}
print(json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False))
