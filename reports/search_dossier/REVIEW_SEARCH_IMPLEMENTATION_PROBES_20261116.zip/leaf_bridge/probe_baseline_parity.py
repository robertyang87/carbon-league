import hashlib, importlib.util, json, pathlib, sys, time
import numpy as np
ROOT=pathlib.Path('/workspace/carbon-league')
sys.path.insert(0,str(ROOT/'code/search_proto'))
import real_env
path=ROOT/'code/packs/echo4_int8.py'
public=[]; direct=[]
for seat in range(2):
 pack,agent=real_env.load_pack(str(path)); public.append(pack); direct.append(agent)
sim=real_env.extract_internals(direct[0]).FastCarbon()
rows=[]
t0=time.perf_counter()
for seed in [986490,986491]:
 sim.reset(seed=seed)
 for step in range(12):
  acts=[]
  for seat in [0,1]:
   obs=sim.obs(seat)
   ad=direct[seat](obs,{})
   ap=public[seat].agent(obs,{})
   rows.append({'seed':seed,'step':step,'seat':seat,'equal':ad==ap,'action':ad})
   acts.append(ad)
  sim.step(*acts)
result={'pack_md5':hashlib.md5(path.read_bytes()).hexdigest(),'embedded_hashes':{k:hashlib.md5(v.encode()).hexdigest() for k,v in public[0]._SRC.items()},'observations':len(rows),'mismatches':[r for r in rows if not r['equal']],'rows':rows,'elapsed_s':time.perf_counter()-t0}
print(json.dumps(result,indent=2,ensure_ascii=False))
