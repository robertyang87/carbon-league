# Leaf / bridge review

Frozen source: `eeb1b4b93374a0aba2c61b8d2bf8e867f2c3b58c`. No source changes or deployment.

## LB01 — P2: the documented pinned-vendor bootstrap does not reproduce from the repository

Locations: `code/search_proto/pack_bridge.py:22–23,40–56,59–80`; `code/search_proto/README.md:10,18`; `reports/search_dossier/SEARCH_LINE_STATUS_20261116.md:90,97`.

README/status say pack_bridge fetches and validates all four sources and smoke can run after that setup. Actual `fetch_vendor()` makes precisely one request for `code/cnet2_search.py`, writes one file, and has no path to provision `cnet2_feat.py`, `cnet2_np.py`, or `fastsim.py`. `real_env.verify_vendor()` requires all four files. Fresh checkout also imports `gh_api` from a machine-local `~/workspace` location; the tracked helper resides under `tools/` and itself depends on a Muse-specific credential runtime. Thus the recorded S1 run may be real on Muse's populated machine, but the claimed repository bootstrap is incomplete and independent reviewers cannot follow the documented commands.

Independent evidence (`probe_leaf_bridge.py/json`): mock only the remote transport to return exact pinned search bytes; the actual bridge code created exactly `['cnet2_search.py']`, three dependencies remained missing, and `load_pack_sources()` then raised `RuntimeError` naming missing `cnet2_feat`. `bridge_cli.log` independently shows clean checkout invocation fails `ModuleNotFoundError: No module named 'gh_api'` before even provisioning the cache. No network was used by the probe.

Related gap in the same bridge contract: once a vendor file exists, `load_pack_sources()` executes it without checking the pinned hash. Replacing that temporary cached file with a synthetic one-line `STALE_SENTINEL=True` module is accepted. This is a fail-closed reproducibility/identity defect in that helper, not evidence the current real-env run used wrong source: the real-env entry independently verifies four vendor hashes and the entire Echo4 package.

Suggested repair: a checkout-local/offline-capable bootstrap at a frozen commit, populate and fully hash all four sources, reverify cached bytes on load, document the exact setup command/dependencies. Prefer using tracked pinned source rather than requiring runtime GitHub network credentials for local testing. Do not infer previous acceptance evidence is fabricated; label it environment-dependent until independently reproducible.

## Deferred hardening, not a currently reachable deployed failure

`leaf_adapters.py:82–89`: VNetLeafAdapter is explicitly a scaffold with no backend wired. The default raises NotImplementedError, as required. Once a backend is injected, `+inf` maps silently to U=1, `-inf` to U=0, and NaN passes through while last_out_of_range remains False. Add raw-output finite checking before tanh, and validated artifact identity/acceptance metadata at actual backend integration. These are future readiness conditions, **not** grounds to claim the current actor pack or current heuristic run has corrupt weights. Probe records all three transformations.

## Verified positive facts and limits

- `real_env.load_pack()` loads the exact frozen Echo4 pack (`819250bfc82632786063dabd46a616bd`); all four embedded `_SRC` source hashes independently recompute to declared full hashes.
- Current _B2/_B3 and ensemble are empty, so its `make_search_agent(... rweights=None, oweights=None)` path matches this pinned public pack.
- `probe_baseline_parity.py/json` compares direct-loaded baseline to the package's real public `agent(obs,{})` in two newly seeded games, 12 steps each, both seats: **48 observations, 0 action mismatches**, including cross-game step=0 reset. This is a bounded parity check, not exhaustive policy equivalence or resource certification.
- Full PPO vnet is **not yet implemented**: only the backend-injection scaffold exists. Correct report wording is heuristic search prototype wired, L-vnet33 pending backend plus behavior/calibration/cost/size acceptance. Presence of actor value/utility tensors does not constitute critic integration.
- Heuristic leaf currently uses raw score margin by explicit prototype decision, and the comparator only argmaxes one deterministic scenario. No affine monotonicity bug was established for that current limited use. It is not a calibrated E[U] leaf or evidence of positive whole-game ΔU. If later combining terminal U and raw heuristic scores, or averaging stochastic scenarios, affine identity is no longer a sufficient scale contract.
- Main duplicate issues (root timing, step299, rollout guard, seat1 initial snapshot) were routed to their owning review agents and not counted here.
