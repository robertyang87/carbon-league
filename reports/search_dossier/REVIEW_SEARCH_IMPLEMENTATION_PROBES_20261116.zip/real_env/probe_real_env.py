import sys, json, copy
from pathlib import Path
import numpy as np
sys.path.insert(0,'/workspace/carbon-league/code/search_proto')
import real_env
PACK='/workspace/carbon-league/code/packs/echo4_int8.py'
pack, agent = real_env.load_pack(PACK)
h=real_env.RealEnvSearch(agent); FC=h.inx.FastCarbon

def state(step=100,cash=(100,100)):
    s=FC(); s.reset(seed=986201); q=s.get_state(); q['step']=step; q['cash']=list(cash); q['carbon']=[0.0]*225
    q['workers']={'player-0-worker-0':{'player':0,'pos':49,'carbon':44.0,'type':'COLLECTOR'}, 'player-1-worker-0':{'player':1,'pos':50,'carbon':8.0,'type':'COLLECTOR'}}
    q['wid_counter']=[1,1]; q['trees']={}; q['trees_dict']={}; q['tid_counter']=[0,0]; s.set_state(q); return s

out={}
# Fresh agent requested for seat 1 on real late root; compare reconstructed opponent against exact same-history fo.
s=state(); obs=s.obs(1); h.begin_step(); a0=agent(obs); root=h._build_root(obs,a0)
fresh=h.inx.F.Feat(0); oo=dict(obs,player=0); vis=np.zeros(225)
for w in obs['players'][0][2].values():
    cs=[w[0]] if w[2]=='COLLECTOR' else h.inx.F.DEST[w[0],1:]; vis[cs]=h.inx.st['f'].est[cs]
oo['carbon']=vis.tolist(); xo=fresh.observe(oo); yy,_,_=h.inx.pol.act(xo,fresh.aux,teacher=h.inx.st['ot']); correct=fresh.to_actions(yy)
out['fresh_seat1']={'snapshot_seat':h._fo_snap.seat,'expected_snapshot_seat':0,'root_opponent_actions':root.acts_o,'correct_opponent_actions':correct,'wrong_side_ids':[k for k in root.acts_o if k.startswith('player-1-')]}
# Already time-terminal roots must reject without a transition; real rollout advances.
for step in (298,299,300):
    p,a=real_env.load_pack(PACK); hh=real_env.RealEnvSearch(a); ss=state(step); oo=ss.obs(0); hh.begin_step(); aa=a(oo); rr=hh._build_root(oo,aa); r=hh._make_rollout(rr)
    results=[]
    for horizon in (1,2,3):
        v=r(rr.full,aa,horizon,0); results.append({'horizon':horizon,'final_step':v.sim.step_count,'left':v.left,'leaf':hh._raw_leaf(v),'cash':list(v.sim.cash)})
    out['time_root_'+str(step)]=results
print(json.dumps(out,indent=2))
Path('/workspace/search-code-review-20261116/real_env/results.json').write_text(json.dumps(out,indent=2)+'\n')
