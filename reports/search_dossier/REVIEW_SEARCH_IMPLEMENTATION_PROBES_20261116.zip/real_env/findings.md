# real_env 只读审查（eeb1b4b93374a0aba2c61b8d2bf8e867f2c3b58c）

## RE01 / P1：到时终止没有接入，H≥2 越过正式终局，已到时根仍被推进

- 位置：`code/search_proto/real_env.py:455–484`，具体 `465` / `467` / `480` 只调用 `inx.terminal_fn`；该函数由 `extract_internals:183` 提取原 `_search` 闭包，权威旧实现 `code/cnet2_search.py:660–661` 仅判两方灭绝，**不含时间终止**。
- 权威基准 `code/eval_v53.py:165` 明确 299 次推进：最后 agent 调用看 step298，终态为 step299。 `eval_v53:497–514` 另有灭绝结算。
- 原始 Echo4 包实际运行，构造仍有存活双方的 root298：H1停在299，现金 `[114,100]`、叶14；H2继续到300，现金 `[114,40]`、叶74；H3继续到301。对已到时 root299，H1/H2/H3分别推进到300/301/302；root300也被推进。
- 这不是计时效率问题：比较器高一轮可用正式比赛不存在的后续招募/交付改变比较值。当前 H1 的终局 battery 也构造在299→300，所以其 leaf 与 cash 自洽无法证明规则边界正确（测试代理另报）。
- 修复方向：根步≥episodeSteps−1直接拒绝/零推进；每次联合推进后同时检查灭绝和时间边界；终态冻结，H2/H3不再推；精确终局值按权威得分（灭绝 pre_cash、正常 final_cash）结算。
- 独立证据：`probe_real_env.py`、`results.json`、`probe.log`，真实 pack md5 `819250bfc82632786063dabd46a616bd`，无 source 变更。

## RE02 / P2：H≥2 续弈跳过生产守卫（代码路径确定，尚未实测收益伤害）

- 位置：`real_env.py:457–458` 仅复制 Feat；`469–477` 通过 `act_b` 得两席裸网标签直接推进，没有每席 BankruptcyGuard、没有 reset_step/apply、没有维护 lostw/prevw。
- 候选根的 `429–439` guard 复核只能覆盖第一步候选，不会覆盖后续模拟中单位死亡、现金变化、失去 collector 等新触发状态。
- 生产路径 `cnet2_search.py:565–615` BankruptcyGuard.apply 根据 lostw/prevw、现金、单位数改变移动和招募；注册要求生产续弈必须 guard-on。当前 H1 不消费续弈，这个问题只在 H≥2 暴露；不能拿 H1 电池替 H2/H3签字。
- 我做了真实原包的受控 root碰撞后续弈对照（`probe_guard.py`，`guard_results.json`），以及有限构造扫描，**这些样本裸网恰巧与守卫同动作，未观察到行为翻转**。因此报告只主张实现缺口，不声称已测得损失/负收益。
- 修复方向：每候选、每席独立守卫快照；沿真实分支逐步执行 same production guard 并维护历史，或正式把续弈策略改标无守卫并重新定义叶校准/验证对象。用可控 guard 必触发反例验证 H2/H3 不跨臂/跨席串扰。

## 已协调其他线（不重复编号）

- fresh seat1 首根 `begin_step:300–304` 默认建立 `Feat(1)`，但对手应 seat0；实际 probe 返回全 `player-1-*` opponent action，正确参考为 `player-0-*`。由 integration 线认领，复用 `results.json`。
- `_build_root/_generate_candidates` 不计入比较器预算且超预算强给0.05秒，由 comparator/integration 线归并。

## 核实通过/范围

- Prefix 使用 vendor `decode_b` 实际逐槽更新 reserved/undecided/cash/slots，没有复用旧动作的 uf/mf/legal 的 X01 式缺陷。
- 根 `acts_o` 在候选构造前一次确定，候选间共享；未见候选窥视输入。
- root full_carbon 来自 `f.est` 而不是 obs full_carbon；未见真实隐藏图直接泄漏。
- Feat 分支通过 feat_copy 拷贝 mutating arrays/history，模拟器串行复用时即时取叶值；未发现候选状态互污染的已证反例。
- 灭绝路径 root pre_cash 与后续终止 pc 存储在代码上符合既有规则；本轮无独立全权威灭绝矩阵实跑，不升格为全面认证。
