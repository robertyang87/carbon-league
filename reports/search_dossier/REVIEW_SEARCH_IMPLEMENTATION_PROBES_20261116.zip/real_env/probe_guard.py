import sys, json, dataclasses
from pathlib import Path
import numpy as np
sys.path.insert(0,'/workspace/carbon-league/code/search_proto')
import real_env
PACK='/workspace/carbon-league/code/packs/echo4_int8.py'
p,a=real_env.load_pack(PACK); h=real_env.RealEnvSearch(a); FC=h.inx.FastCarbon
s=FC(); s.reset(seed=986201); q=s.get_state();q.update(step=100,cash=[100,100],carbon=[0.0]*225,trees={},trees_dict={},tid_counter=[0,0],wid_counter=[1,1])
q['workers']={'player-0-worker-0':{'player':0,'pos':49,'carbon':44.0,'type':'COLLECTOR'}, 'player-1-worker-0':{'player':1,'pos':50,'carbon':8.0,'type':'COLLECTOR'}}
s.set_state(q); obs=s.obs(0);h.begin_step(); a0=a(obs);root=h._build_root(obs,a0)
# Freeze opponent NONE at the current root. Candidate walks into the opposing lower-cargo collector.
root=dataclasses.replace(root,acts_o={}); action={'player-0-worker-0':'RIGHT'}
records=[]; original=h.inx.mod['act_b']; root_guard=h.inx.guard.copy()
def capture(pol,xs,auxs,teachers,forced=None):
    labs=original(pol,xs,auxs,teachers,forced)
    # Independent production guard application to the raw continuation output.
    f=h.inx.mod['feat_copy'](root.f)
    # Recover successor from root branch pool (the active rollout state).
    f.observe(h.inx.pool[0].obs(0))
    raw=labs[0].copy(); _,lg,_=pol.act(xs[0],auxs[0],teacher=teachers[0]); g=root_guard.copy();g.reset_step()
    guarded=g.apply(xs[0],auxs[0],raw.copy(),lg,pol,f.own_uid,teachers[0])
    records.append({'step':h.inx.pool[0].step_count,'raw':f.to_actions(raw),'production_guarded':f.to_actions(guarded),'lostw_after':g.lostw,'raw_labels':raw.tolist(),'guarded_labels':guarded.tolist()})
    return labs
h.inx.mod['act_b']=capture
r=h._make_rollout(root); v=r(root.full,action,2,0)
actual={'step':v.sim.step_count,'workers':{u:{'player':w.player,'type':'COLLECTOR' if w.is_collector else 'PLANTER'} for u,w in v.sim.workers.items()},'cash':list(v.sim.cash),'leaf':h._raw_leaf(v)}
h.inx.mod['act_b']=original
# Branch reference uses exact observed same raw action except applies the actual production guard once.
s2=FC();s2.load_observation(root.full);s2.step(action,{})
fm=h.inx.mod['feat_copy'](root.f);fo=h.inx.mod['feat_copy'](root.fo)
xs=[fm.observe(s2.obs(0)),fo.observe(s2.obs(1))]; labs=original(h.inx.rpol,xs,[fm.aux,fo.aux],[root.t_now,root.ot]); _,lg,_=h.inx.pol.act(xs[0],fm.aux,teacher=root.t_now)
g=root_guard.copy();g.reset_step(); labs[0]=g.apply(xs[0],fm.aux,labs[0],lg,h.inx.pol,fm.own_uid,root.t_now)
s2.step(fm.to_actions(labs[0]),fo.to_actions(labs[1]))
reference={'step':s2.step_count,'workers':{u:{'player':w.player,'type':'COLLECTOR' if w.is_collector else 'PLANTER'} for u,w in s2.workers.items()},'cash':list(s2.cash),'leaf':float(h.inx.leaf_fn(s2,0,197,[100,100]))}
out={'root_guard_history':{'lostw':root_guard.lostw,'prevw':sorted(root_guard.prevw)},'continuation':records,'actual_raw_rollout':actual,'production_guard_reference':reference}
print(json.dumps(out,indent=2));Path('/workspace/search-code-review-20261116/real_env/guard_results.json').write_text(json.dumps(out,indent=2)+'\n')
