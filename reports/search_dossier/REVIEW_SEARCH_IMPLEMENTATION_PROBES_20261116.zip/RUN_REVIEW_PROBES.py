"""Portable read-only probe runner. Requires Python3.12, numpy, torch (strategy).
Example: python RUN_REVIEW_PROBES.py --repo /path/carbon-league comparator
No business source is modified. Outputs go into this extracted evidence directory.
"""
import argparse
import os
from pathlib import Path
import subprocess
import sys
import tempfile

PROBES = {
    'comparator': 'comparator/probe_comparator.py',
    'terminal': 'real_env/probe_real_env.py',
    'seat': 'integration/probe_fresh_seat1.py',
    'battery': 'acceptance/probe_acceptance.py',
    'truncated': 'acceptance/probe_truncated_verification.py',
    'addendum': 'comparator/probe_addendum_terminal.py',
    'bridge': 'leaf_bridge/probe_leaf_bridge.py',
    'parity': 'leaf_bridge/probe_baseline_parity.py',
    'strategy': 'strategy/probe_strategy.py',
}
p = argparse.ArgumentParser()
p.add_argument('--repo', required=True, type=Path)
p.add_argument('probe', choices=PROBES)
a = p.parse_args()
here = Path(__file__).resolve().parent
repo = a.repo.resolve()
code = (here / PROBES[a.probe]).read_text()
code = code.replace('/workspace/carbon-league', str(repo))
code = code.replace('/workspace/search-code-review-20261116', str(here))
env = dict(os.environ, OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1',
           MKL_NUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1')
with tempfile.TemporaryDirectory(prefix='carbon-review-probe-') as d:
    f = Path(d) / 'probe.py'
    f.write_text(code)
    r = subprocess.run([sys.executable, str(f)], env=env, cwd=repo)
    raise SystemExit(r.returncode)
