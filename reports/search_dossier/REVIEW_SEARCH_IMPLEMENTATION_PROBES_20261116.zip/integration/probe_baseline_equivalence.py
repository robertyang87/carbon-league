"""Echo4 public entry versus eager-loaded shadow harness, without deploying search."""
import sys,json
from pathlib import Path
sys.path.insert(0,'/workspace/carbon-league/code/search_proto')
import real_env
PACK='/workspace/carbon-league/code/packs/echo4_int8.py'
packs=[]; direct=[]; harnesses=[]
for seat in range(2):
    p,a=real_env.load_pack(PACK); packs.append(p); direct.append(a); harnesses.append(real_env.RealEnvSearch(a))
sim=harnesses[0].inx.FastCarbon(); sim.reset(seed=986203)
comparisons=0; roots=0; differences=[]; decisions=[]
for step in range(60):
    acts=[]
    for seat in range(2):
        obs=sim.obs(seat); h=harnesses[seat]; h.begin_step()
        baseline_public=packs[seat].agent(obs,None)
        eager=direct[seat](obs)
        comparisons+=1
        if baseline_public!=eager:
            differences.append({'step':step,'seat':seat,'public':baseline_public,'eager':eager})
        dec=h.decide_at_root(obs,eager,baseline_step_cost_s=0.0,horizon=1)
        if dec is not None:
            roots+=1
            decisions.append({'step':step,'seat':seat,'changed':dec.changed})
        acts.append(baseline_public)
    sim.step(*acts)
    if harnesses[0].inx.terminal_fn(sim): break
out={'source_sha':'eeb1b4b93374a0aba2c61b8d2bf8e867f2c3b58c','scope':'Deterministic functional equivalence only; synthetic budget, not timing or deployment certification.', 'public_vs_eager_action_comparisons':comparisons,'differences':differences,'shadow_roots':roots,'shadow_changed':sum(d['changed'] for d in decisions)}
print(json.dumps(out,indent=2));Path('/workspace/search-code-review-20261116/integration/baseline_equivalence_results.json').write_text(json.dumps(out,indent=2)+'\n')
assert not differences
