"""Read-only integration probe. Run with OPENBLAS_NUM_THREADS=1 and repository Python env."""
import json, sys
from pathlib import Path
import numpy as np
sys.path.insert(0, '/workspace/carbon-league/code/search_proto')
import real_env
PACK='/workspace/carbon-league/code/packs/echo4_int8.py'
pack, agent = real_env.load_pack(PACK)
h = real_env.RealEnvSearch(agent)
s = h.inx.FastCarbon(); s.reset(seed=986201)
q = s.get_state(); q['step'] = 100; q['cash'] = [100,100]; q['carbon'] = [0.0]*225
q['workers'] = {
 'player-0-worker-0': {'player':0,'pos':49,'carbon':44.0,'type':'COLLECTOR'},
 'player-1-worker-0': {'player':1,'pos':50,'carbon':8.0,'type':'COLLECTOR'},
}
q['wid_counter']=[1,1]; q['trees']={}; q['trees_dict']={}; q['tid_counter']=[0,0]; s.set_state(q)
obs = s.obs(1)
h.begin_step()
a0 = agent(obs)
root = h._build_root(obs,a0)
# Correct same root reconstruction from the opponent's seat, with exactly the
# same legal carbon belief projection as _build_root; no live state mutation.
fresh=h.inx.F.Feat(0)
oo=dict(obs,player=0); vis=np.zeros(225)
for w in obs['players'][0][2].values():
    cs=[w[0]] if w[2]=='COLLECTOR' else h.inx.F.DEST[w[0],1:]
    vis[cs]=h.inx.st['f'].est[cs]
oo['carbon']=vis.tolist()
xo=fresh.observe(oo)
y,_,_=h.inx.pol.act(xo,fresh.aux,teacher=h.inx.st['ot'])
correct = fresh.to_actions(y)
transitions={}
for name, opp in [('actual', root.acts_o), ('correct_seat',correct)]:
    sim=h.inx.FastCarbon(); sim.load_observation(root.full)
    sim.step(opp,a0)
    transitions[name] = {'cash': list(sim.cash),
      'opponent_workers':{k:{'pos':v.pos,'cargo':v.carbon} for k,v in sim.workers.items() if v.player==0}}
out={
 'source_sha':'eeb1b4b93374a0aba2c61b8d2bf8e867f2c3b58c',
 'root_step':100, 'actor_seat':1,
 'snapshot_seat':h._fo_snap.seat,'expected_snapshot_seat':0,
 'a0':a0,'root_opponent_actions':root.acts_o,'correct_opponent_actions':correct,
 'opponent_ids_legal':sorted(set(obs['players'][0][1])|set(obs['players'][0][2])),
 'all_predicted_opponent_ids_wrong':all(k.startswith('player-1-') for k in root.acts_o),
 'transitions':transitions,
}
assert out['snapshot_seat']==1 and out['all_predicted_opponent_ids_wrong']
assert transitions['actual'] != transitions['correct_seat']
print(json.dumps(out,ensure_ascii=False,indent=2))
Path('/workspace/search-code-review-20261116/integration/fresh_seat1_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
