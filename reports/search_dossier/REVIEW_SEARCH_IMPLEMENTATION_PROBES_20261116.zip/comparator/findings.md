# Comparator / telemetry independent review

Frozen source: `eeb1b4b93374a0aba2c61b8d2bf8e867f2c3b58c`. No source modifications. Python `/workspace/carbon-review-venv/bin/python`. All evidence lives beside this document; `probe_comparator.py` uses a deterministic monotonic clock to prove accounting/control behavior, **not to claim measured machine throughput or observed platform failure**. Shipped `tests_s1.py` passed 7/7 unchanged.

## C01 — Public-call deadline excludes root construction/candidate decoding and replenishes an exhausted budget (P1 before S2)

- `real_env.py:499–500` runs `_build_root` (opponent network reconstruction) and `_generate_candidates` (enc_for, up to MAX_BR Prefix alternatives, guard passes) before any elapsed accounting for the comparison. At `:505`, only caller-supplied baseline cost is deducted. `Comparator.decide :104` resets t0 after all of that work. At `real_env.py:506–510`, an already exhausted budget is replenished to 50 ms. `:524` reports only comparator elapsed.
- This contradicts prereg's public-entry-inclusive deadline and the helper's claim `real_env.py:494–497` that it shares the same deployment budget with baseline. This does not establish that the current prototype has already failed the real platform: no deployment certification was run here.
- Probe `budget_baseline_0.2_prep_0.9`: baseline=.2s, root/candidate=.9s, comparison=.002s. With nominal total=.7s, actual call elapsed=1.102s, yet result commits alternative with `abort_reason=None`; telemetry reports .002s only.
- Probe `budget_baseline_0.8_prep_0.0`: baseline already >.7s, yet helper allocates another .05s and commits alternative. A note is added but is not admission control.
- Fix: derive a single absolute deadline before baseline; debit begin_step/root reconstruction/candidate generation/guard/simulation/leaf/output; decline comparison if no remaining reserve. Remove minimum-budget replenishment. Keep total public elapsed and per-stage elapsed separately so the comparator-only cost cannot be read as overall search cost. Implement conservative whole-round admission before S2; current post-call timeout check cannot interrupt indivisible work.
- Supplemental logical probe `single_call_has_no_admission`: .05s budget can still execute a 3.1s rollout before returning A0. This is illustrative of missing admission, **not a timing forecast**. C_hi is already listed unfinished in status; distinguish that open deliverable from the incorrect accounting above.

## C02 — Nonfinite leaf values are accepted as completed comparisons; runtime exceptions produce no safe decision/telemetry (P2)

- `comparator.py:132,141,145,149–161` trusts both injected callbacks; `float(value)` is not a finite check. At :145 `NaN` / `Inf` enter `values`. The min/tuple selection is well-defined enough to silently return a choice, then `completed_rounds=1` and `abort_reason=None` certify completion.
- Independent probes: `[.1,+inf]` selects alternative and records a changed completed round; `[nan,.9]` returns A0 as a supposedly valid completed round despite no valid baseline comparison. `HeuristicLeafAdapter :45–51` labels nonfinite as merely out-of-range and returns it, so adapter does not close the hole. `VNetLeafAdapter` also lacks finite checks (backend inf maps to 1, nan remains nan), to be merged with leaf review if duplicate.
- Runtime rollout/leaf exceptions escape directly, as explicitly documented by status §5.1(10). This diagnostic choice is not concealment, but it does not meet design's deployed safe fallback contract. `real_env.py:514–526` records telemetry only after a successful return, so an error emits no decision row or failure count; output consumer can retain stale totals. Invalid caller contract (no A0/too many candidates) may still fail fast; runtime model/simulator failures after a valid A0 should be treated separately.
- Fix: require finite (not necessarily [0,1] for explicitly registered raw-margin heuristic) scores before committing; any nonfinite invalidates the entire round. At runtime boundary retain A0/last complete result and emit typed failure reason and attempted-work counters in a finally path. Diagnostics may additionally raise after recording; deployment must preserve fallback.
- No actual NaN in the natural-root run is claimed. This is an independently reproducible fail-open branch and missing regression fixture.

## C03 — Single-horizon prototype is not the registered anytime controller (open deliverable; don't call a production regression)

- `Comparator` is candid at :62: one-step single-horizon. Its only loop at :128 is over candidates; every invocation resets scores at :127 and only ever returns completed_rounds 0/1. There is no H1→H2→H3 advancement or stored prior-round winner.
- In contrast README comparator bullet and status code table claim interruption returns previous completed round. Passing horizon=2 directly attempts two-depth rollout for each candidate. Probe shows only H2 calls; on second-candidate timeout it returns A0, with no H1 evaluation or result available. Shipped T3 only tests first-round failure and cannot cover later-round fallback.
- Current natural-root S1 runs H=1, so its successful first-round behavior is not falsified by this gap. Mark multi-depth anytime + prior-complete fallback unimplemented; do not treat current S1 fixture as certifying that promised feature. Require a deliberate H1 winner / interrupted H2 fixture when implemented, or narrow current stage contract explicitly to H1.

## Additional low-priority observations (not primary blockers)

- `completed_comparisons` means eligible candidate count in `Decision` (:158), but completed root count in `StatsCollector` (:23,59). Current RealEnv maps manually via `completed`; serialized consumers need unit-specific names.
- Comparator only checks count and exactly-one-A0; it does not check unique indices or positive horizon. RealEnv generates unique indices by enumeration and calls H>=1 today, so treat as API robustness, not a demonstrated production issue.
- All-vetoed alternatives still produce a one-candidate completed round; this is explicit self-test :214–219. For mechanism success requiring actual comparison, separately count roots with >=2 eligible candidates. Current reported natural roots have no vetoes, so this does not invalidate their counts.
