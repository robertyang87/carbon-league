import ast, sys, json
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,'/workspace/carbon-league/code')
from fastsim import FastCarbon
source=Path('/workspace/search-code-review-20261116/comparator/s1_addendum_remote.py').read_text()
tree=ast.parse(source)
verify=next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=='verify_root')
calls=[]
instances=[]
class LoggedFastCarbon(FastCarbon):
    def __init__(self):
        super().__init__();self.step_entries=[];instances.append(self)
    def step(self,a,b):
        self.step_entries.append(self.step_count)
        return super().step(a,b)
def load_pack(path):
    def agent(obs):
        calls.append({'step':obs['step'],'seat':obs['player']})
        return {}
    return None,agent
ns={'real_env':SimpleNamespace(load_pack=load_pack),'wall':lambda:0.0,'VERIFY_UNTIL_S':565.0}
exec(compile(ast.Module(body=[verify],type_ignores=[]),'<unmodified verify_root source>','exec'),ns)
root=FastCarbon();root.reset(986360);snap=root.get_state();snap['step']=298
entry={'game':0,'seat':0,'step':298,'band':'ge220','FastCarbon':LoggedFastCarbon,'snap':snap,'a0':{},'chosen':{},'other':{}}
result=ns['verify_root']('unused_pack',entry)
evidence={'source_commit':'21098bad35e5cd8ac6104b3eef8ad20edb56c043','source_function':'s1_addendum.py:253-296 verify_root (AST extracted unchanged)', 'root_step':298,'arm_step_call_entries':[s.step_entries for s in instances],'policy_call_observations':calls,'result':result,'interpretation':'Each arm takes 298->299, then calls both policies at terminal step299 and advances299->300; marks this complete.'}
out=Path('/workspace/search-code-review-20261116/comparator/addendum_terminal_results.json');out.write_text(json.dumps(evidence,indent=2)+'\n');print(out.read_text())
