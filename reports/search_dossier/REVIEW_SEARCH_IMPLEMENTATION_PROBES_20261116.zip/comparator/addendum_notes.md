# Supplemental review of remote delta 21098bad

Local repository remains frozen at eeb1b4b9. Remote files copied with `git show 21098bad35e5cd8ac6104b3eef8ad20edb56c043:code/search_proto/{s1_addendum.py,s1_addendum_results.json}` to this evidence directory. No source edits or full matches run.

## Effect on prior comparator findings

None: comparator.py / real_env.py / telemetry.py are unchanged, so public timer undercount, minimum-budget replenishment, nonfinite-value acceptance and single-horizon-only scope remain.

## Positive credit / current acceptance status

The new addendum is honest about its result. Its header explicitly says exit 0 means the script finished, not PASS. Published JSON contains 48 attempted collision geometries, `success=null`, and verdict positive case not achieved. The scan reaches step197, records 86 roots /40 changed, all below220. Only saved step150 seat0 is verified: A0 reaches300, selected branch times out at255. `chosen_minus_a0_final_diff=null`, with incomplete reason. The addendum correctly refuses to turn a partial branch into a benefit delta; this is stronger than the original battery helper. It supplies no successful positive fixture or completed late continuation closure.

## A01 — Added verification repeats the wrong episode boundary and fresh-state continuation

- `s1_addendum.py:264–265` constructs fresh policy agents for each continuation, while entry only preserves simulator state/actions (:359–365), not Feat history / per-seat guard state. Explicitly documented equal cold start does not make it equivalent to the registered production continuation distribution. This is the same validation identity limitation as original battery, not a new independent root cause.
- `:274–286` runs until step300 and marks complete only there. No authoritative terminal check handles the step299 cutoff or earlier extinction. It also unconditionally takes the selected root move (:268–271).
- New deterministic probe `probe_addendum_terminal.py` executes the **unchanged AST-extracted verify_root function** with actual FastCarbon and cheap no-op policy stubs. At root step298, both arms call `step` at entries298 and299. Both policies are queried on terminal observation step299; simulator then reaches300 and is marked complete. Evidence in `addendum_terminal_results.json`. This is a control-flow proof of one extra transition, not a claim about full-model gain.
- Fix should be shared between original battery and addendum: reject roots already terminal, use canonical terminal predicate and previous-cash outcome contract, stop immediately after true terminal, preserve production policy memory (or explicitly register a separate cold-start-policy diagnostic), and measure actual U when certifying gain.

## Scope cautions

- Part1 `success` is a one-step cargo/survival event, not proof of final U improvement. It can validate collision avoidance mechanics if a fixture eventually succeeds; it does not replace exact terminal-positive acceptance or S3. Current output does not claim it succeeded.
- Do not inflate issue counts by re-listing inherited timer/terminal/memory problems as unrelated new items; append the new callsite to the existing issue.
- Metadata/assertion audit is delegated to acceptance reviewer.
