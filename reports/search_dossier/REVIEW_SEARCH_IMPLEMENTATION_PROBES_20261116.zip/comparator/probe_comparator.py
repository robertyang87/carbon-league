import sys, json, dataclasses
from pathlib import Path
sys.path.insert(0, '/workspace/carbon-league/code/search_proto')
import comparator
from comparator import Candidate, Comparator
from telemetry import StatsCollector
from real_env import RealEnvSearch
from leaf_adapters import HeuristicLeafAdapter

class Clock:
    def __init__(self): self.t = 0.0
    def tick(self, dt): self.t += dt
    def now(self): return self.t

clock = Clock()
original = comparator.time.monotonic
comparator.time.monotonic = clock.now
cands = [Candidate(0, 'a0', True), Candidate(1, 'a1', False)]
rows = {}
try:
    # The real entry helper does expensive root+candidate work before the timer;
    # fake clock isolates accounting deterministically from machine speed.
    for baseline, prep in [(0.2, 0.9), (0.8, 0.0)]:
        clock.t = baseline
        harness = RealEnvSearch.__new__(RealEnvSearch)
        harness.cfg = {'BUDGET': 0.7}
        harness.notes = []
        harness.collector = StatsCollector()
        harness.leaf_adapter = HeuristicLeafAdapter(lambda action: 0.1 if action == 'a0' else 0.9)
        root = type('Root', (), {'full': None, 'step': 10})()
        def build(obs, a0):
            clock.tick(prep / 2)
            return root
        def generate(root, a0):
            clock.tick(prep / 2)
            return cands, None, set()
        def make_rollout(root):
            def rollout(state, action, horizon, seed):
                clock.tick(.001)
                return action
            return rollout
        harness._build_root = build
        harness._generate_candidates = generate
        harness._make_rollout = make_rollout
        decision = harness.decide_at_root({}, 'a0', baseline)
        rows[f'budget_baseline_{baseline}_prep_{prep}'] = {
            'decision': dataclasses.asdict(decision), 'public_elapsed': clock.t,
            'registered_total': .7, 'telemetry': harness.collector.snapshot(),
            'notes': harness.notes,
        }
    for name, vals in [('infinite_alternative', [.1, float('inf')]), ('nan_baseline', [float('nan'), .9])]:
        clock.t = 0
        decision = Comparator(.1).decide(None,cands,lambda s,a,h,seed:a,lambda a:vals[0 if a=='a0' else 1],1,0)
        rows[name] = dataclasses.asdict(decision)
    for name, fn in [('rollout_raises', lambda s,a,h,seed: (_ for _ in ()).throw(RuntimeError('simulation failed'))), ('leaf_raises', lambda s,a,h,seed:a)]:
        clock.t = 0
        try:
            d = Comparator(.1).decide(None,cands,fn,lambda a: (_ for _ in ()).throw(ValueError('invalid leaf')),1,0)
            rows[name] = dataclasses.asdict(d)
        except Exception as exc:
            rows[name] = {'exception_escaped': type(exc).__name__, 'message': str(exc), 'a0_decision_returned': False}
    # One expensive indivisible rollout can consume arbitrary wall time despite
    # the tiny budget; post-call detection only changes the action afterward.
    clock.t = 0
    def costly(s,a,h,seed):
        clock.tick(3.1)
        return a
    d = Comparator(.05).decide(None,cands,costly,lambda a:.5,1,0)
    rows['single_call_has_no_admission'] = dataclasses.asdict(d)
    # Passing H=2 does not try H=1 first or retain an H=1 result.
    clock.t = 0
    calls = []
    def two_depth(s,a,h,seed):
        calls.append([a,h]);clock.tick(.03 if h==2 else .001);return a
    d = Comparator(.05).decide(None,cands,two_depth,lambda a:.4 if a=='a0' else .8,2,0)
    rows['single_horizon_no_complete_shallower_fallback'] = {'decision': dataclasses.asdict(d), 'called_horizons': calls}
finally:
    comparator.time.monotonic = original
out = Path('/workspace/search-code-review-20261116/comparator/results.json')
out.write_text(json.dumps(rows,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
print(out.read_text())
