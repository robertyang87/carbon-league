# 复核证据包

主代码冻结 eeb1b4b93374a0aba2c61b8d2bf8e867f2c3b58c，追加审查 21098bad35e5cd8ac6104b3eef8ad20edb56c043。
对当前修复版复跑时请记录实际 SHA；历史结果不自动证明新版本仍有相同问题。

本包只含审查笔记、轻量探针和输出。没有训练权重、凭据或生产改动。Echo4 包从用户自己的仓库 code/packs/echo4_int8.py 读取。
大场、资源认证、L-vnet33 工件不在本次验证范围。

要求 Python3.12、NumPy1.26.4；strategy 探针另需 Torch。仓库 sparse checkout 须包含 code/search_proto、code/packs/echo4_int8.py、code/ 下四件原源及 reports/。

解压后运行（每次只跑一个，结果写入证据目录）：

```sh
python RUN_REVIEW_PROBES.py --repo /path/to/carbon-league comparator
python RUN_REVIEW_PROBES.py --repo /path/to/carbon-league terminal
python RUN_REVIEW_PROBES.py --repo /path/to/carbon-league seat
python RUN_REVIEW_PROBES.py --repo /path/to/carbon-league battery
python RUN_REVIEW_PROBES.py --repo /path/to/carbon-league truncated
python RUN_REVIEW_PROBES.py --repo /path/to/carbon-league addendum
python RUN_REVIEW_PROBES.py --repo /path/to/carbon-league bridge
python RUN_REVIEW_PROBES.py --repo /path/to/carbon-league parity
python RUN_REVIEW_PROBES.py --repo /path/to/carbon-league strategy
```

runner仅在临时副本替换探针中的原评审路径，不修改业务源码。battery 为加速只采一个自然根，原B正反例不变；vendor准备和输出均重定向在证据目录。addendum 从包内保存的21098bad原源码抽取未改函数控制流，真实FastCarbon＋无动作策略桩验证终点。确定性时钟反例不是机器性能实测。

findings.md 是分线原始笔记；最终问题编号和范围以仓内 REVIEW_SEARCH_IMPLEMENTATION_20261116.md 为准。guard有限样本未证实动作翻转，保留其对照结果以避免只留失败证据。
